
package com.lenovo.m2.buy.smbmiddleware.remote.cxf.member;

import javax.xml.bind.annotation.XmlEnum;
import javax.xml.bind.annotation.XmlEnumValue;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>ProcessStatus的 Java 类。
 * 
 * <p>以下模式片段指定包含在此类中的预期内容。
 * <p>
 * <pre>
 * &lt;simpleType name="ProcessStatus"&gt;
 *   &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string"&gt;
 *     &lt;enumeration value="UnProcessed"/&gt;
 *     &lt;enumeration value="Succeed"/&gt;
 *     &lt;enumeration value="Failure"/&gt;
 *     &lt;enumeration value="Duplicate"/&gt;
 *   &lt;/restriction&gt;
 * &lt;/simpleType&gt;
 * </pre>
 * 
 */
@XmlType(name = "ProcessStatus")
@XmlEnum
public enum ProcessStatus {

    @XmlEnumValue("UnProcessed")
    UN_PROCESSED("UnProcessed"),
    @XmlEnumValue("Succeed")
    SUCCEED("Succeed"),
    @XmlEnumValue("Failure")
    FAILURE("Failure"),
    @XmlEnumValue("Duplicate")
    DUPLICATE("Duplicate");
    private final String value;

    ProcessStatus(String v) {
        value = v;
    }

    public String value() {
        return value;
    }

    public static ProcessStatus fromValue(String v) {
        for (ProcessStatus c: ProcessStatus.values()) {
            if (c.value.equals(v)) {
                return c;
            }
        }
        throw new IllegalArgumentException(v);
    }

}
