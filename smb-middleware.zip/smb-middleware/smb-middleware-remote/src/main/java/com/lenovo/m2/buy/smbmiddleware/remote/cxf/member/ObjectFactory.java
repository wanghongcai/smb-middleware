
package com.lenovo.m2.buy.smbmiddleware.remote.cxf.member;

import javax.xml.bind.annotation.XmlRegistry;


/**
 * This object contains factory methods for each 
 * Java content interface and Java element interface 
 * generated in the com.lenovo.m2.buy.smbmiddleware.remote.cxf.member package. 
 * <p>An ObjectFactory allows you to programatically 
 * construct new instances of the Java representation 
 * for XML content. The Java representation of XML 
 * content can consist of schema derived interfaces 
 * and classes representing the binding of schema 
 * type definitions, element declarations and model 
 * groups.  Factory methods for each of these are 
 * provided in this class.
 * 
 */
@XmlRegistry
public class ObjectFactory {


    /**
     * Create a new ObjectFactory that can be used to create new instances of schema derived classes for package: com.lenovo.m2.buy.smbmiddleware.remote.cxf.member
     * 
     */
    public ObjectFactory() {
    }

    /**
     * Create an instance of {@link HelloWorld }
     * 
     */
    public HelloWorld createHelloWorld() {
        return new HelloWorld();
    }

    /**
     * Create an instance of {@link HelloWorldResponse }
     * 
     */
    public HelloWorldResponse createHelloWorldResponse() {
        return new HelloWorldResponse();
    }

    /**
     * Create an instance of {@link AddMemberInfo }
     * 
     */
    public AddMemberInfo createAddMemberInfo() {
        return new AddMemberInfo();
    }

    /**
     * Create an instance of {@link IntegrationMemberInfo }
     * 
     */
    public IntegrationMemberInfo createIntegrationMemberInfo() {
        return new IntegrationMemberInfo();
    }

    /**
     * Create an instance of {@link AddMemberInfoResponse }
     * 
     */
    public AddMemberInfoResponse createAddMemberInfoResponse() {
        return new AddMemberInfoResponse();
    }

    /**
     * Create an instance of {@link Result }
     * 
     */
    public Result createResult() {
        return new Result();
    }

    /**
     * Create an instance of {@link UpdateMemberInfo }
     * 
     */
    public UpdateMemberInfo createUpdateMemberInfo() {
        return new UpdateMemberInfo();
    }

    /**
     * Create an instance of {@link UpdateMemberInfoResponse }
     * 
     */
    public UpdateMemberInfoResponse createUpdateMemberInfoResponse() {
        return new UpdateMemberInfoResponse();
    }

    /**
     * Create an instance of {@link SeachMemberInfo }
     * 
     */
    public SeachMemberInfo createSeachMemberInfo() {
        return new SeachMemberInfo();
    }

    /**
     * Create an instance of {@link SeachMemberInfoResponse }
     * 
     */
    public SeachMemberInfoResponse createSeachMemberInfoResponse() {
        return new SeachMemberInfoResponse();
    }

    /**
     * Create an instance of {@link AddInvoiceInfo }
     * 
     */
    public AddInvoiceInfo createAddInvoiceInfo() {
        return new AddInvoiceInfo();
    }

    /**
     * Create an instance of {@link IntegrationMemberInvoiceInfo }
     * 
     */
    public IntegrationMemberInvoiceInfo createIntegrationMemberInvoiceInfo() {
        return new IntegrationMemberInvoiceInfo();
    }

    /**
     * Create an instance of {@link AddInvoiceInfoResponse }
     * 
     */
    public AddInvoiceInfoResponse createAddInvoiceInfoResponse() {
        return new AddInvoiceInfoResponse();
    }

    /**
     * Create an instance of {@link UpdateInvoiceInfo }
     * 
     */
    public UpdateInvoiceInfo createUpdateInvoiceInfo() {
        return new UpdateInvoiceInfo();
    }

    /**
     * Create an instance of {@link UpdateInvoiceInfoResponse }
     * 
     */
    public UpdateInvoiceInfoResponse createUpdateInvoiceInfoResponse() {
        return new UpdateInvoiceInfoResponse();
    }

    /**
     * Create an instance of {@link SearchInvoiceInfo }
     * 
     */
    public SearchInvoiceInfo createSearchInvoiceInfo() {
        return new SearchInvoiceInfo();
    }

    /**
     * Create an instance of {@link SearchInvoiceInfoResponse }
     * 
     */
    public SearchInvoiceInfoResponse createSearchInvoiceInfoResponse() {
        return new SearchInvoiceInfoResponse();
    }

    /**
     * Create an instance of {@link AddCompanyInfo }
     * 
     */
    public AddCompanyInfo createAddCompanyInfo() {
        return new AddCompanyInfo();
    }

    /**
     * Create an instance of {@link IntegrationCompany }
     * 
     */
    public IntegrationCompany createIntegrationCompany() {
        return new IntegrationCompany();
    }

    /**
     * Create an instance of {@link AddCompanyInfoResponse }
     * 
     */
    public AddCompanyInfoResponse createAddCompanyInfoResponse() {
        return new AddCompanyInfoResponse();
    }

    /**
     * Create an instance of {@link UpdateCompanyInfo }
     * 
     */
    public UpdateCompanyInfo createUpdateCompanyInfo() {
        return new UpdateCompanyInfo();
    }

    /**
     * Create an instance of {@link UpdateCompanyInfoResponse }
     * 
     */
    public UpdateCompanyInfoResponse createUpdateCompanyInfoResponse() {
        return new UpdateCompanyInfoResponse();
    }

    /**
     * Create an instance of {@link SearchCompanyInfo }
     * 
     */
    public SearchCompanyInfo createSearchCompanyInfo() {
        return new SearchCompanyInfo();
    }

    /**
     * Create an instance of {@link SearchCompanyInfoResponse }
     * 
     */
    public SearchCompanyInfoResponse createSearchCompanyInfoResponse() {
        return new SearchCompanyInfoResponse();
    }

    /**
     * Create an instance of {@link AddShipInfo }
     * 
     */
    public AddShipInfo createAddShipInfo() {
        return new AddShipInfo();
    }

    /**
     * Create an instance of {@link IntegrationShipToParty }
     * 
     */
    public IntegrationShipToParty createIntegrationShipToParty() {
        return new IntegrationShipToParty();
    }

    /**
     * Create an instance of {@link AddShipInfoResponse }
     * 
     */
    public AddShipInfoResponse createAddShipInfoResponse() {
        return new AddShipInfoResponse();
    }

    /**
     * Create an instance of {@link UpdateShipInfo }
     * 
     */
    public UpdateShipInfo createUpdateShipInfo() {
        return new UpdateShipInfo();
    }

    /**
     * Create an instance of {@link UpdateShipInfoResponse }
     * 
     */
    public UpdateShipInfoResponse createUpdateShipInfoResponse() {
        return new UpdateShipInfoResponse();
    }

    /**
     * Create an instance of {@link SearchShipInfo }
     * 
     */
    public SearchShipInfo createSearchShipInfo() {
        return new SearchShipInfo();
    }

    /**
     * Create an instance of {@link SearchShipInfoResponse }
     * 
     */
    public SearchShipInfoResponse createSearchShipInfoResponse() {
        return new SearchShipInfoResponse();
    }

}
