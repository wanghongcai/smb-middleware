
package com.lenovo.m2.buy.smbmiddleware.remote.cxf.pricelist;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlSchemaType;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>IntegrationGoods complex type的 Java 类。
 * 
 * <p>以下模式片段指定包含在此类中的预期内容。
 * 
 * <pre>
 * &lt;complexType name="IntegrationGoods"&gt;
 *   &lt;complexContent&gt;
 *     &lt;extension base="{http://tempuri.org/}BasePoco"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="Code" type="{http://www.w3.org/2001/XMLSchema}long"/&gt;
 *         &lt;element name="Marketable" type="{http://tempuri.org/}TrueFalseEnum"/&gt;
 *         &lt;element name="Name" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="GoodsMaterialCode" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="ProductGroupCode" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="GoodsSMBCode" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="ThumbnailsPictureUrl" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="ProcessStatus" type="{http://tempuri.org/}ProcessStatus"/&gt;
 *         &lt;element name="OperationType" type="{http://tempuri.org/}OperationType"/&gt;
 *         &lt;element name="GoodsParameter" type="{http://tempuri.org/}ArrayOfIntegrationGoodsParameter" minOccurs="0"/&gt;
 *       &lt;/sequence&gt;
 *     &lt;/extension&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "IntegrationGoods", propOrder = {
    "code",
    "marketable",
    "name",
    "goodsMaterialCode",
    "productGroupCode",
    "goodsSMBCode",
    "thumbnailsPictureUrl",
    "processStatus",
    "operationType",
    "goodsParameter"
})
public class IntegrationGoods
    extends BasePoco
{

    @XmlElement(name = "Code")
    protected long code;
    @XmlElement(name = "Marketable", required = true, nillable = true)
    @XmlSchemaType(name = "string")
    protected TrueFalseEnum marketable;
    @XmlElement(name = "Name")
    protected String name;
    @XmlElement(name = "GoodsMaterialCode")
    protected String goodsMaterialCode;
    @XmlElement(name = "ProductGroupCode")
    protected String productGroupCode;
    @XmlElement(name = "GoodsSMBCode")
    protected String goodsSMBCode;
    @XmlElement(name = "ThumbnailsPictureUrl")
    protected String thumbnailsPictureUrl;
    @XmlElement(name = "ProcessStatus", required = true, nillable = true)
    @XmlSchemaType(name = "string")
    protected ProcessStatus processStatus;
    @XmlElement(name = "OperationType", required = true, nillable = true)
    @XmlSchemaType(name = "string")
    protected OperationType operationType;
    @XmlElement(name = "GoodsParameter")
    protected ArrayOfIntegrationGoodsParameter goodsParameter;

    /**
     * 获取code属性的值。
     * 
     */
    public long getCode() {
        return code;
    }

    /**
     * 设置code属性的值。
     * 
     */
    public void setCode(long value) {
        this.code = value;
    }

    /**
     * 获取marketable属性的值。
     * 
     * @return
     *     possible object is
     *     {@link TrueFalseEnum }
     *     
     */
    public TrueFalseEnum getMarketable() {
        return marketable;
    }

    /**
     * 设置marketable属性的值。
     * 
     * @param value
     *     allowed object is
     *     {@link TrueFalseEnum }
     *     
     */
    public void setMarketable(TrueFalseEnum value) {
        this.marketable = value;
    }

    /**
     * 获取name属性的值。
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getName() {
        return name;
    }

    /**
     * 设置name属性的值。
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setName(String value) {
        this.name = value;
    }

    /**
     * 获取goodsMaterialCode属性的值。
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getGoodsMaterialCode() {
        return goodsMaterialCode;
    }

    /**
     * 设置goodsMaterialCode属性的值。
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setGoodsMaterialCode(String value) {
        this.goodsMaterialCode = value;
    }

    /**
     * 获取productGroupCode属性的值。
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getProductGroupCode() {
        return productGroupCode;
    }

    /**
     * 设置productGroupCode属性的值。
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setProductGroupCode(String value) {
        this.productGroupCode = value;
    }

    /**
     * 获取goodsSMBCode属性的值。
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getGoodsSMBCode() {
        return goodsSMBCode;
    }

    /**
     * 设置goodsSMBCode属性的值。
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setGoodsSMBCode(String value) {
        this.goodsSMBCode = value;
    }

    /**
     * 获取thumbnailsPictureUrl属性的值。
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getThumbnailsPictureUrl() {
        return thumbnailsPictureUrl;
    }

    /**
     * 设置thumbnailsPictureUrl属性的值。
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setThumbnailsPictureUrl(String value) {
        this.thumbnailsPictureUrl = value;
    }

    /**
     * 获取processStatus属性的值。
     * 
     * @return
     *     possible object is
     *     {@link ProcessStatus }
     *     
     */
    public ProcessStatus getProcessStatus() {
        return processStatus;
    }

    /**
     * 设置processStatus属性的值。
     * 
     * @param value
     *     allowed object is
     *     {@link ProcessStatus }
     *     
     */
    public void setProcessStatus(ProcessStatus value) {
        this.processStatus = value;
    }

    /**
     * 获取operationType属性的值。
     * 
     * @return
     *     possible object is
     *     {@link OperationType }
     *     
     */
    public OperationType getOperationType() {
        return operationType;
    }

    /**
     * 设置operationType属性的值。
     * 
     * @param value
     *     allowed object is
     *     {@link OperationType }
     *     
     */
    public void setOperationType(OperationType value) {
        this.operationType = value;
    }

    /**
     * 获取goodsParameter属性的值。
     * 
     * @return
     *     possible object is
     *     {@link ArrayOfIntegrationGoodsParameter }
     *     
     */
    public ArrayOfIntegrationGoodsParameter getGoodsParameter() {
        return goodsParameter;
    }

    /**
     * 设置goodsParameter属性的值。
     * 
     * @param value
     *     allowed object is
     *     {@link ArrayOfIntegrationGoodsParameter }
     *     
     */
    public void setGoodsParameter(ArrayOfIntegrationGoodsParameter value) {
        this.goodsParameter = value;
    }

}
