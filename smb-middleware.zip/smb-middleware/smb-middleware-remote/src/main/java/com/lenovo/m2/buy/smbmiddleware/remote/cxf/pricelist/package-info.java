@javax.xml.bind.annotation.XmlSchema(namespace = "http://tempuri.org/", elementFormDefault = javax.xml.bind.annotation.XmlNsForm.QUALIFIED)
package com.lenovo.m2.buy.smbmiddleware.remote.cxf.pricelist;
