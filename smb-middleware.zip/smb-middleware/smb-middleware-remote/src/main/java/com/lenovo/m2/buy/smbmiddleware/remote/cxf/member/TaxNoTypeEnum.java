
package com.lenovo.m2.buy.smbmiddleware.remote.cxf.member;

import javax.xml.bind.annotation.XmlEnum;
import javax.xml.bind.annotation.XmlEnumValue;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>taxNoTypeEnum的 Java 类。
 * 
 * <p>以下模式片段指定包含在此类中的预期内容。
 * <p>
 * <pre>
 * &lt;simpleType name="taxNoTypeEnum"&gt;
 *   &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string"&gt;
 *     &lt;enumeration value="Tax"/&gt;
 *     &lt;enumeration value="CreditCode"/&gt;
 *     &lt;enumeration value="Empty"/&gt;
 *   &lt;/restriction&gt;
 * &lt;/simpleType&gt;
 * </pre>
 * 
 */
@XmlType(name = "taxNoTypeEnum")
@XmlEnum
public enum TaxNoTypeEnum {

    @XmlEnumValue("Tax")
    TAX("Tax"),
    @XmlEnumValue("CreditCode")
    CREDIT_CODE("CreditCode"),
    @XmlEnumValue("Empty")
    EMPTY("Empty");

    private final String value;

    TaxNoTypeEnum(String v) {
        value = v;
    }

    public String value() {
        return value;
    }

    public static TaxNoTypeEnum fromValue(String v) {
        for (TaxNoTypeEnum c: TaxNoTypeEnum.values()) {
            if (c.value.equals(v)) {
                return c;
            }
        }
        throw new IllegalArgumentException(v);
    }

}
