package com.lenovo.m2.buy.smbmiddleware.remote;

/**
 * Created by wangrq1 on 2016/7/28.
 */
public interface MemberInfoRemote {


    String findIdByThirdId(String thirdId) throws RuntimeException;

    String findThirdIdById(String id) throws RuntimeException;


    String findUserGUID(String id) throws RuntimeException;


}
