
package com.lenovo.m2.buy.smbmiddleware.remote.cxf.member;

import javax.xml.bind.annotation.XmlEnum;
import javax.xml.bind.annotation.XmlEnumValue;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>PayManTypeEnum的 Java 类。
 * 
 * <p>以下模式片段指定包含在此类中的预期内容。
 * <p>
 * <pre>
 * &lt;simpleType name="PayManTypeEnum"&gt;
 *   &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string"&gt;
 *     &lt;enumeration value="Person"/&gt;
 *     &lt;enumeration value="Company"/&gt;
 *   &lt;/restriction&gt;
 * &lt;/simpleType&gt;
 * </pre>
 * 
 */
@XmlType(name = "PayManTypeEnum")
@XmlEnum
public enum PayManTypeEnum {

    @XmlEnumValue("Person")
    PERSON("Person"),
    @XmlEnumValue("Company")
    COMPANY("Company");
    private final String value;

    PayManTypeEnum(String v) {
        value = v;
    }

    public String value() {
        return value;
    }

    public static PayManTypeEnum fromValue(String v) {
        for (PayManTypeEnum c: PayManTypeEnum.values()) {
            if (c.value.equals(v)) {
                return c;
            }
        }
        throw new IllegalArgumentException(v);
    }

}
