
package com.lenovo.m2.buy.smbmiddleware.remote.cxf.pricelist;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>IntegrationGoodsParameter complex type的 Java 类。
 * 
 * <p>以下模式片段指定包含在此类中的预期内容。
 * 
 * <pre>
 * &lt;complexType name="IntegrationGoodsParameter"&gt;
 *   &lt;complexContent&gt;
 *     &lt;extension base="{http://tempuri.org/}BasePoco"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="IntegrationGoodsID" type="{http://microsoft.com/wsdl/types/}guid"/&gt;
 *         &lt;element name="ServiceGoods" type="{http://tempuri.org/}IntegrationGoods" minOccurs="0"/&gt;
 *         &lt;element name="ParameterName" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="ParameterNameValue" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *       &lt;/sequence&gt;
 *     &lt;/extension&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "IntegrationGoodsParameter", propOrder = {
    "integrationGoodsID",
    "serviceGoods",
    "parameterName",
    "parameterNameValue"
})
public class IntegrationGoodsParameter
    extends BasePoco
{

    @XmlElement(name = "IntegrationGoodsID", required = true, nillable = true)
    protected String integrationGoodsID;
    @XmlElement(name = "ServiceGoods")
    protected IntegrationGoods serviceGoods;
    @XmlElement(name = "ParameterName")
    protected String parameterName;
    @XmlElement(name = "ParameterNameValue")
    protected String parameterNameValue;

    /**
     * 获取integrationGoodsID属性的值。
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getIntegrationGoodsID() {
        return integrationGoodsID;
    }

    /**
     * 设置integrationGoodsID属性的值。
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setIntegrationGoodsID(String value) {
        this.integrationGoodsID = value;
    }

    /**
     * 获取serviceGoods属性的值。
     * 
     * @return
     *     possible object is
     *     {@link IntegrationGoods }
     *     
     */
    public IntegrationGoods getServiceGoods() {
        return serviceGoods;
    }

    /**
     * 设置serviceGoods属性的值。
     * 
     * @param value
     *     allowed object is
     *     {@link IntegrationGoods }
     *     
     */
    public void setServiceGoods(IntegrationGoods value) {
        this.serviceGoods = value;
    }

    /**
     * 获取parameterName属性的值。
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getParameterName() {
        return parameterName;
    }

    /**
     * 设置parameterName属性的值。
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setParameterName(String value) {
        this.parameterName = value;
    }

    /**
     * 获取parameterNameValue属性的值。
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getParameterNameValue() {
        return parameterNameValue;
    }

    /**
     * 设置parameterNameValue属性的值。
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setParameterNameValue(String value) {
        this.parameterNameValue = value;
    }

}
