
package com.lenovo.m2.buy.smbmiddleware.remote.cxf.member;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlSchemaType;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>IntegrationShipToParty complex type的 Java 类。
 * 
 * <p>以下模式片段指定包含在此类中的预期内容。
 * 
 * <pre>
 * &lt;complexType name="IntegrationShipToParty"&gt;
 *   &lt;complexContent&gt;
 *     &lt;extension base="{http://tempuri.org/}BasePoco"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="MemberInfoID" type="{http://microsoft.com/wsdl/types/}guid"/&gt;
 *         &lt;element name="ClientName" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="ClientAbbName" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="SubAreaCode" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="SubAreaName" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="Zip" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="ProvinceCode" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="ProvinceName" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="CityCode" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="CityName" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="CountyCode" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="CountyName" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="VillageName" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="VillageCode" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="Address" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="MobilePhone" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="ShipToCompany" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="AddressType" type="{http://tempuri.org/}AddressTypeEnum"/&gt;
 *         &lt;element name="IsDefault" type="{http://tempuri.org/}TrueFalseEnum"/&gt;
 *         &lt;element name="ProcessStatus" type="{http://tempuri.org/}ProcessStatus"/&gt;
 *         &lt;element name="OperationType" type="{http://tempuri.org/}OperationType"/&gt;
 *         &lt;element name="IsValid" type="{http://tempuri.org/}TrueFalseEnum"/&gt;
 *       &lt;/sequence&gt;
 *     &lt;/extension&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "IntegrationShipToParty", propOrder = {
    "memberInfoID",
    "clientName",
    "clientAbbName",
    "subAreaCode",
    "subAreaName",
    "zip",
    "provinceCode",
    "provinceName",
    "cityCode",
    "cityName",
    "countyCode",
    "countyName",
    "villageName",
    "villageCode",
    "address",
    "mobilePhone",
    "shipToCompany",
    "addressType",
    "isDefault",
    "processStatus",
    "operationType",
    "isValid"
})
public class IntegrationShipToParty
    extends BasePoco
{

    @XmlElement(name = "MemberInfoID", required = true, nillable = true)
    protected String memberInfoID;
    @XmlElement(name = "ClientName")
    protected String clientName;
    @XmlElement(name = "ClientAbbName")
    protected String clientAbbName;
    @XmlElement(name = "SubAreaCode")
    protected String subAreaCode;
    @XmlElement(name = "SubAreaName")
    protected String subAreaName;
    @XmlElement(name = "Zip")
    protected String zip;
    @XmlElement(name = "ProvinceCode")
    protected String provinceCode;
    @XmlElement(name = "ProvinceName")
    protected String provinceName;
    @XmlElement(name = "CityCode")
    protected String cityCode;
    @XmlElement(name = "CityName")
    protected String cityName;
    @XmlElement(name = "CountyCode")
    protected String countyCode;
    @XmlElement(name = "CountyName")
    protected String countyName;
    @XmlElement(name = "VillageName")
    protected String villageName;
    @XmlElement(name = "VillageCode")
    protected String villageCode;
    @XmlElement(name = "Address")
    protected String address;
    @XmlElement(name = "MobilePhone")
    protected String mobilePhone;
    @XmlElement(name = "ShipToCompany")
    protected String shipToCompany;
    @XmlElement(name = "AddressType", required = true, nillable = true)
    @XmlSchemaType(name = "string")
    protected AddressTypeEnum addressType;
    @XmlElement(name = "IsDefault", required = true, nillable = true)
    @XmlSchemaType(name = "string")
    protected TrueFalseEnum isDefault;
    @XmlElement(name = "ProcessStatus", required = true)
    @XmlSchemaType(name = "string")
    protected ProcessStatus processStatus;
    @XmlElement(name = "OperationType", required = true)
    @XmlSchemaType(name = "string")
    protected OperationType operationType;
    @XmlElement(name = "IsValid", required = true)
    @XmlSchemaType(name = "string")
    protected TrueFalseEnum isValid;

    /**
     * 获取memberInfoID属性的值。
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getMemberInfoID() {
        return memberInfoID;
    }

    /**
     * 设置memberInfoID属性的值。
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setMemberInfoID(String value) {
        this.memberInfoID = value;
    }

    /**
     * 获取clientName属性的值。
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getClientName() {
        return clientName;
    }

    /**
     * 设置clientName属性的值。
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setClientName(String value) {
        this.clientName = value;
    }

    /**
     * 获取clientAbbName属性的值。
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getClientAbbName() {
        return clientAbbName;
    }

    /**
     * 设置clientAbbName属性的值。
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setClientAbbName(String value) {
        this.clientAbbName = value;
    }

    /**
     * 获取subAreaCode属性的值。
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getSubAreaCode() {
        return subAreaCode;
    }

    /**
     * 设置subAreaCode属性的值。
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setSubAreaCode(String value) {
        this.subAreaCode = value;
    }

    /**
     * 获取subAreaName属性的值。
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getSubAreaName() {
        return subAreaName;
    }

    /**
     * 设置subAreaName属性的值。
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setSubAreaName(String value) {
        this.subAreaName = value;
    }

    /**
     * 获取zip属性的值。
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getZip() {
        return zip;
    }

    /**
     * 设置zip属性的值。
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setZip(String value) {
        this.zip = value;
    }

    /**
     * 获取provinceCode属性的值。
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getProvinceCode() {
        return provinceCode;
    }

    /**
     * 设置provinceCode属性的值。
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setProvinceCode(String value) {
        this.provinceCode = value;
    }

    /**
     * 获取provinceName属性的值。
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getProvinceName() {
        return provinceName;
    }

    /**
     * 设置provinceName属性的值。
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setProvinceName(String value) {
        this.provinceName = value;
    }

    /**
     * 获取cityCode属性的值。
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCityCode() {
        return cityCode;
    }

    /**
     * 设置cityCode属性的值。
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCityCode(String value) {
        this.cityCode = value;
    }

    /**
     * 获取cityName属性的值。
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCityName() {
        return cityName;
    }

    /**
     * 设置cityName属性的值。
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCityName(String value) {
        this.cityName = value;
    }

    /**
     * 获取countyCode属性的值。
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCountyCode() {
        return countyCode;
    }

    /**
     * 设置countyCode属性的值。
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCountyCode(String value) {
        this.countyCode = value;
    }

    /**
     * 获取countyName属性的值。
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCountyName() {
        return countyName;
    }

    /**
     * 设置countyName属性的值。
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCountyName(String value) {
        this.countyName = value;
    }

    /**
     * 获取villageName属性的值。
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getVillageName() {
        return villageName;
    }

    /**
     * 设置villageName属性的值。
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setVillageName(String value) {
        this.villageName = value;
    }

    /**
     * 获取villageCode属性的值。
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getVillageCode() {
        return villageCode;
    }

    /**
     * 设置villageCode属性的值。
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setVillageCode(String value) {
        this.villageCode = value;
    }

    /**
     * 获取address属性的值。
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getAddress() {
        return address;
    }

    /**
     * 设置address属性的值。
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setAddress(String value) {
        this.address = value;
    }

    /**
     * 获取mobilePhone属性的值。
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getMobilePhone() {
        return mobilePhone;
    }

    /**
     * 设置mobilePhone属性的值。
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setMobilePhone(String value) {
        this.mobilePhone = value;
    }

    /**
     * 获取shipToCompany属性的值。
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getShipToCompany() {
        return shipToCompany;
    }

    /**
     * 设置shipToCompany属性的值。
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setShipToCompany(String value) {
        this.shipToCompany = value;
    }

    /**
     * 获取addressType属性的值。
     * 
     * @return
     *     possible object is
     *     {@link AddressTypeEnum }
     *     
     */
    public AddressTypeEnum getAddressType() {
        return addressType;
    }

    /**
     * 设置addressType属性的值。
     * 
     * @param value
     *     allowed object is
     *     {@link AddressTypeEnum }
     *     
     */
    public void setAddressType(AddressTypeEnum value) {
        this.addressType = value;
    }

    /**
     * 获取isDefault属性的值。
     * 
     * @return
     *     possible object is
     *     {@link TrueFalseEnum }
     *     
     */
    public TrueFalseEnum getIsDefault() {
        return isDefault;
    }

    /**
     * 设置isDefault属性的值。
     * 
     * @param value
     *     allowed object is
     *     {@link TrueFalseEnum }
     *     
     */
    public void setIsDefault(TrueFalseEnum value) {
        this.isDefault = value;
    }

    /**
     * 获取processStatus属性的值。
     * 
     * @return
     *     possible object is
     *     {@link ProcessStatus }
     *     
     */
    public ProcessStatus getProcessStatus() {
        return processStatus;
    }

    /**
     * 设置processStatus属性的值。
     * 
     * @param value
     *     allowed object is
     *     {@link ProcessStatus }
     *     
     */
    public void setProcessStatus(ProcessStatus value) {
        this.processStatus = value;
    }

    /**
     * 获取operationType属性的值。
     * 
     * @return
     *     possible object is
     *     {@link OperationType }
     *     
     */
    public OperationType getOperationType() {
        return operationType;
    }

    /**
     * 设置operationType属性的值。
     * 
     * @param value
     *     allowed object is
     *     {@link OperationType }
     *     
     */
    public void setOperationType(OperationType value) {
        this.operationType = value;
    }

    /**
     * 获取isValid属性的值。
     * 
     * @return
     *     possible object is
     *     {@link TrueFalseEnum }
     *     
     */
    public TrueFalseEnum getIsValid() {
        return isValid;
    }

    /**
     * 设置isValid属性的值。
     * 
     * @param value
     *     allowed object is
     *     {@link TrueFalseEnum }
     *     
     */
    public void setIsValid(TrueFalseEnum value) {
        this.isValid = value;
    }

}
