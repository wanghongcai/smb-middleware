
package com.lenovo.m2.buy.smbmiddleware.remote.cxf.pricelist;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlSchemaType;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>IntegrationPriceList complex type的 Java 类。
 * 
 * <p>以下模式片段指定包含在此类中的预期内容。
 * 
 * <pre>
 * &lt;complexType name="IntegrationPriceList"&gt;
 *   &lt;complexContent&gt;
 *     &lt;extension base="{http://tempuri.org/}BasePoco"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="PriceListCode" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="OperationType" type="{http://tempuri.org/}PriceListType"/&gt;
 *         &lt;element name="ProcessStatus" type="{http://tempuri.org/}ProcessStatus"/&gt;
 *       &lt;/sequence&gt;
 *     &lt;/extension&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "IntegrationPriceList", propOrder = {
    "priceListCode",
    "operationType",
    "processStatus"
})
public class IntegrationPriceList
    extends BasePoco
{

    @XmlElement(name = "PriceListCode")
    protected String priceListCode;
    @XmlElement(name = "OperationType", required = true, nillable = true)
    @XmlSchemaType(name = "string")
    protected PriceListType operationType;
    @XmlElement(name = "ProcessStatus", required = true, nillable = true)
    @XmlSchemaType(name = "string")
    protected ProcessStatus processStatus;

    /**
     * 获取priceListCode属性的值。
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getPriceListCode() {
        return priceListCode;
    }

    /**
     * 设置priceListCode属性的值。
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setPriceListCode(String value) {
        this.priceListCode = value;
    }

    /**
     * 获取operationType属性的值。
     * 
     * @return
     *     possible object is
     *     {@link PriceListType }
     *     
     */
    public PriceListType getOperationType() {
        return operationType;
    }

    /**
     * 设置operationType属性的值。
     * 
     * @param value
     *     allowed object is
     *     {@link PriceListType }
     *     
     */
    public void setOperationType(PriceListType value) {
        this.operationType = value;
    }

    /**
     * 获取processStatus属性的值。
     * 
     * @return
     *     possible object is
     *     {@link ProcessStatus }
     *     
     */
    public ProcessStatus getProcessStatus() {
        return processStatus;
    }

    /**
     * 设置processStatus属性的值。
     * 
     * @param value
     *     allowed object is
     *     {@link ProcessStatus }
     *     
     */
    public void setProcessStatus(ProcessStatus value) {
        this.processStatus = value;
    }

}
