package com.lenovo.m2.buy.smbmiddleware.remote.impl;

import java.util.HashMap;
import java.util.Map;

import com.lenovo.m2.buy.smbmiddleware.remote.OpenPlatUtil;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.lenovo.m2.buy.smbmiddleware.exception.BusinessException;
import com.lenovo.m2.buy.smbmiddleware.remote.MemberInfoRemote;
import com.lenovo.m2.buy.smbmiddleware.util.Constants;
import com.lenovo.m2.buy.smbmiddleware.util.JsonUtil;

/**
 * Created by wangrq1 on 2016/7/28.
 */

@Service
public class MemberInfoRemoteImpl implements MemberInfoRemote {

    static String SMB_GROUP_ID = "C0002";

    @Autowired
    private OpenPlatUtil openPlatUtil;


    @Override
    public String findUserGUID(String id) throws RuntimeException {
        Map<String,String> param = new HashMap<>();
        param.put("sts", "e40e7004-4c8a-4963-8564-31271a8337d8");
        param.put("customerId", id);

//        return "e40e7004-4c8a-4963-8564-31271a8337d8";
        String res = openPlatUtil.invokeOpenPlat(Constants.METHOD_MEMBER_GETTHIRDIDBYID, JsonUtil.toJson(param));
        Map map = JsonUtil.fromJson(res, Map.class);
        String ret = String.valueOf(map.get("ret"));
        if("0".equals(ret)){
            Map obj = (Map)map.get("obj");
            return String.valueOf(obj.get("customerguid"));
        }else {
            throw new BusinessException("", String.valueOf(map.get("msg")));
        }
    }

    @Override
    public String findIdByThirdId(String thirdId) throws RuntimeException {
        Map<String,String> param = new HashMap<>();
        param.put("sts", "e40e7004-4c8a-4963-8564-31271a8337d8");
        param.put("thirdId", thirdId);
        param.put("groupId", SMB_GROUP_ID);
//        return "12345";
        String res = openPlatUtil.invokeOpenPlat(Constants.METHOD_MEMBER_GETIDBYTHIRDID, JsonUtil.toJson(param));

        Map map = JsonUtil.fromJson(res, Map.class);
        String ret = String.valueOf(map.get("ret"));
        if("0".equals(ret)){
            Map obj = (Map)map.get("obj");
            return String.valueOf(obj.get("customerid"));
        }else {
            throw new BusinessException("", String.valueOf(map.get("msg")));
        }
    }

    @Override
    public String findThirdIdById(String id) throws RuntimeException {
        Map<String,String> param = new HashMap<>();
        param.put("sts", "e40e7004-4c8a-4963-8564-31271a8337d8");
        param.put("customerId", id);

//        return "SMB2160728000001";

        String res = openPlatUtil.invokeOpenPlat(Constants.METHOD_MEMBER_GETTHIRDIDBYID, JsonUtil.toJson(param));

        Map map = JsonUtil.fromJson(res, Map.class);
        String ret = String.valueOf(map.get("ret"));
        if("0".equals(ret)){
            Map obj = (Map)map.get("obj");
            return String.valueOf(obj.get("smbid"));
        }else {
            throw new BusinessException("", String.valueOf(map.get("msg")));
        }

    }
}
