
package com.lenovo.m2.buy.smbmiddleware.remote.cxf.member;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlSchemaType;
import javax.xml.bind.annotation.XmlType;
import javax.xml.datatype.XMLGregorianCalendar;


/**
 * <p>IntegrationMemberInfo complex type的 Java 类。
 * 
 * <p>以下模式片段指定包含在此类中的预期内容。
 * 
 * <pre>
 * &lt;complexType name="IntegrationMemberInfo"&gt;
 *   &lt;complexContent&gt;
 *     &lt;extension base="{http://tempuri.org/}BasePoco"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="MemberCode" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="MemberName" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="TFGetEmail" type="{http://tempuri.org/}TrueFalseEnum"/&gt;
 *         &lt;element name="TFGetPhone" type="{http://tempuri.org/}TrueFalseEnum"/&gt;
 *         &lt;element name="Email" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="MobilePhone" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="Telphone" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="Birthday" type="{http://www.w3.org/2001/XMLSchema}dateTime"/&gt;
 *         &lt;element name="CompanyID" type="{http://microsoft.com/wsdl/types/}guid"/&gt;
 *         &lt;element name="LoginCode" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="PassWord" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="IsMailActivate" type="{http://tempuri.org/}TrueFalseEnum"/&gt;
 *         &lt;element name="IsActivate" type="{http://tempuri.org/}TrueFalseEnum"/&gt;
 *         &lt;element name="ProcessStatus" type="{http://tempuri.org/}ProcessStatus"/&gt;
 *         &lt;element name="OperationType" type="{http://tempuri.org/}OperationType"/&gt;
 *       &lt;/sequence&gt;
 *     &lt;/extension&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "IntegrationMemberInfo", propOrder = {
    "memberCode",
    "memberName",
    "tfGetEmail",
    "tfGetPhone",
    "email",
    "mobilePhone",
    "telphone",
    "birthday",
    "companyID",
    "loginCode",
    "passWord",
    "isMailActivate",
    "isActivate",
    "processStatus",
    "operationType"
})
public class IntegrationMemberInfo
    extends BasePoco
{

    @XmlElement(name = "MemberCode")
    protected String memberCode;
    @XmlElement(name = "MemberName")
    protected String memberName;
    @XmlElement(name = "TFGetEmail", required = true, nillable = true)
    @XmlSchemaType(name = "string")
    protected TrueFalseEnum tfGetEmail;
    @XmlElement(name = "TFGetPhone", required = true, nillable = true)
    @XmlSchemaType(name = "string")
    protected TrueFalseEnum tfGetPhone;
    @XmlElement(name = "Email")
    protected String email;
    @XmlElement(name = "MobilePhone")
    protected String mobilePhone;
    @XmlElement(name = "Telphone")
    protected String telphone;
    @XmlElement(name = "Birthday", required = true, nillable = true)
    @XmlSchemaType(name = "dateTime")
    protected XMLGregorianCalendar birthday;
    @XmlElement(name = "CompanyID", required = true, nillable = true)
    protected String companyID;
    @XmlElement(name = "LoginCode")
    protected String loginCode;
    @XmlElement(name = "PassWord")
    protected String passWord;
    @XmlElement(name = "IsMailActivate", required = true, nillable = true)
    @XmlSchemaType(name = "string")
    protected TrueFalseEnum isMailActivate;
    @XmlElement(name = "IsActivate", required = true, nillable = true)
    @XmlSchemaType(name = "string")
    protected TrueFalseEnum isActivate;
    @XmlElement(name = "ProcessStatus", required = true, nillable = true)
    @XmlSchemaType(name = "string")
    protected ProcessStatus processStatus;
    @XmlElement(name = "OperationType", required = true, nillable = true)
    @XmlSchemaType(name = "string")
    protected OperationType operationType;

    /**
     * 获取memberCode属性的值。
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getMemberCode() {
        return memberCode;
    }

    /**
     * 设置memberCode属性的值。
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setMemberCode(String value) {
        this.memberCode = value;
    }

    /**
     * 获取memberName属性的值。
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getMemberName() {
        return memberName;
    }

    /**
     * 设置memberName属性的值。
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setMemberName(String value) {
        this.memberName = value;
    }

    /**
     * 获取tfGetEmail属性的值。
     * 
     * @return
     *     possible object is
     *     {@link TrueFalseEnum }
     *     
     */
    public TrueFalseEnum getTFGetEmail() {
        return tfGetEmail;
    }

    /**
     * 设置tfGetEmail属性的值。
     * 
     * @param value
     *     allowed object is
     *     {@link TrueFalseEnum }
     *     
     */
    public void setTFGetEmail(TrueFalseEnum value) {
        this.tfGetEmail = value;
    }

    /**
     * 获取tfGetPhone属性的值。
     * 
     * @return
     *     possible object is
     *     {@link TrueFalseEnum }
     *     
     */
    public TrueFalseEnum getTFGetPhone() {
        return tfGetPhone;
    }

    /**
     * 设置tfGetPhone属性的值。
     * 
     * @param value
     *     allowed object is
     *     {@link TrueFalseEnum }
     *     
     */
    public void setTFGetPhone(TrueFalseEnum value) {
        this.tfGetPhone = value;
    }

    /**
     * 获取email属性的值。
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getEmail() {
        return email;
    }

    /**
     * 设置email属性的值。
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setEmail(String value) {
        this.email = value;
    }

    /**
     * 获取mobilePhone属性的值。
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getMobilePhone() {
        return mobilePhone;
    }

    /**
     * 设置mobilePhone属性的值。
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setMobilePhone(String value) {
        this.mobilePhone = value;
    }

    /**
     * 获取telphone属性的值。
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getTelphone() {
        return telphone;
    }

    /**
     * 设置telphone属性的值。
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setTelphone(String value) {
        this.telphone = value;
    }

    /**
     * 获取birthday属性的值。
     * 
     * @return
     *     possible object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public XMLGregorianCalendar getBirthday() {
        return birthday;
    }

    /**
     * 设置birthday属性的值。
     * 
     * @param value
     *     allowed object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public void setBirthday(XMLGregorianCalendar value) {
        this.birthday = value;
    }

    /**
     * 获取companyID属性的值。
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCompanyID() {
        return companyID;
    }

    /**
     * 设置companyID属性的值。
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCompanyID(String value) {
        this.companyID = value;
    }

    /**
     * 获取loginCode属性的值。
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getLoginCode() {
        return loginCode;
    }

    /**
     * 设置loginCode属性的值。
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setLoginCode(String value) {
        this.loginCode = value;
    }

    /**
     * 获取passWord属性的值。
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getPassWord() {
        return passWord;
    }

    /**
     * 设置passWord属性的值。
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setPassWord(String value) {
        this.passWord = value;
    }

    /**
     * 获取isMailActivate属性的值。
     * 
     * @return
     *     possible object is
     *     {@link TrueFalseEnum }
     *     
     */
    public TrueFalseEnum getIsMailActivate() {
        return isMailActivate;
    }

    /**
     * 设置isMailActivate属性的值。
     * 
     * @param value
     *     allowed object is
     *     {@link TrueFalseEnum }
     *     
     */
    public void setIsMailActivate(TrueFalseEnum value) {
        this.isMailActivate = value;
    }

    /**
     * 获取isActivate属性的值。
     * 
     * @return
     *     possible object is
     *     {@link TrueFalseEnum }
     *     
     */
    public TrueFalseEnum getIsActivate() {
        return isActivate;
    }

    /**
     * 设置isActivate属性的值。
     * 
     * @param value
     *     allowed object is
     *     {@link TrueFalseEnum }
     *     
     */
    public void setIsActivate(TrueFalseEnum value) {
        this.isActivate = value;
    }

    /**
     * 获取processStatus属性的值。
     * 
     * @return
     *     possible object is
     *     {@link ProcessStatus }
     *     
     */
    public ProcessStatus getProcessStatus() {
        return processStatus;
    }

    /**
     * 设置processStatus属性的值。
     * 
     * @param value
     *     allowed object is
     *     {@link ProcessStatus }
     *     
     */
    public void setProcessStatus(ProcessStatus value) {
        this.processStatus = value;
    }

    /**
     * 获取operationType属性的值。
     * 
     * @return
     *     possible object is
     *     {@link OperationType }
     *     
     */
    public OperationType getOperationType() {
        return operationType;
    }

    /**
     * 设置operationType属性的值。
     * 
     * @param value
     *     allowed object is
     *     {@link OperationType }
     *     
     */
    public void setOperationType(OperationType value) {
        this.operationType = value;
    }

}
