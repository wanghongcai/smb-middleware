package com.lenovo.m2.buy.smbmiddleware.remote;


import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.lenovo.m2.buy.smbmiddleware.enums.GlobalErrorMessage;
import com.lenovo.m2.buy.smbmiddleware.exception.BusinessException;
import com.lenovo.m2.buy.smbmiddleware.util.HttpUtil;
import com.lenovo.m2.buy.smbmiddleware.util.JsonUtil;
import com.lenovo.m2.buy.smbmiddleware.util.OpenPlatReq;

/**
 * Created by wangrq1 on 2016/7/21.
 */
public class OpenPlatUtil {
	
	private static Logger log = LoggerFactory.getLogger(OpenPlatUtil.class);

    private String   url;

    private String appKey;

    private String secretKey;

    public OpenPlatUtil(){}

    public OpenPlatUtil(String url, String appKey, String secretKey){
        this.url = url;
        this.appKey = appKey;
        this.secretKey = secretKey;
    }



    public String invokeOpenPlat(String method, String param) throws RuntimeException {

        method = method + "_hs";

        OpenPlatReq req = new OpenPlatReq(method, param, appKey, secretKey);
        log.info("url={},req body={}", url, req.getPostBody());
        String platRes =  HttpUtil.executeHttpPost(url, req.getPostBody());
        log.info("res={}", platRes);

        Map map = JsonUtil.fromJson(platRes, Map.class);
        Object success = map.get("success");
        if("true".equals(String.valueOf(success))){
            Map obj = (Map)map.get("result");
            Object res = obj.get(String.format("%s_response", method.replaceAll("\\.", "_")));
            log.info("unpack res={}", res);
            return JsonUtil.toJson(res);
        }else{
        	log.info("invoke openplat failed, res={}", platRes);
            throw new BusinessException(GlobalErrorMessage.ERROR_INVOKE_OPEN_PLAT);
        }

    }

    public String getUrl() {
        return url;
    }

    public void setUrl(String url) {
        this.url = url;
    }

    public String getAppKey() {
        return appKey;
    }

    public void setAppKey(String appKey) {
        this.appKey = appKey;
    }

    public String getSecretKey() {
        return secretKey;
    }

    public void setSecretKey(String secretKey) {
        this.secretKey = secretKey;
    }
}
