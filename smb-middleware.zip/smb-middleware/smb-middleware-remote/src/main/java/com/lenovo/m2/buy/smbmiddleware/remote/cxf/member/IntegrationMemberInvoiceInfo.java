
package com.lenovo.m2.buy.smbmiddleware.remote.cxf.member;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlSchemaType;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>IntegrationMemberInvoiceInfo complex type的 Java 类。
 * 
 * <p>以下模式片段指定包含在此类中的预期内容。
 * 
 * <pre>
 * &lt;complexType name="IntegrationMemberInvoiceInfo"&gt;
 *   &lt;complexContent&gt;
 *     &lt;extension base="{http://tempuri.org/}BasePoco"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="InvoiceName" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="MemberInfoID" type="{http://microsoft.com/wsdl/types/}guid"/&gt;
 *         &lt;element name="CompanyType" type="{http://tempuri.org/}InvoiceCompanyTypeEnum"/&gt;
 *         &lt;element name="InvoiceSort" type="{http://tempuri.org/}InvoiceSortEnum"/&gt;
 *         &lt;element name="taxNoType" type="{http://tempuri.org/}taxNoTypeEnum"/&gt;
 *         &lt;element name="InvoiceType" type="{http://tempuri.org/}InvoiceTypeEnum"/&gt;
 *         &lt;element name="PayManType" type="{http://tempuri.org/}PayManTypeEnum"/&gt;
 *         &lt;element name="PayMan" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="TaxID" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="BankName" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="BankID" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="SubAreaCode" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="SubAreaName" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="Zip" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="ProvinceCode" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="ProvinceName" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="CityCode" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="CityName" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="CountyCode" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="CountyName" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="Address" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="Phone" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="IsShow" type="{http://tempuri.org/}TrueFalseEnum"/&gt;
 *         &lt;element name="IsDefault" type="{http://tempuri.org/}TrueFalseEnum"/&gt;
 *         &lt;element name="ProcessStatus" type="{http://tempuri.org/}ProcessStatus"/&gt;
 *         &lt;element name="OperationType" type="{http://tempuri.org/}OperationType"/&gt;
 *         &lt;element name="ApprovalStatus" type="{http://tempuri.org/}MemberInvoiceStatusEnum"/&gt;
 *         &lt;element name="SoldToCode" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *       &lt;/sequence&gt;
 *     &lt;/extension&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "IntegrationMemberInvoiceInfo", propOrder = {
    "invoiceName",
    "memberInfoID",
    "companyType",
    "invoiceSort",
    "taxNoType",
    "invoiceType",
    "payManType",
    "payMan",
    "taxID",
    "bankName",
    "bankID",
    "subAreaCode",
    "subAreaName",
    "zip",
    "provinceCode",
    "provinceName",
    "cityCode",
    "cityName",
    "countyCode",
    "countyName",
    "address",
    "phone",
    "isShow",
    "isDefault",
    "processStatus",
    "operationType",
    "approvalStatus",
    "soldToCode"
})
public class IntegrationMemberInvoiceInfo
    extends BasePoco
{

    @XmlElement(name = "InvoiceName")
    protected String invoiceName;
    @XmlElement(name = "MemberInfoID", required = true, nillable = true)
    protected String memberInfoID;
    @XmlElement(name = "CompanyType", required = true, nillable = true)
    @XmlSchemaType(name = "string")
    protected InvoiceCompanyTypeEnum companyType;
    @XmlElement(name = "InvoiceSort", required = true, nillable = true)
    @XmlSchemaType(name = "string")
    protected InvoiceSortEnum invoiceSort;
    @XmlElement(required = true, nillable = true)
    @XmlSchemaType(name = "string")
    protected TaxNoTypeEnum taxNoType;
    @XmlElement(name = "InvoiceType", required = true, nillable = true)
    @XmlSchemaType(name = "string")
    protected InvoiceTypeEnum invoiceType;
    @XmlElement(name = "PayManType", required = true, nillable = true)
    @XmlSchemaType(name = "string")
    protected PayManTypeEnum payManType;
    @XmlElement(name = "PayMan")
    protected String payMan;
    @XmlElement(name = "TaxID")
    protected String taxID;
    @XmlElement(name = "BankName")
    protected String bankName;
    @XmlElement(name = "BankID")
    protected String bankID;
    @XmlElement(name = "SubAreaCode")
    protected String subAreaCode;
    @XmlElement(name = "SubAreaName")
    protected String subAreaName;
    @XmlElement(name = "Zip")
    protected String zip;
    @XmlElement(name = "ProvinceCode")
    protected String provinceCode;
    @XmlElement(name = "ProvinceName")
    protected String provinceName;
    @XmlElement(name = "CityCode")
    protected String cityCode;
    @XmlElement(name = "CityName")
    protected String cityName;
    @XmlElement(name = "CountyCode")
    protected String countyCode;
    @XmlElement(name = "CountyName")
    protected String countyName;
    @XmlElement(name = "Address")
    protected String address;
    @XmlElement(name = "Phone")
    protected String phone;
    @XmlElement(name = "IsShow", required = true, nillable = true)
    @XmlSchemaType(name = "string")
    protected TrueFalseEnum isShow;
    @XmlElement(name = "IsDefault", required = true, nillable = true)
    @XmlSchemaType(name = "string")
    protected TrueFalseEnum isDefault;
    @XmlElement(name = "ProcessStatus", required = true)
    @XmlSchemaType(name = "string")
    protected ProcessStatus processStatus;
    @XmlElement(name = "OperationType", required = true)
    @XmlSchemaType(name = "string")
    protected OperationType operationType;
    @XmlElement(name = "ApprovalStatus", required = true, nillable = true)
    @XmlSchemaType(name = "string")
    protected MemberInvoiceStatusEnum approvalStatus;
    @XmlElement(name = "SoldToCode")
    protected String soldToCode;

    /**
     * 获取invoiceName属性的值。
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getInvoiceName() {
        return invoiceName;
    }

    /**
     * 设置invoiceName属性的值。
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setInvoiceName(String value) {
        this.invoiceName = value;
    }

    /**
     * 获取memberInfoID属性的值。
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getMemberInfoID() {
        return memberInfoID;
    }

    /**
     * 设置memberInfoID属性的值。
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setMemberInfoID(String value) {
        this.memberInfoID = value;
    }

    /**
     * 获取companyType属性的值。
     * 
     * @return
     *     possible object is
     *     {@link InvoiceCompanyTypeEnum }
     *     
     */
    public InvoiceCompanyTypeEnum getCompanyType() {
        return companyType;
    }

    /**
     * 设置companyType属性的值。
     * 
     * @param value
     *     allowed object is
     *     {@link InvoiceCompanyTypeEnum }
     *     
     */
    public void setCompanyType(InvoiceCompanyTypeEnum value) {
        this.companyType = value;
    }

    /**
     * 获取invoiceSort属性的值。
     * 
     * @return
     *     possible object is
     *     {@link InvoiceSortEnum }
     *     
     */
    public InvoiceSortEnum getInvoiceSort() {
        return invoiceSort;
    }

    /**
     * 设置invoiceSort属性的值。
     * 
     * @param value
     *     allowed object is
     *     {@link InvoiceSortEnum }
     *     
     */
    public void setInvoiceSort(InvoiceSortEnum value) {
        this.invoiceSort = value;
    }

    /**
     * 获取taxNoType属性的值。
     * 
     * @return
     *     possible object is
     *     {@link TaxNoTypeEnum }
     *     
     */
    public TaxNoTypeEnum getTaxNoType() {
        return taxNoType;
    }

    /**
     * 设置taxNoType属性的值。
     * 
     * @param value
     *     allowed object is
     *     {@link TaxNoTypeEnum }
     *     
     */
    public void setTaxNoType(TaxNoTypeEnum value) {
        this.taxNoType = value;
    }

    /**
     * 获取invoiceType属性的值。
     * 
     * @return
     *     possible object is
     *     {@link InvoiceTypeEnum }
     *     
     */
    public InvoiceTypeEnum getInvoiceType() {
        return invoiceType;
    }

    /**
     * 设置invoiceType属性的值。
     * 
     * @param value
     *     allowed object is
     *     {@link InvoiceTypeEnum }
     *     
     */
    public void setInvoiceType(InvoiceTypeEnum value) {
        this.invoiceType = value;
    }

    /**
     * 获取payManType属性的值。
     * 
     * @return
     *     possible object is
     *     {@link PayManTypeEnum }
     *     
     */
    public PayManTypeEnum getPayManType() {
        return payManType;
    }

    /**
     * 设置payManType属性的值。
     * 
     * @param value
     *     allowed object is
     *     {@link PayManTypeEnum }
     *     
     */
    public void setPayManType(PayManTypeEnum value) {
        this.payManType = value;
    }

    /**
     * 获取payMan属性的值。
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getPayMan() {
        return payMan;
    }

    /**
     * 设置payMan属性的值。
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setPayMan(String value) {
        this.payMan = value;
    }

    /**
     * 获取taxID属性的值。
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getTaxID() {
        return taxID;
    }

    /**
     * 设置taxID属性的值。
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setTaxID(String value) {
        this.taxID = value;
    }

    /**
     * 获取bankName属性的值。
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getBankName() {
        return bankName;
    }

    /**
     * 设置bankName属性的值。
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setBankName(String value) {
        this.bankName = value;
    }

    /**
     * 获取bankID属性的值。
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getBankID() {
        return bankID;
    }

    /**
     * 设置bankID属性的值。
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setBankID(String value) {
        this.bankID = value;
    }

    /**
     * 获取subAreaCode属性的值。
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getSubAreaCode() {
        return subAreaCode;
    }

    /**
     * 设置subAreaCode属性的值。
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setSubAreaCode(String value) {
        this.subAreaCode = value;
    }

    /**
     * 获取subAreaName属性的值。
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getSubAreaName() {
        return subAreaName;
    }

    /**
     * 设置subAreaName属性的值。
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setSubAreaName(String value) {
        this.subAreaName = value;
    }

    /**
     * 获取zip属性的值。
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getZip() {
        return zip;
    }

    /**
     * 设置zip属性的值。
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setZip(String value) {
        this.zip = value;
    }

    /**
     * 获取provinceCode属性的值。
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getProvinceCode() {
        return provinceCode;
    }

    /**
     * 设置provinceCode属性的值。
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setProvinceCode(String value) {
        this.provinceCode = value;
    }

    /**
     * 获取provinceName属性的值。
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getProvinceName() {
        return provinceName;
    }

    /**
     * 设置provinceName属性的值。
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setProvinceName(String value) {
        this.provinceName = value;
    }

    /**
     * 获取cityCode属性的值。
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCityCode() {
        return cityCode;
    }

    /**
     * 设置cityCode属性的值。
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCityCode(String value) {
        this.cityCode = value;
    }

    /**
     * 获取cityName属性的值。
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCityName() {
        return cityName;
    }

    /**
     * 设置cityName属性的值。
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCityName(String value) {
        this.cityName = value;
    }

    /**
     * 获取countyCode属性的值。
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCountyCode() {
        return countyCode;
    }

    /**
     * 设置countyCode属性的值。
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCountyCode(String value) {
        this.countyCode = value;
    }

    /**
     * 获取countyName属性的值。
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCountyName() {
        return countyName;
    }

    /**
     * 设置countyName属性的值。
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCountyName(String value) {
        this.countyName = value;
    }

    /**
     * 获取address属性的值。
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getAddress() {
        return address;
    }

    /**
     * 设置address属性的值。
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setAddress(String value) {
        this.address = value;
    }

    /**
     * 获取phone属性的值。
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getPhone() {
        return phone;
    }

    /**
     * 设置phone属性的值。
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setPhone(String value) {
        this.phone = value;
    }

    /**
     * 获取isShow属性的值。
     * 
     * @return
     *     possible object is
     *     {@link TrueFalseEnum }
     *     
     */
    public TrueFalseEnum getIsShow() {
        return isShow;
    }

    /**
     * 设置isShow属性的值。
     * 
     * @param value
     *     allowed object is
     *     {@link TrueFalseEnum }
     *     
     */
    public void setIsShow(TrueFalseEnum value) {
        this.isShow = value;
    }

    /**
     * 获取isDefault属性的值。
     * 
     * @return
     *     possible object is
     *     {@link TrueFalseEnum }
     *     
     */
    public TrueFalseEnum getIsDefault() {
        return isDefault;
    }

    /**
     * 设置isDefault属性的值。
     * 
     * @param value
     *     allowed object is
     *     {@link TrueFalseEnum }
     *     
     */
    public void setIsDefault(TrueFalseEnum value) {
        this.isDefault = value;
    }

    /**
     * 获取processStatus属性的值。
     * 
     * @return
     *     possible object is
     *     {@link ProcessStatus }
     *     
     */
    public ProcessStatus getProcessStatus() {
        return processStatus;
    }

    /**
     * 设置processStatus属性的值。
     * 
     * @param value
     *     allowed object is
     *     {@link ProcessStatus }
     *     
     */
    public void setProcessStatus(ProcessStatus value) {
        this.processStatus = value;
    }

    /**
     * 获取operationType属性的值。
     * 
     * @return
     *     possible object is
     *     {@link OperationType }
     *     
     */
    public OperationType getOperationType() {
        return operationType;
    }

    /**
     * 设置operationType属性的值。
     * 
     * @param value
     *     allowed object is
     *     {@link OperationType }
     *     
     */
    public void setOperationType(OperationType value) {
        this.operationType = value;
    }

    /**
     * 获取approvalStatus属性的值。
     * 
     * @return
     *     possible object is
     *     {@link MemberInvoiceStatusEnum }
     *     
     */
    public MemberInvoiceStatusEnum getApprovalStatus() {
        return approvalStatus;
    }

    /**
     * 设置approvalStatus属性的值。
     * 
     * @param value
     *     allowed object is
     *     {@link MemberInvoiceStatusEnum }
     *     
     */
    public void setApprovalStatus(MemberInvoiceStatusEnum value) {
        this.approvalStatus = value;
    }

    /**
     * 获取soldToCode属性的值。
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getSoldToCode() {
        return soldToCode;
    }

    /**
     * 设置soldToCode属性的值。
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setSoldToCode(String value) {
        this.soldToCode = value;
    }

}
