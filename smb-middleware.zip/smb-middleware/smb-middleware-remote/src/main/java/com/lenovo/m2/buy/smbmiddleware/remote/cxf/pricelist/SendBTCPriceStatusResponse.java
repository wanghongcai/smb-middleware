
package com.lenovo.m2.buy.smbmiddleware.remote.cxf.pricelist;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>anonymous complex type的 Java 类。
 * 
 * <p>以下模式片段指定包含在此类中的预期内容。
 * 
 * <pre>
 * &lt;complexType&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="SendBTCPriceStatusResult" type="{http://tempuri.org/}PriceResult" minOccurs="0"/&gt;
 *       &lt;/sequence&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "", propOrder = {
    "sendBTCPriceStatusResult"
})
@XmlRootElement(name = "SendBTCPriceStatusResponse")
public class SendBTCPriceStatusResponse {

    @XmlElement(name = "SendBTCPriceStatusResult")
    protected PriceResult sendBTCPriceStatusResult;

    /**
     * 获取sendBTCPriceStatusResult属性的值。
     * 
     * @return
     *     possible object is
     *     {@link PriceResult }
     *     
     */
    public PriceResult getSendBTCPriceStatusResult() {
        return sendBTCPriceStatusResult;
    }

    /**
     * 设置sendBTCPriceStatusResult属性的值。
     * 
     * @param value
     *     allowed object is
     *     {@link PriceResult }
     *     
     */
    public void setSendBTCPriceStatusResult(PriceResult value) {
        this.sendBTCPriceStatusResult = value;
    }

}
