
package com.lenovo.m2.buy.smbmiddleware.remote.cxf.member;

import javax.xml.bind.annotation.XmlEnum;
import javax.xml.bind.annotation.XmlEnumValue;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>InvoiceSortEnum的 Java 类。
 * 
 * <p>以下模式片段指定包含在此类中的预期内容。
 * <p>
 * <pre>
 * &lt;simpleType name="InvoiceSortEnum"&gt;
 *   &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string"&gt;
 *     &lt;enumeration value="zz"/&gt;
 *     &lt;enumeration value="zp"/&gt;
 *     &lt;enumeration value="gr"/&gt;
 *     &lt;enumeration value="wu"/&gt;
 *   &lt;/restriction&gt;
 * &lt;/simpleType&gt;
 * </pre>
 * 
 */
@XmlType(name = "InvoiceSortEnum")
@XmlEnum
public enum InvoiceSortEnum {

    @XmlEnumValue("zz")
    ZZ("zz"),
    @XmlEnumValue("zp")
    ZP("zp"),
    @XmlEnumValue("gr")
    GR("gr"),
    @XmlEnumValue("wu")
    WU("wu");
    private final String value;

    InvoiceSortEnum(String v) {
        value = v;
    }

    public String value() {
        return value;
    }

    public static InvoiceSortEnum fromValue(String v) {
        for (InvoiceSortEnum c: InvoiceSortEnum.values()) {
            if (c.value.equals(v)) {
                return c;
            }
        }
        throw new IllegalArgumentException(v);
    }

}
