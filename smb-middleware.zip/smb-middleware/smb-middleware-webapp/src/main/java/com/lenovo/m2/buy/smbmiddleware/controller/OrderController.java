package com.lenovo.m2.buy.smbmiddleware.controller;

import com.lenovo.m2.arch.framework.domain.RemoteResult;
import com.lenovo.m2.buy.smbmiddleware.remote.OpenPlatUtil;
import com.lenovo.m2.buy.smbmiddleware.util.Constants;
import com.lenovo.m2.buy.smbmiddleware.util.JsonUtil;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import javax.servlet.http.HttpServletRequest;

/**
 * Created by wangrq1 on 2016/7/28.
 */

@Controller
public class OrderController extends BaseController{


    @Autowired
    private OpenPlatUtil openPlatUtil;

    @RequestMapping(value = "/api/order/updatestatus.jhtm", produces = "application/json; charset=utf-8")
    @ResponseBody
    public String orderStateUpdate(HttpServletRequest request){
        String json = getRequestBody(request);

        try {
            return openPlatUtil.invokeOpenPlat(Constants.METHOD_ORDER_STATE_UPDATE, json);
        } catch (Exception e) {
            e.printStackTrace();
            RemoteResult result = new RemoteResult(false);
            result.setResultMsg(e.getMessage());
            return JsonUtil.toJson(result);
        }

    }


    @RequestMapping(value = "/api/logistics/updateLogistics.jhtm", produces = "application/json; charset=utf-8")
    @ResponseBody
    public String updateLogistics(HttpServletRequest request){
        String json = getRequestBody(request);
        try {
            return openPlatUtil.invokeOpenPlat(Constants.METHOD_ORDER_LOGISTICS, json);
        } catch (Exception e) {
            e.printStackTrace();
            RemoteResult result = new RemoteResult(false);
            result.setResultMsg(e.getMessage());
            return JsonUtil.toJson(result);
        }

    }
    
    
    @RequestMapping(value = "/api/logistics/updateLogisticsMessage.jhtm", produces = "application/json; charset=utf-8")
    @ResponseBody
    public String updateLogisticsMessage(HttpServletRequest request){
        String json = getRequestBody(request);

        try {
            return openPlatUtil.invokeOpenPlat(Constants.METHOD_ORDER_LOGISTICS_MESSAGE, json);
        } catch (Exception e) {
            e.printStackTrace();
            RemoteResult result = new RemoteResult(false);
            result.setResultMsg(e.getMessage());
            return JsonUtil.toJson(result);
        }

    }
    
    

    @RequestMapping(value = "/api/order/getcontracturl.jhtm", produces = "application/json; charset=utf-8")
    @ResponseBody
    public String getContractUrl(HttpServletRequest request){
        String json = getRequestBody(request);
        try {
            return openPlatUtil.invokeOpenPlat(Constants.METHOD_ORDER_LOGISTICS, json);
        } catch (Exception e) {
            e.printStackTrace();
            RemoteResult result = new RemoteResult(false);
            result.setResultMsg(e.getMessage());
            return JsonUtil.toJson(result);
        }
    }


}
