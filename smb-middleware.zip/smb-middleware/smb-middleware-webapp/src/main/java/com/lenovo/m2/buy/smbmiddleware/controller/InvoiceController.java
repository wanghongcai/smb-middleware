package com.lenovo.m2.buy.smbmiddleware.controller;

import com.lenovo.m2.arch.framework.domain.RemoteResult;
import com.lenovo.m2.buy.smbmiddleware.domain.InvoiceShop;
import com.lenovo.m2.buy.smbmiddleware.manager.InvoiceManager;
import com.lenovo.m2.buy.smbmiddleware.util.JsonUtil;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;

/**
 * Created by wangrq1 on 2016/7/26.
 */
@Controller
public class InvoiceController extends BaseController{

    private static Logger log = LoggerFactory.getLogger(InvoiceController.class);

    @Resource
    private InvoiceManager invoiceManager;

    @RequestMapping(value = "/api/invoice/synInvoice.jhtm", produces = "application/json; charset=utf-8")
    @ResponseBody
    public String invoiceSync(HttpServletRequest request){

        String method = getMethod(request);
        String body   = getRequestBody(request);

        try{
            return invoiceManager.syncInvoiceAdd(body);
        }catch (Exception e){
            log.error("", e);
            RemoteResult result = new RemoteResult(false);
            result.setResultMsg(e.getMessage());
            return JsonUtil.toJson(result);
        }

    }
    
    
    @RequestMapping(value = "/api/invoice/notify.jhtm", produces = "application/json; charset=utf-8")
    @ResponseBody
    public String notify(HttpServletRequest request){
        try{
        	String id= request.getParameter("id");
        	InvoiceShop shop = invoiceManager.getById(id);
        	if(shop == null){
        		return "null";
        	}
            boolean r = invoiceManager.notifySmbInvoiceAdd(shop);
            return String.valueOf(r);
        }catch (Exception e){
            log.error("", e);
            RemoteResult result = new RemoteResult(false);
            result.setResultMsg(e.getMessage());
            return JsonUtil.toJson(result);
        }

    }
    

}
