package com.lenovo.m2.buy.smbmiddleware.controller;

import java.util.Map;

import javax.servlet.http.HttpServletRequest;

import com.lenovo.m2.buy.smbmiddleware.remote.OpenPlatUtil;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import com.lenovo.m2.arch.framework.domain.RemoteResult;
import com.lenovo.m2.buy.smbmiddleware.remote.MemberInfoRemote;
import com.lenovo.m2.buy.smbmiddleware.util.Constants;
import com.lenovo.m2.buy.smbmiddleware.util.JsonUtil;

@Controller
public class ContractController extends BaseController{
	

	@Autowired
	private MemberInfoRemote memberInfoRemote;

	@Autowired
	private OpenPlatUtil openPlatUtil;

	/**
	 * SMB新增合同
	 * @param request
	 * @return
	 */
	    @RequestMapping(value = "/api/contract/addContractInfo.jhtm", produces = "application/json; charset=utf-8")
	    @ResponseBody
	    public String addContractInfo(HttpServletRequest request){

	        String body   = getRequestBody(request);

	        try{
	        	Map map = JsonUtil.fromJson(body, Map.class);
	        	String memberCode = String.valueOf(map.get("memberCode"));
	            String id = memberInfoRemote.findIdByThirdId(memberCode);
	            map.put("userId", id);
	            return openPlatUtil.invokeOpenPlat(Constants.METHOD_CONTRACT_ADD, JsonUtil.toJson(map));
	        }catch (Exception e){
	            log.error("", e);
	            RemoteResult result = new RemoteResult(false);
	            result.setResultMsg(e.getMessage());
	            return JsonUtil.toJson(result);
	        }

	    }


	/**
	 * SMB获取合同
	 * @param request
	 * @return
	 */
		@RequestMapping(value = "/api/contract/getContractInfo.jhtm", produces = "application/json; charset=utf-8")
	    @ResponseBody
	    public String getContractInfo(HttpServletRequest request){
	        String body   = getRequestBody(request);
	        try{
	        	Map map = JsonUtil.fromJson(body, Map.class);
	        	String memberCode = String.valueOf(map.get("memberCode"));
	            String id = memberInfoRemote.findIdByThirdId(memberCode);
	            map.put("userId", id);
	            return openPlatUtil.invokeOpenPlat(Constants.METHOD_CONTRACT_QUERY, JsonUtil.toJson(map));
	        }catch (Exception e){
	            log.error("", e);
	            RemoteResult result = new RemoteResult(false);
	            result.setResultMsg(e.getMessage());
	            return JsonUtil.toJson(result);
	        }
	    }
	    
}
