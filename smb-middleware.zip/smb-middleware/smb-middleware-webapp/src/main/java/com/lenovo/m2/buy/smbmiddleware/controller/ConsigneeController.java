package com.lenovo.m2.buy.smbmiddleware.controller;

import com.lenovo.m2.arch.framework.domain.RemoteResult;
import com.lenovo.m2.buy.smbmiddleware.domain.Memberaddrs;
import com.lenovo.m2.buy.smbmiddleware.enums.GlobalErrorMessage;
import com.lenovo.m2.buy.smbmiddleware.manager.AddressManager;
import com.lenovo.m2.buy.smbmiddleware.util.JsonUtil;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import java.util.HashMap;
import java.util.Map;

/**
 * Created by wangrq1 on 2016/7/26.
 */
@Controller
public class ConsigneeController extends BaseController {

    @Resource
    private AddressManager addressManager;


    @RequestMapping(value = "/api/consignee/adddeliver.jhtm", produces = "application/json; charset=utf-8")
    @ResponseBody
    public String addDeliver(HttpServletRequest request) {

        String body = getRequestBody(request);
        log.info("addDeliver json={}", body);

        //调用开放平台 添加地址
        //获取返回结果 如果成功则将返回id连同 请求参数一同返回
        try {
            String res = addressManager.syncAddressAdd(body);
            return res;
        } catch (Exception e) {
            RemoteResult rr = new RemoteResult(false);
            rr.setResultCode(GlobalErrorMessage.ERROR_SYSTEM_ERROR.getCode());
            rr.setResultMsg(e.getMessage());
            return JsonUtil.toJson(rr);
        }
    }

    @RequestMapping(value = "/api/consignee/modifydeliver.jhtm", produces = "application/json; charset=utf-8")
    @ResponseBody
    public String modifyDeliver(HttpServletRequest request) {

        String method = getMethod(request);
        String body = getRequestBody(request);

        //根据uuid查询id
        Map map = JsonUtil.fromJson(body, Map.class);
        String deliverId = (String) map.get("deliverId");

        Map getIdParam = new HashMap();
        getIdParam.put("uuid", deliverId);
        try {
            return addressManager.syncAddressModify(body);
        } catch (Exception e) {
            RemoteResult rr = new RemoteResult(false);
            rr.setResultCode(GlobalErrorMessage.ERROR_SYSTEM_ERROR.getCode());
            rr.setResultMsg(GlobalErrorMessage.ERROR_SYSTEM_ERROR.getCommon());
            return JsonUtil.toJson(rr);
        }

    }


    @RequestMapping("/api/consignee/deletedeliver.jhtm")
    @ResponseBody
    public String deletedeliver(HttpServletRequest request) {

        String method = getMethod(request);
        String body = getRequestBody(request);

        return null;
    }

    
    @RequestMapping(value = "/api/consignee/notify.jhtm", produces = "application/json; charset=utf-8")
    @ResponseBody
    public String notify(String id, String userId, String type) {
        //根据uuid查询id
        try {
        	Memberaddrs address = addressManager.getById(userId, type, id);
        	if(address == null){
        		return "null";
        	}
        	boolean r = addressManager.notifySmbAddressAdd(address);
        	return String.valueOf(r);
        } catch (Exception e) {
            RemoteResult rr = new RemoteResult(false);
            rr.setResultCode(GlobalErrorMessage.ERROR_SYSTEM_ERROR.getCode());
            rr.setResultMsg(GlobalErrorMessage.ERROR_SYSTEM_ERROR.getCommon());
            return JsonUtil.toJson(rr);
        }
    }
    

}
