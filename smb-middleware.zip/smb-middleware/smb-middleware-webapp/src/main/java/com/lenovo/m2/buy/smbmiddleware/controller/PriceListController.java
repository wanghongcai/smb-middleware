package com.lenovo.m2.buy.smbmiddleware.controller;

import com.lenovo.m2.arch.framework.domain.RemoteResult;
import com.lenovo.m2.buy.smbmiddleware.manager.AddressManager;
import com.lenovo.m2.buy.smbmiddleware.manager.InvoiceManager;
import com.lenovo.m2.buy.smbmiddleware.remote.MemberInfoRemote;
import com.lenovo.m2.buy.smbmiddleware.remote.OpenPlatUtil;
import com.lenovo.m2.buy.smbmiddleware.util.Constants;
import com.lenovo.m2.buy.smbmiddleware.util.JsonUtil;

import org.apache.commons.lang.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import java.util.Map;

/**
 * Created by wangrq1 on 2016/7/28.
 */
@Controller
public class PriceListController extends BaseController{

    private static Logger log = LoggerFactory.getLogger(PriceListController.class);

    @Resource
    private MemberInfoRemote memberInfoRemote;
    @Resource
    private InvoiceManager invoiceManager;
    
    @Resource
    private AddressManager addressManager;

    @Autowired
    private OpenPlatUtil openPlatUtil;


    @RequestMapping(value = "/api/pricelist/add.jhtm" , produces = "application/json; charset=utf-8")
    @ResponseBody
    public String syncPriceList(HttpServletRequest request){

        String json = getRequestBody(request);

        try {
        	Map map = JsonUtil.fromJson(json, Map.class);
            String memberCode = String.valueOf(map.get("memberCode"));
            String id = memberInfoRemote.findIdByThirdId(memberCode);
            map.put("userId", id);
            map.put("unique", id);
            map.put("lenovoId", id);
            map.put("memberNo", id);
            map.put("terminal", "1");
            json = JsonUtil.toJson(map);
            json = StringUtils.replaceChars(json, '+', ' ');
            json = StringUtils.replaceChars(json, '%', ' ');
            json = StringUtils.replaceChars(json, '&', ' ');
            json = StringUtils.replaceChars(json, '?', ' ');
//            json = StringUtils.replaceChars(json, '/', ' ');
            
            return openPlatUtil.invokeOpenPlat(Constants.METHOD_PRICE_LIST_ADD, json);
        } catch (Exception e) {
            log.error("", e);
            RemoteResult result = new RemoteResult(false);
            result.setResultMsg(e.getMessage());

            return JsonUtil.toJson(result);
        }


    }




    @RequestMapping(value = "/api/pricelist/manualorder.jhtm", produces = "application/json; charset=utf-8")
    @ResponseBody
    public String manualorder(HttpServletRequest request){

        String json = getRequestBody(request);
        try {
        	Map map = JsonUtil.fromJson(json, Map.class);
            return openPlatUtil.invokeOpenPlat(Constants.METHOD_PRICE_LIST_MANUALORDER, JsonUtil.toJson(map));
        } catch (Exception e) {
        	log.error("", e);
            RemoteResult result = new RemoteResult(false);
            result.setResultMsg(e.getMessage());
            return JsonUtil.toJson(result);
        }

    }
    
    @RequestMapping(value = "/api/pricelist/updateToOrdered.jhtm", produces = "application/json; charset=utf-8")
    @ResponseBody
    public String updateToOrdered(HttpServletRequest request){

        String json = getRequestBody(request);
        try {
        	Map map = JsonUtil.fromJson(json, Map.class);
        	String memberCode = String.valueOf(map.get("memberCode"));
            String id = memberInfoRemote.findIdByThirdId(memberCode);
            map.put("userId", id);
            return openPlatUtil.invokeOpenPlat(Constants.METHOD_PRICE_LIST_UPDATETO_ORDERED, JsonUtil.toJson(map));
        } catch (Exception e) {
        	log.error("", e);
            RemoteResult result = new RemoteResult(false);
            result.setResultMsg(e.getMessage());
            return JsonUtil.toJson(result);
        }

    }

    
    
    @RequestMapping(value = "/api/pricelist/queryPdfUrl.jhtm", produces = "application/json; charset=utf-8")
    @ResponseBody
    public String queryPdfUrl(HttpServletRequest request){

        String json = getRequestBody(request);
        try {
        	Map map = JsonUtil.fromJson(json, Map.class);
        	String memberCode = String.valueOf(map.get("memberCode"));
            String id = memberInfoRemote.findIdByThirdId(memberCode);
            map.put("userId", id);
            return openPlatUtil.invokeOpenPlat(Constants.METHOD_PRICE_LIST_QUERY_PDFURL, JsonUtil.toJson(map));
        } catch (Exception e) {
        	log.error("", e);
            RemoteResult result = new RemoteResult(false);
            result.setResultMsg(e.getMessage());
            return JsonUtil.toJson(result);
        }

    }
    
    
    
    @RequestMapping(value = "/api/test.jhtm", produces = "application/json; charset=utf-8")
    @ResponseBody
    public String test(){
    	return "success";
    }
    


	public static void main(String[] args) {
		String json = "1+2";	
		json = StringUtils.replaceChars(json, '+', ' ');
		
		json = "\u0026Hsss";
//		json.replaceAll("ssss\u0026", "");
		
		json = StringUtils.replaceChars(json, '&', ' ');
		
		System.out.println(json);
	}
    
    
}
