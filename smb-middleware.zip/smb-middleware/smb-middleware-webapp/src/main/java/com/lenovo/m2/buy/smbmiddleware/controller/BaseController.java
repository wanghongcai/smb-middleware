package com.lenovo.m2.buy.smbmiddleware.controller;

import com.lenovo.m2.buy.smbmiddleware.util.CustomizedPropertyConfigurer;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import javax.servlet.http.HttpServletRequest;
import java.io.BufferedReader;
import java.io.IOException;

/**
 * Created by wangrq1 on 2016/7/21.
 */
public abstract class BaseController {

    protected Logger log = LoggerFactory.getLogger(getClass());


    protected  String getRequestBody(HttpServletRequest request){
        StringBuilder sb=  new StringBuilder();

        try {
            BufferedReader br = request.getReader();
            String line = null;
            while ((line = br.readLine()) != null) {
                sb.append(line);
            }
        } catch (IOException e) {
            log.error("", e);
        }

        String uri = request.getRequestURI();
        String body = sb.toString();

        log.info("uri={}, body={}", uri, body);
        return body;
    }


    protected String getMethod(HttpServletRequest request){
        String uri = request.getRequestURI();
        return CustomizedPropertyConfigurer.getContextProperty(uri);
    }

}
