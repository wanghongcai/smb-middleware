package com.lenovo.smbmiddleware.test.dotnet;

/**
 * Created by wangrq1 on 2016/8/1.
 */
public class TestInvoice {
}
