package com.lenovo.smbmiddleware.test;

import com.lenovo.m2.buy.smbmiddleware.remote.OpenPlatUtil;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import com.lenovo.m2.buy.smbmiddleware.remote.MemberInfoRemote;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations = {"classpath:applicationContext-*.xml"})
public class TestMember {
	
	static String SMB_GROUP_ID = "C0002";
	
	@Autowired
	private MemberInfoRemote memberInfoRemote;

	@Autowired
	private OpenPlatUtil openPlatUtil;


	@Test
	public void test(){
		  
		
		
		
	}
	
	@Test
	public void testFindByThirdId() throws Exception{
		
		
		String id = memberInfoRemote.findIdByThirdId("SMB251223000014");
		System.out.println(id);
		
		
	}

}
