package com.lenovo.smbmiddleware.test;

import com.lenovo.m2.buy.smbmiddleware.util.HttpUtil;
import com.lenovo.m2.buy.smbmiddleware.util.JsonUtil;

import org.apache.commons.collections.map.HashedMap;
import org.junit.Assert;
import org.junit.Test;

import java.io.UnsupportedEncodingException;
import java.net.URLEncoder;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * Created by wangrq1 on 2016/7/28.
 */

//@RunWith(SpringJUnit4ClassRunner.class)
//@ContextConfiguration(locations = {"classpath:applicationContext-*.xml"})
public class TestPriceList {

//	@Autowired
//	private PriceListManager priceListManager;
	
	
	@Test
	public void testSyncPriceList() {
		 String url = "http://smbfront17.lenovouat.com/api/pricelist/add.jhtm";
		
//		String url = "http://smbfront.17.lenovo.com.cn/api/pricelist/add.jhtm";

//		String url = "http://cart.lenovouat.cn/api/pricelist/add.jhtm";
		Map<String, Object> map = new HashMap();
		map.put("terminal", 1);
		map.put("memberCode", "SMB2160830000002");
		map.put("dealNo", "SMB1234128111195");
		map.put("expireDate", "2018-09-21 10:23:23");
		map.put("saleOrganization", "10057830455");
		map.put("itcode", "wangrq1");
		map.put("lenovoId", "10057830455");
		map.put("totalPrice", "10000");

		map.put("payee", "联想北京");
		map.put("openingBank", "北京银行");
		map.put("accountNumber", "866180558810001800800");
		map.put("isCreatedOrder", "0");
		map.put("auditFile", "");
		map.put("buyerName", "张三");
		map.put("buyerAddress", "上地西路6号");
		map.put("buyerZip", "100083");
		map.put("buyerPhone", "18001141691");

		map.put("customManager", "销售1");
		map.put("cmPhone", "18001141691");

		map.put("cmFax", "销售1");
		
		map.put("buyerContacts", "李四");
		
		map.put("buyerTele", "010-82332043");

		List<Map> details = new ArrayList<>();
		Map<String, Object> good1 = new HashMap<>();
		good1.put("gcode", "53583");
		good1.put("materialCode", "yetest003");
		good1.put("productGroupNo", "50");
		good1.put("productName", "ye商城多规格");
		good1.put("applyNumber", "5");
		good1.put("goodsType", "0");
		good1.put("goodsCategory", "5");
		good1.put("applyPrice", "0.01a");
		
		
		Map<String, Object> good2 = new HashMap<>();
		good2.put("gcode", "53591");
		good2.put("materialCode", "20EHA00ECD");
		good2.put("productGroupNo", "84");
		good2.put("productName", "17促销副品");
		good2.put("applyNumber", "1");
		good2.put("goodsType", "2");
		good2.put("goodsCategory", "1");
		good2.put("applyPrice", "500");

		
//		details.add(good1);
		details.add(good2);
		map.put("details", JsonUtil.toJson(details));

		System.out.println(JsonUtil.toJson(details));

		String body = JsonUtil.toJson(map);

	
		
		System.out.println(body);
		try {
			String res = HttpUtil.executeHttpPostType(url, body, "application/json; charset=utf-8");
			System.out.println(res);
		} catch (Exception e) {
			e.printStackTrace();
		}

	}

	

	@Test
	public void testManualOrder() {
//		String url = "http://cart.lenovouat.cn/api/pricelist/manualorder.jhtm";
		String url = "http://smbfront.17.lenovouat.cn/api/pricelist/manualorder.jhtm";
		Map<String, Object> map = new HashMap();
		map.put("terminal", 1);
//		map.put("dealNo", "SMB1234128174");
		map.put("dealNo", "SMBP70110000B");

		map.put("itCode", "b2ctest");

		map.put("payMan", "王瑞奇");
		map.put("payManType", "1");
		map.put("payType", "1");
		map.put("invoiceId", "5f5d83e1-31b9-426e-863f-edf973ed16b6");
		map.put("deliverAddressId", "3d9884f2-5854-4003-aac2-38888123c3e1");
		map.put("invoiceAddressId", "3a4566ef-17b8-4422-92ed-d0bc9d171c54");
		map.put("userName", "wangrq1");
		
		//收货地址
//		Map<String, Object> shAddress = new HashMap<>();
//		shAddress.put("deliverName", "王瑞奇");
//		shAddress.put("deliverProvince", "北京");
//		shAddress.put("deliverCity", "北京");
//		shAddress.put("deliverCounty", "海淀区");
//		shAddress.put("deliverTowerShip", "回龙观");
//		shAddress.put("deliverStreet", "上地西路");
//		shAddress.put("zip", "100083");
//		shAddress.put("deliverMobile", "18001141691");
//		shAddress.put("deliverTele", "010-82332043");
//		//收票地址
//		Map<String, Object> spAddress = new HashMap<>();
//		shAddress.put("deliverName", "王瑞奇");
//		shAddress.put("deliverProvince", "北京");
//		shAddress.put("deliverCity", "北京");
//		shAddress.put("deliverCounty", "海淀区");
//		shAddress.put("deliverTowerShip", "回龙观");
//		shAddress.put("deliverStreet", "上地西路");
//		shAddress.put("zip", "100083");
//		shAddress.put("deliverMobile", "18001141691");
//		shAddress.put("deliverTele", "010-82332043");
//		
//		map.put("deliverAddress", shAddress);
//		map.put("invoiceAddress", spAddress);

		String body = JsonUtil.toJson(map);

		try {
			String res = HttpUtil.executeHttpPostType(url, body, "application/json; charset=utf-8");
			System.out.println(res);
			
		} catch (Exception e) {
			e.printStackTrace();
			Assert.fail();
		}
	}
	
	
	
	@Test
	public void testManualOrder2() {
		
		
//		String url = "http://cart.lenovouat.cn/api/pricelist/manualorder.jhtm";
		String url = "http://smbfront.17.lenovo.com.cn/api/pricelist/manualorder.jhtm";
		Map<String, Object> map = new HashMap();
		map.put("terminal", 1);
		map.put("dealNo", "SMBP6102500021111");

		map.put("itCode", "autotest");

		map.put("payMan", "王瑞奇");
		map.put("payManType", "0");
		map.put("payType", "3");
		map.put("invoiceId", "b40d013d-16fe-4610-8e00-c58c74a93ad3");
		map.put("deliverAddressId", "4d171e06-a09e-4e91-b359-f7137ee2538c");
		map.put("invoiceAddressId", "3587b681-67b6-4298-9eaa-727b74654a5d");
		map.put("userName", "wangrq1");

		String body = JsonUtil.toJson(map);

		try {
			String res = HttpUtil.executeHttpPostType(url, body, "application/json; charset=utf-8");
			System.out.println(res);
			
		} catch (Exception e) {
			e.printStackTrace();
			Assert.fail();
		}
	}


	@Test
	public void testDirectAddPriceList() {

		String url = "https://buy.lenovo.com.cn/api/pricelist/add.jhtm";
		Map<String, Object> map = mockProductData();

		System.out.println(map);

		String body = mapToPostData(map);

		try {
			//application/x-www-form-urlencoded
			String res = HttpUtil.postStr(url, map);
//			url = url + '?' + body;
//			String res = HttpUtil.getStr(url);
			System.out.println(res);

		} catch (Exception e) {
			e.printStackTrace();
			Assert.fail();
		}
	}





	/**
	 * 直连fps测试
	 */
	@Test
	public void testDirectManualOrder() {


//		String url = "http://cart.lenovouat.cn/api/pricelist/manualorder.jhtm";
		String url = "https://buy.lenovo.com.cn/api/pricelist/manualorder.jhtm";
		Map<String, Object> map = new HashMap();
		map.put("terminal", "1");
		map.put("dealNo", "SMBP6102500021111");
		map.put("payMan", "王瑞奇");
		map.put("payManType", "0");
		map.put("payType", "3");
		map.put("invoiceId", "b40d013d-16fe-4610-8e00-c58c74a93ad3");
		map.put("deliverAddressId", "4d171e06-a09e-4e91-b359-f7137ee2538c");
		map.put("invoiceAddressId", "3587b681-67b6-4298-9eaa-727b74654a5d");
		map.put("itCode", "autotest");
		map.put("userName", "wangrq1");



		String body = mapToPostData(map);

		try {
			//application/x-www-form-urlencoded
			String res = HttpUtil.postStr(url, map);
//			url = url + '?' + body;
//			String res = HttpUtil.getStr(url);
			System.out.println(res);

		} catch (Exception e) {
			e.printStackTrace();
			Assert.fail();
		}
	}



	@Test
	public void testCTOPriceList(){
		
		
		String url = "http://smbfront.17.lenovouat.cn/api/pricelist/add.jhtm";
		Map<String, Object> map = new HashMap();
		map.put("terminal", 1);
		map.put("memberCode", "SMB2160811000036");
		map.put("dealNo", "SMB1234128180");
		map.put("expireDate", "2018-09-09 10:23:23");
		map.put("saleOrganization", "10057830455");
		map.put("itcode", "wangrq1");
		map.put("lenovoId", "10057830455");
		map.put("totalPrice", "10000");

		map.put("payee", "联想北京");
		map.put("openingBank", "北京银行");
		map.put("accountNumber", "866180558810001800800");
		map.put("isCreatedOrder", "0");
		map.put("auditFile", "");
		map.put("buyerName", "张三");
		map.put("buyerAddress", "上地西路6号");
		map.put("buyerZip", "100083");
		map.put("buyerPhone", "18001141691");

		map.put("customManager", "销售1");
		map.put("cmPhone", "18001141691");

		map.put("cmFax", "销售1");
		
		map.put("buyerContacts", "李四");
		
		map.put("buyerTele", "010-82332043");

		List<Map> details = new ArrayList<>();
		Map<String, Object> good1 = new HashMap<>();
		good1.put("gcode", "51479");
		good1.put("materialCode", "yetest003");
		good1.put("productGroupNo", "50");
		good1.put("productName", "ye商城多   * /  (规格)");
		good1.put("applyNumber", "5");
		good1.put("goodsType", "2");
		good1.put("goodsCategory", "5");
		good1.put("applyPrice", "500");

		String accessoryStr = "[    {        \"name\": \"NBCPUCP\",        \"value\": \"I5-5200U\",        \"isSee\": 1,        \"language\": 0    },    {        \"name\": \"NBHDD\",        \"value\": \"500G 9.5/7mm 5400RPM\",        \"isSee\": 1,        \"language\": 0    },    {        \"name\": \"NBRAM\",        \"value\": \"4G(1*4GBDDRIIIL1600)\",        \"isSee\": 1,        \"language\": 0    },    {        \"name\": \"NBVGA\",        \"value\": \"ATI EXO PRO R5 M330 DDR3L 2G\",        \"isSee\": 1,        \"language\": 0    },    {        \"name\": \"NBODD\",        \"value\": \"9.0mm SUPER MULTI(TRAY IN)\",        \"isSee\": 1,        \"language\": 0    },    {        \"name\": \"NBWLAN\",        \"value\": \"Intel 3160 1x1 AC BT4.0\",        \"isSee\": 1,        \"language\": 0    },    {        \"name\": \"NBOS\",        \"value\": \"WIN8.1 PRC\",        \"isSee\": 1,        \"language\": 0    },    {        \"name\": \"NBLCD\",        \"value\": \"14.0 HD TN AG(FLAT)\",        \"isSee\": 1,        \"language\": 0    },    {        \"name\": \"NBADAPTER\",        \"value\": \"BLACK 65W 3-PIN\",        \"isSee\": 1,        \"language\": 0    },    {        \"name\": \"NBBATTERY\",        \"value\": \"Black 4Cell 32WH\",        \"isSee\": 1,        \"language\": 0    },    {        \"name\": \"NBLANGUAGE\",        \"value\": \"Chinese\",        \"isSee\": 1,        \"language\": 0    },    {        \"name\": \"NBOFFICE\",        \"value\": \"OFFICE 2013 TRIAL\",        \"isSee\": 1,        \"language\": 0    },    {        \"name\": \"NBService1\",        \"value\": \"无延保服务选配\",        \"isSee\": 1,        \"language\": 0    },    {        \"name\": \"NBService2\",        \"value\": \"无安装验机\",        \"isSee\": 1,        \"language\": 0    },    {        \"name\": \"NBService4\",        \"value\": \"无意外保护选配\",        \"isSee\": 1,        \"language\": 0    }  ]";

		List<Map> accessorys = JsonUtil.readValuesAsArrayList(accessoryStr, Map.class);
//		Map<String, Object> accessory1 = new HashMap<>();
//		accessory1.put("name","规格1");
//		accessory1.put("value","1");
//		accessory1.put("isSee",1);
//		accessory1.put("language",0);
//		accessorys.add(accessory1);
//		
//		Map<String, Object> accessory2 = new HashMap<>();
//		accessory2.put("name","规格2");
//		accessory2.put("value","2");
//		accessory2.put("isSee",1);
//		accessory2.put("language",0);
//		accessorys.add(accessory2);
		
		good1.put("accessories",accessorys);
		
		
		details.add(good1);
		map.put("details", details);
		
		String body = JsonUtil.toJson(map);

		try {
			String res = HttpUtil.executeHttpPostType(url, body, "application/json; charset=utf-8");
			System.out.println(res);
		} catch (Exception e) {
			e.printStackTrace();
		}
		
	}
	
	
	
/*	@Test
	public void testUpdateStatus(){
		
		
		boolean ss= priceListManager.updateSmbStatus("SMB123412896");
		Assert.assertTrue(ss);
		
	}
	
	
	

	@Test
	public void pullOrderedStatus(){
		
				String dealNo = priceListManager.pullOrderedDealNo();
		
		System.out.println(dealNo);
		
		
	}*/



	@Test
	public void testSyncPriceListPurchase() throws UnsupportedEncodingException {
		String url = "http://cart.17.lenovouat.com/api/pricelist/add.jhtm";


		Map<String, Object> map = new HashMap();
		map.put("terminal", 1);
		map.put("dealNo", "SMBP704010004");
		map.put("expireDate", "2017-04-09 00:00:00");
		map.put("saleOrganization", "联想(北京)有限公司");
		map.put("itcode", "zhangxi15");
		map.put("lenovoId", "210567");
		map.put("totalPrice", "15200");

		map.put("payee", "联想(北京)有限公司");
		map.put("openingBank", "招商银行北京大屯路支行");
		map.put("accountNumber", "866180558810001800800");
		map.put("isCreatedOrder", "0");
		map.put("auditFile", "");
		map.put("buyerName", "庆阳海越农业有限公司");
		map.put("buyerAddress", "甘肃省庆阳市宁县焦村镇街上村");
		map.put("buyerZip", "730000");
		map.put("buyerPhone", "18291469010");

		map.put("customManager", "张玺");
		map.put("cmPhone", "15388216913");

		map.put("cmFax", "028-83877282");
		map.put("buyerContacts", "刘晓玲");
		map.put("buyerTele", "028-83877282");

//
//		List<Map> details = new ArrayList<>();
//		Map<String, Object> good1 = new HashMap<>();
//		good1.put("gcode", "90001798");
//		good1.put("materialCode", "90DSA0BPCD");
//		good1.put("productGroupNo", "03");
//		good1.put("productName", "启天M4600 H110");
//		good1.put("applyNumber", "4");
//		good1.put("goodsType", "2");
//		good1.put("applyPrice", "2990");



		String details = "[{\"gcode\":\"90001750\",\"materialCode\":\"10GYA03600\",\"productGroupNo\":\"03\",\"productName\":\"ThinkCentre M4600t H110\",\"applyNumber\":1,\"applyPrice\":3850.00,\"goodsType\":2,\"accessories\":[{\"name\":\"国家\",\"value\":\"China\",\"isSee\":1,\"language\":0},{\"name\":\"机型信息\",\"value\":\"ThinkCentre M4600t-N000\",\"isSee\":1,\"language\":0},{\"name\":\"预装类型\",\"value\":\"Standard_Image\",\"isSee\":1,\"language\":0},{\"name\":\"预装OS版本\",\"value\":\"No_Operating System\",\"isSee\":1,\"language\":0},{\"name\":\"预装OS语言\",\"value\":\"Free DOS For W7\",\"isSee\":1,\"language\":0},{\"name\":\"机箱\",\"value\":\"ThinkCentre M 25L黑色机箱\",\"isSee\":1,\"language\":0},{\"name\":\"主板\",\"value\":\"Intel SkyLake H110\",\"isSee\":1,\"language\":0},{\"name\":\"CPU\",\"value\":\"Intel Core i5-6500 3.2G 4C\",\"isSee\":1,\"language\":0},{\"name\":\"内存\",\"value\":\"8GB DDR4 2133 UDIMM\",\"isSee\":1,\"language\":0},{\"name\":\"硬盘1\",\"value\":\"500GB HD 7200RPM 3.5\\u0026quot; SATA3\",\"isSee\":1,\"language\":0},{\"name\":\"硬盘2\",\"value\":\"NONE\",\"isSee\":1,\"language\":0},{\"name\":\"第二硬盘扩展支架\",\"value\":\"None\",\"isSee\":1,\"language\":0},{\"name\":\"光驱位热插拔硬盘支架\",\"value\":\"None\",\"isSee\":1,\"language\":0},{\"name\":\"光驱1\",\"value\":\"DVD Rambo\",\"isSee\":1,\"language\":0},{\"name\":\"光驱2\",\"value\":\"NONE\",\"isSee\":1,\"language\":0},{\"name\":\"显卡\",\"value\":\"Integrated Graphic Card\",\"isSee\":1,\"language\":0},{\"name\":\"显卡转接线\",\"value\":\"None\",\"isSee\":1,\"language\":0},{\"name\":\"网卡\",\"value\":\"Integrated Ethernet\",\"isSee\":1,\"language\":0},{\"name\":\"无线网卡\",\"value\":\"None\",\"isSee\":1,\"language\":0},{\"name\":\"喇叭\",\"value\":\"None\",\"isSee\":1,\"language\":0},{\"name\":\"读卡器\",\"value\":\"NONE\",\"isSee\":1,\"language\":0},{\"name\":\"机箱报警开关\",\"value\":\"None\",\"isSee\":1,\"language\":0},{\"name\":\"机箱锁\",\"value\":\"None\",\"isSee\":1,\"language\":0},{\"name\":\"系统风扇\",\"value\":\"NONE\",\"isSee\":1,\"language\":0},{\"name\":\"键盘\",\"value\":\"新PS2防水键盘\",\"isSee\":1,\"language\":0},{\"name\":\"鼠标\",\"value\":\"USB黑色光电鼠标\",\"isSee\":1,\"language\":0},{\"name\":\"电源\",\"value\":\"180W 85% ES HP\",\"isSee\":1,\"language\":0},{\"name\":\"eSATA Port\",\"value\":\"None\",\"isSee\":1,\"language\":0},{\"name\":\"并口线\",\"value\":\"NONE\",\"isSee\":1,\"language\":0},{\"name\":\"USB接口\",\"value\":\"前2后4HP\",\"isSee\":1,\"language\":0},{\"name\":\"串口2\",\"value\":\"None\",\"isSee\":1,\"language\":0},{\"name\":\"防尘罩\",\"value\":\"None\",\"isSee\":1,\"language\":0},{\"name\":\"Optional PS2\",\"value\":\"Optional PS2 Cable\",\"isSee\":1,\"language\":0},{\"name\":\"顶置提手\",\"value\":\"有顶置提手\",\"isSee\":1,\"language\":0},{\"name\":\"Office办公软件\",\"value\":\"None\",\"isSee\":1,\"language\":0},{\"name\":\"随机软件1\",\"value\":\"None\",\"isSee\":1,\"language\":0},{\"name\":\"随机软件2\",\"value\":\"None\",\"isSee\":1,\"language\":0},{\"name\":\"随机软件3\",\"value\":\"None\",\"isSee\":1,\"language\":0},{\"name\":\"随机软件4\",\"value\":\"None\",\"isSee\":1,\"language\":0},{\"name\":\"随机驱动光盘\",\"value\":\"None\",\"isSee\":1,\"language\":0},{\"name\":\"应用\",\"value\":\"OKR\",\"isSee\":1,\"language\":0},{\"name\":\"服务1\",\"value\":\"TCM五年全面保修五年上门(促销)\",\"isSee\":1,\"language\":0},{\"name\":\"服务2\",\"value\":\"None\",\"isSee\":1,\"language\":0},{\"name\":\"服务3\",\"value\":\"门到桌安装验机\",\"isSee\":1,\"language\":0},{\"name\":\"服务4\",\"value\":\"None\",\"isSee\":1,\"language\":0},{\"name\":\"服务5\",\"value\":\"None\",\"isSee\":1,\"language\":0},{\"name\":\"服务6\",\"value\":\"None\",\"isSee\":1,\"language\":0},{\"name\":\"定制\",\"value\":\"NONE\",\"isSee\":1,\"language\":0},{\"name\":\"Second Ethernet\",\"value\":\"None\",\"isSee\":1,\"language\":0},{\"name\":\"10GYOTHERS10\",\"value\":\"NONE\",\"isSee\":1,\"language\":0},{\"name\":\"10GYOTHERS2\",\"value\":\"NONE\",\"isSee\":1,\"language\":0},{\"name\":\"10GYOTHERS3\",\"value\":\"NONE\",\"isSee\":1,\"language\":0},{\"name\":\"10GYOTHERS4\",\"value\":\"NONE\",\"isSee\":1,\"language\":0},{\"name\":\"10GYOTHERS5\",\"value\":\"NONE\",\"isSee\":1,\"language\":0},{\"name\":\"10GYOTHERS6\",\"value\":\"NONE\",\"isSee\":1,\"language\":0},{\"name\":\"10GYOTHERS7\",\"value\":\"NONE\",\"isSee\":1,\"language\":0},{\"name\":\"10GYOTHERS8\",\"value\":\"NONE\",\"isSee\":1,\"language\":0},{\"name\":\"10GYOTHERS9\",\"value\":\"NONE\",\"isSee\":1,\"language\":0}],\"productImage\":\"http://pic.17.lenovo.com.cn/g1/M00/00/2C/CmBUeVcLYRSAcEd0AADI8faMd-M116.jpg\"},{\"gcode\":\"1484\",\"materialCode\":\"60EAHCRNCA\",\"productGroupNo\":\"03\",\"productName\":\"ThinkVision 21.5英寸宽屏LED液晶(T2224r)\",\"applyNumber\":1,\"applyPrice\":930.00,\"goodsType\":1,\"accessories\":[],\"productImage\":\"http://p1.lefile.cn/M00/00/41/CmBUeVfObTiATWVbAACuRY5DUa0740.jpg\"}]";



//		details = details.replace("\n", "");
//		details = details.replaceAll("\\s+", "");

		map.put("details", URLEncoder.encode(details, "UTF8"));

 		String body = mapToPostData(map);

		System.out.println(body);
		try {
			System.out.println(body);
			String res = HttpUtil.executeHttpPostType(url, body, "application/x-www-form-urlencoded");
			System.out.println(res);
		} catch (Exception e) {
			e.printStackTrace();
		}

	}


	@Test
	public void testQueryPdf() {
		String url = "http://smbfront.17.lenovouat.cn/api/pricelist/queryPdfUrl.jhtm";
		Map<String, Object> map = new HashMap();
		map.put("itCode", "autotest");
		map.put("userId", "1014686");
		map.put("dealNo", "SMBP702060003");

		String body = mapToPostData(map);



		System.out.println(body);
		try {
			String res = HttpUtil.executeHttpPostType(url, body, "application/json");
			System.out.println(res);
		} catch (Exception e) {
			e.printStackTrace();
		}

	}







	public Map<String, Object> mockProductData(){

		String str = "{\"dealNo\":\"SMBP70414000D\",\"expireDate\":\"2017-04-22 00:00:00\",\"saleOrganization\":\"联想(北京)有限公司\",\"itcode\":\"jiangjy7\",\"memberCode\":\"SMB2170413000006\",\"totalPrice\":23600.0,\"payee\":\"联想(北京)有限公司\",\"openingBank\":\"招商银行北京大屯路支行\",\"accountNumber\":\"866180558810001800800\",\"isCreatedOrder\":1,\"auditFile\":null,\"buyerName\":\"乌鲁木齐宇通通讯设备有限公司\",\"buyerAddress\":\"乌鲁木齐市乌苏路6 号样瑞苑小区I 单元402 室\",\"buyerZip\":\"830001\",\"buyerPhone\":\"13899852116\",\"customManager\":\"姜菊颖\",\"cmPhone\":\"13541031684\",\"cmFax\":\"028-85655121\",\"pdfUrl\":\"\",\"buyerContacts\":\"罗建\",\"buyerTele\":\"028-85545614\",\"details\":[{\"gcode\":\"380\",\"materialCode\":\"20CLA3KNCD\",\"productGroupNo\":\"87\",\"productName\":\"ThinkPad X250/Windows 7 专业版/i5-5300U/ 4GB内存/ 1TB硬盘16G\",\"applyNumber\":2,\"applyPrice\":8200.0,\"goodsType\":1,\"accessories\":[{\"name\":\"CPU\",\"value\":\"第五代智能英特尔®酷睿™i5-5300U处理器(2.3睿频至2.9GHz,3MB)\",\"isSee\":1,\"language\":0},{\"name\":\"光驱\",\"value\":\"NO\",\"isSee\":1,\"language\":0},{\"name\":\"内存\",\"value\":\"4GB PC3-12800 1600MHz DDR3L 内存\",\"isSee\":1,\"language\":0},{\"name\":\"前置电池\",\"value\":\"3芯锂聚合物电池（平板）\",\"isSee\":1,\"language\":0},{\"name\":\"后置电池\",\"value\":\"3芯23.2Wh锂聚合物电池（平板）\",\"isSee\":1,\"language\":0},{\"name\":\"屏幕尺寸\",\"value\":\"12.5英寸HD(1366*768) LED 背光显示屏，\",\"isSee\":1,\"language\":0},{\"name\":\"指纹识别\",\"value\":\"Yes\",\"isSee\":1,\"language\":0},{\"name\":\"摄像头\",\"value\":\"720p HD 摄像头\",\"isSee\":1,\"language\":0},{\"name\":\"操作系统\",\"value\":\"Windows 7 专业版\",\"isSee\":1,\"language\":0},{\"name\":\"无线网卡\",\"value\":\"Intel 7265 BGN\",\"isSee\":1,\"language\":0},{\"name\":\"显卡\",\"value\":\"英特尔® HD 5500显示芯片\",\"isSee\":1,\"language\":0},{\"name\":\"服务\",\"value\":\"3年部件和人工（系统电池1年），送3年有限上门①，网上注册送3年意外保护②\",\"isSee\":1,\"language\":0},{\"name\":\"硬盘\",\"value\":\"1TB 5400rpm SATA硬盘16G M2\",\"isSee\":1,\"language\":0},{\"name\":\"蓝牙\",\"value\":\"Yes\",\"isSee\":1,\"language\":0},{\"name\":\"键盘\",\"value\":\"普通键盘\",\"isSee\":1,\"language\":0}],\"productImage\":\"http://p1.lefile.cn/product/adminweb/2016/09/08/0M9OR94waMkvlm3fT4SqwkBXT-3488.jpg\"},{\"gcode\":\"192\",\"materialCode\":\"20CLA3KSCD\",\"productGroupNo\":\"87\",\"productName\":\"ThinkPad X250/Windows 7 Home Basic/ i5-5300U/ 4GB内存/ 256GB固态硬盘\",\"applyNumber\":1,\"applyPrice\":7200.0,\"goodsType\":1,\"accessories\":[{\"name\":\"CPU\",\"value\":\"第五代智能英特尔®酷睿™i5-5300U处理器(2.3睿频至2.9GHz,3MB)\",\"isSee\":1,\"language\":0},{\"name\":\"光驱\",\"value\":\"无\",\"isSee\":1,\"language\":0},{\"name\":\"其他\",\"value\":\"无\",\"isSee\":1,\"language\":0},{\"name\":\"内存\",\"value\":\"4GB PC3-12800 1600MHz DDR3L 内存\",\"isSee\":1,\"language\":0},{\"name\":\"前置电池\",\"value\":\"3芯锂聚合物电池（平板）\",\"isSee\":1,\"language\":0},{\"name\":\"后置电池\",\"value\":\"3芯23.2Wh锂聚合物电池（平板）\",\"isSee\":1,\"language\":0},{\"name\":\"屏幕尺寸\",\"value\":\"12.5英寸\",\"isSee\":1,\"language\":0},{\"name\":\"指纹识别\",\"value\":\"有\",\"isSee\":1,\"language\":0},{\"name\":\"摄像头\",\"value\":\"720p HD\",\"isSee\":1,\"language\":0},{\"name\":\"操作系统\",\"value\":\"Windows 7 Home Basic\",\"isSee\":1,\"language\":0},{\"name\":\"无线网卡\",\"value\":\"Intel 7265 BGN\",\"isSee\":1,\"language\":0},{\"name\":\"显卡\",\"value\":\"Intel HD 5500显示芯片\",\"isSee\":1,\"language\":0},{\"name\":\"服务\",\"value\":\"1年部件和人工，客户送修\",\"isSee\":1,\"language\":0},{\"name\":\"硬盘\",\"value\":\"256GB SSD\",\"isSee\":1,\"language\":0},{\"name\":\"蓝牙\",\"value\":\"有\",\"isSee\":1,\"language\":0},{\"name\":\"键盘\",\"value\":\"普通键盘\",\"isSee\":1,\"language\":0}],\"productImage\":\"http://p1.lefile.cn/product/adminweb/2016/09/08/IPYTyVLxMwgT2HA0jAcfDePZ6-9298.jpg\"}],\"userId\":\"228009\",\"unique\":\"228009\",\"lenovoId\":\"228009\",\"memberNo\":\"228009\",\"terminal\":\"1\"}";

		return JsonUtil.fromJson(str, Map.class);
	}



	private String mapToPostData(Map<String,Object> map){
		StringBuilder sb =new StringBuilder();

		for(Map.Entry<String,Object> entry: map.entrySet()){
			sb.append(entry.getKey()).append('=').append(entry.getValue()).append('&');
		}
		return sb.toString();
	}

}
