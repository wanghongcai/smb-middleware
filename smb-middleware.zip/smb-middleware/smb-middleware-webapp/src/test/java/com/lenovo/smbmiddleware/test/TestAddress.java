package com.lenovo.smbmiddleware.test;

import java.util.HashMap;
import java.util.Map;

import org.apache.commons.lang.RandomStringUtils;
import org.apache.commons.lang.SystemUtils;
import org.junit.Test;

import com.lenovo.m2.buy.smbmiddleware.util.HttpUtil;
import com.lenovo.m2.buy.smbmiddleware.util.JsonUtil;

/**
 * Created by wangrq1 on 2016/7/26.
 */

public class TestAddress {



    @Test
    public void testAddressAdd(){
        String url = "http://smbfront.17.lenovo.com.cn/api/consignee/adddeliver.jhtm";
        Map<String, Object> map = new HashMap();
//        map.put("terminal", 1);
        map.put("memberCode", "SMB2160901000001");
        map.put("type", "SH");
        map.put("zip", "100083");
//        map.put("shopId", "6");
        map.put("deliverName", "王瑞奇");
        map.put("deliverProvince", "北京市");

        map.put("deliverCity", "北京");
        map.put("deliverCounty", "海淀区");
        map.put("deliverTowerShip", "上地");
        map.put("deliverStreet", "上地西路");
        map.put("deliverTele", "010-82332043");
        map.put("deliverMobile", "18001141691");
        map.put("deliverEmail", "wangrq1@lenovo.com");
        map.put("isDefault", "1");
        map.put("company", "lenovo");


        String body = JsonUtil.toJson(map);

        try {
            String res = HttpUtil.executeHttpPostType(url, body, "application/json; charset=utf-8");
            System.out.println(res);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }


    @Test
    public void testAddressModify(){
        Map<String, Object> map = new HashMap<>();
        map.put("deliverId", "");// UUID
        map.put("terminal", 1);
        map.put("userId", "10057830455");
        map.put("type", 1);
        map.put("zip", "100083");
        map.put("unique", "10057830455");
        map.put("shopId", "6");
        map.put("deliverName", "王瑞奇");
        map.put("deliverProvince", "北京市");

        map.put("deliverCity", "北京");
        map.put("deliverCounty", "海淀区");
        map.put("deliverTowerShip", "上地");
        map.put("deliverStreet", "上地西路");
        map.put("deliverTele", "010-82332043");
        map.put("deliverMobile", "18001141691");
        map.put("deliverEmail", "wangrq1@lenovo.com");
        map.put("isDefault", "1");
        map.put("company", "lenovo");


        String body = JsonUtil.toJson(map);

        String url = "http://127.0.0.1/api/consignee/modifydeliver.jhtm";
        try {
            String res = HttpUtil.executeHttpPostType(url, body, "application/json; charset=utf-8");
            System.out.println(res);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }



    @Test
    public void testC(){

        String a = RandomStringUtils.randomAlphabetic(6);

        System.out.println(a);
    }



}
