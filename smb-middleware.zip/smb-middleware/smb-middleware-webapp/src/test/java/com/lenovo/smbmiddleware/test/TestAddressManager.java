package com.lenovo.smbmiddleware.test;

import com.lenovo.m2.buy.smbmiddleware.domain.AddressLog;
import com.lenovo.m2.buy.smbmiddleware.domain.Memberaddrs;
import com.lenovo.m2.buy.smbmiddleware.manager.AddressManager;
import com.lenovo.m2.buy.smbmiddleware.util.JsonUtil;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * Created by wangrq1 on 2016/8/3.
 */
@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations = {"classpath:applicationContext-*.xml"})
public class TestAddressManager {

    @Autowired
    private AddressManager addressManager;



    @Test
    public void testSyncAdd() throws Exception {

        Map<String, Object> map = new HashMap<>();
        map.put("terminal", 1);
        map.put("memberCode", "SMB2160804000013");
        map.put("type", "SH");
        map.put("zip", "100083");
        map.put("deliverName", "王瑞奇");
        map.put("deliverProvince", "北京市");

        map.put("deliverCity", "北京");
        map.put("deliverCounty", "海淀区");
        map.put("deliverTowerShip", "上地");
        map.put("deliverStreet", "上地西路");
        map.put("deliverTele", "010-82332043");
        map.put("deliverMobile", "18001141691");
        map.put("deliverEmail", "wangrq1@lenovo.com");
        map.put("isDefault", "1");
        map.put("company", "lenovo");


        String res = addressManager.syncAddressAdd(JsonUtil.toJson(map));
System.out.println(res);

    }

    @Test
    public void testSyncModify() throws Exception {

        Map<String, Object> map = new HashMap<>();
        map.put("terminal", 1);
        map.put("memberCode", "SMB2160804000013");
        map.put("type", "SH");
        map.put("zip", "100083");
        map.put("deliverName", "王瑞奇modify");
        map.put("deliverProvince", "北京市modify");

        map.put("deliverCity", "北京");
        map.put("deliverCounty", "海淀区");
        map.put("deliverTowerShip", "上地");
        map.put("deliverStreet", "上地西路");
        map.put("deliverTele", "010-82332043");
        map.put("deliverMobile", "18001141695");
        map.put("deliverEmail", "wangrq1@lenovo.com");
        map.put("isDefault", "1");
        map.put("company", "lenovo");
        map.put("outDeliverId", "b22d3118-6167-4a62-b300-98084ca5a1a4");


        String res = addressManager.syncAddressModify(JsonUtil.toJson(map));
        
        System.out.println(res);


    }




    @Test
    public void testAddressGetById(){
//[{"memberaddrs":{"id":"1476702","lenovoId":"10073739669","addressname":"","name":"了李忠啊样","provinceCode":"广西","cityCode":"崇左","countyCode":"江洲","address":"123123","zip":"530000","tel":"","mobile":"18766143231","isdefault":1,"createtime":"2016-08-02 12:01:28","createby":"10073739669","updatetime":"2016-08-02 12:01:28","updateby":"10073739669","email":"","type":"SH","company":"1231212322","townshipCode":"濑湍镇","queryShopId":8,"shopId":8},"opreation":"2"},{"opreation":"2"}]}},"resultCode":"0","success":true}

        Memberaddrs str = addressManager.getById("46406", "SH", "1501108");
        if(str == null){
            System.out.println("null");
        }else{
            System.out.println(str.getLenovoId());
        }

    }


    @Test
    public void testPullAddress(){

/**
 *
 * {"rc":0,"msg":"success","data":[{"memberaddrs":{"id":"1476802","lenovoId":"10073739669","addressname":"","name":"123123333","provinceCode":"广东","cityCode":"阳江","countyCode":"江城","address":"123123","zip":"510000","tel":"","mobile":"18766143231","isdefault":1,"createtime":"2016-08-02 14:35:58","createby":"10073739669","updatetime":"2016-08-02 14:35:58","updateby":"10073739669","email":"","type":"SP","company":"123","queryShopId":8,"shopId":8},"opreation":"2"}]}
 *
 *
 */

        List<AddressLog> res = addressManager.pullAddress();
        System.out.println(JsonUtil.toJson(res));

    }



    @Test
    public void testNotifyAddressAdd(){
       
        Memberaddrs str = addressManager.getById("46496", "SH", "1501501");

    	System.out.println(str.getGuid());

        boolean res = addressManager.notifySmbAddressAdd(str);
        
        System.out.println(res);

    }


    @Test
    public void testNotifyAddressModify(){
        String json = "{\"id\":\"1476802\",\"lenovoId\":\"10073739669\",\"addressname\":\"\",\"name\":\"123123333\",\"provinceCode\":\"广东\",\"cityCode\":\"阳江\",\"countyCode\":\"江城\",\"address\":\"123123\",\"zip\":\"510000\",\"tel\":\"\",\"mobile\":\"18766143231\",\"isdefault\":1,\"createtime\":\"2016-08-02 14:35:58\",\"createby\":\"10073739669\",\"updatetime\":\"2016-08-02 14:35:58\",\"updateby\":\"10073739669\",\"email\":\"\",\"type\":\"SP\",\"company\":\"123\",\"queryShopId\":8,\"shopId\":8}";

        Memberaddrs address = JsonUtil.fromJson(json, Memberaddrs.class);

        addressManager.notifySmbAddressModify(address);

    }
    
    
    @Test
    public void testGetIdByUUid(){
    	    	
    	String id = addressManager.getIdByGuid("35f2eddf-30d3-4fd6-8ab5-63bacf1f7cfc");
    	
    	System.out.println(id);
    }
    
}
