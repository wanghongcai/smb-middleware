package com.lenovo.smbmiddleware.test;

import com.lenovo.m2.buy.smbmiddleware.remote.OpenPlatUtil;
import com.lenovo.m2.buy.smbmiddleware.util.Constants;
import com.lenovo.m2.buy.smbmiddleware.util.HttpUtil;
import com.lenovo.m2.buy.smbmiddleware.util.JsonUtil;
import org.junit.Assert;
import org.junit.Test;

import java.util.*;

/**
 * Created by wangrq1 on 2016/7/29.
 */
public class TestInvoice {

    OpenPlatUtil openPlatUtil;

    @Test
    public void testInvoiceAdd() {

        String url = "http://smbfront17.lenovouat.com/api/invoice/synInvoice.jhtm";
        Map<String, Object> map = new HashMap();
        map.put("terminal", 1);
        map.put("memberCode", "SMB2160901000001");
        map.put("customerName", "联想北京");
        map.put("invoiceType", "0");
        map.put("payManType", "1");
        map.put("payMan", "王瑞奇");
        map.put("taxNo", "10057830455");
        map.put("bankName", "中国银行");
        

        map.put("accountNo", "10057830455");
        map.put("openingBank", "北京银行");
        map.put("accountNumber", "866180558810001800800");
        map.put("subAreaCode", "1");
        map.put("subAreaName", "1");
        map.put("zip", "100083");
        map.put("provinceCode", "1");
        map.put("provinceName", "北京");
        map.put("cityCode", "23");

        map.put("cityName", "销售1");
        map.put("countyCode", "2");

        map.put("countyName", "销售1");

        map.put("address", "销售1");
        map.put("phoneNo", "18001141691");
        map.put("isDefault", "1");

        map.put("approvalStatus", "1");
        map.put("approver", "abc");
        map.put("approvalDate", "2016-09-09 12:12:12");
        map.put("soldToCode", "010123");
        map.put("isShow", "1");
        map.put("createTime", "2016-09-09 12:12:12");
        map.put("createBy", "wangrq1");
        map.put("updateTime", "2016-09-09 12:12:12");
        map.put("updateBy", "wangrq1");
        map.put("isConfirmPersonal", "1");
        map.put("synType", "1");


        String body = JsonUtil.toJson(map);

        try {
            String res = HttpUtil.executeHttpPostType(url, body, "application/json; charset=utf-8");
            System.out.println(res);
        } catch (Exception e) {
            Assert.fail();
        }


    }



    @Test
    public void testInvoiceGetIdByUUID() {
        Map<String, Object> map = new HashMap();
        map.put("terminal", 1);
        map.put("uuid", "0b2d6996-bd7b-43bb-ba75-206caf52333a");

        try {
            String res = openPlatUtil.invokeOpenPlat(Constants.METHOD_INVOICE_GETIDBYUUID, JsonUtil.toJson(map));
            System.out.println(res);
        } catch (Exception e) {
            Assert.fail();
        }

    }



    @Test
    public void testInvoiceGetByID() {
        Map<String, Object> map = new HashMap();
//        map.put("terminal", 1);
        map.put("id", "15");

        try {
            String res = openPlatUtil.invokeOpenPlat(Constants.METHOD_INVOICE_GETBYID, JsonUtil.toJson(map));
            System.out.println(res);
        } catch (Exception e) {
            Assert.fail();
        }

    }

    @Test
    public void testInvoicePull(){
        Map<String,Object> param = new HashMap<>();
        param.put("count", "1");

        try {
            String res = openPlatUtil.invokeOpenPlat(Constants.METHOD_INVOICE_FOR_SYNC, JsonUtil.toJson(param));

            System.out.println(res);


        }catch (Exception e){
            e.printStackTrace();
            Assert.fail();
        }

    }

}


