package com.lenovo.smbmiddleware.test;

import com.lenovo.m2.buy.smbmiddleware.remote.OpenPlatUtil;
import org.junit.Test;

import com.lenovo.m2.buy.smbmiddleware.util.Constants;

public class TestOpenPlat {
	
	
	
	@Test
	public void testAddPriceList(){
		
		
		   String str = "{\"deliverName\":\"15909090000\",\"deliverProvince\":\"北京\",\"deliverCity\":\"朝阳\",\"deliverCounty\":\"朝阳\",\"deliverTowerShip\":\"波罗赤镇\",\"deliverStreet\":\"北京市\",\"deliverTele\":null,\"deliverMobile\":\"15909090000\",\"deliverEmail\":null,\"isDefault\":\"0\",\"company\":\"圆通\",\"type\":\"SH\",\"zip\":\"100000\",\"outDeliverId\":null,\"userId\":\"1014593\",\"unique\":\"1014593\",\"terminal\":\"1\"}";

		
		   
		   
		 

		
		   System.out.println(str);
		   
		   
			String q = "{}";
		   
			
			try {
				
			String res = 	new OpenPlatUtil().invokeOpenPlat(Constants.METHOD_ADDRESS_ADD, str);
				
			
				System.out.println(res);
			} catch (Exception e) {
				e.printStackTrace();
			}

		
		
		
	}

	@Test
	public void testOrder(){
		
		

	}
	
	
}
