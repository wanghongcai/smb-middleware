package com.lenovo.smbmiddleware.test.dotnet;

import com.lenovo.m2.buy.smbmiddleware.remote.cxf.member.*;
import com.lenovo.m2.buy.smbmiddleware.util.JsonUtil;
import org.junit.Test;

/**
 * Created by wangrq1 on 2016/8/1.
 */
public class TestAddress {


    @Test
    public void testAddressAdd(){

        MemberInfo service = new MemberInfo();
        MemberInfoSoap soap = service.getMemberInfoSoap();

        IntegrationShipToParty smbAddress = new IntegrationShipToParty();
        smbAddress.setAddress("上地西路6号");
        smbAddress.setAddressType(AddressTypeEnum.TICKET);
//        smbAddress.setCityCode(address.getc);
        smbAddress.setCityName("北京");
//        smbAddress.setCountyCode();
        smbAddress.setCountyName("北京");

        smbAddress.setIsDefault(TrueFalseEnum.TRUE);
        smbAddress.setIsValid(TrueFalseEnum.TRUE);
//        smbAddress.setSubAreaCode();
//        smbAddress.setSubAreaName();
        smbAddress.setMemberInfoID("1f6b7673-e71d-44b4-8ef7-c137f16c476e"); // // TODO: 2016/7/27
        smbAddress.setZip("100083");
        smbAddress.setID("6d4b8668-51ca-40eb-b013-9e7f96b82b68");


        Result result = soap.addShipInfo(smbAddress);
        System.out.println(JsonUtil.toJson(result));

    }


    @Test
    public void testAddresssModify(){


    }



}
