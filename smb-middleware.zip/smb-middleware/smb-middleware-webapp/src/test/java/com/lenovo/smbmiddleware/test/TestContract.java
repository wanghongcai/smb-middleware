package com.lenovo.smbmiddleware.test;

import java.util.HashMap;
import java.util.Map;

import org.junit.Assert;
import org.junit.Test;

import com.lenovo.m2.buy.smbmiddleware.util.HttpUtil;
import com.lenovo.m2.buy.smbmiddleware.util.JsonUtil;

/**
 * Created by wangrq1 on 2016/7/28.
 */

//@RunWith(SpringJUnit4ClassRunner.class)
//@ContextConfiguration(locations = {"classpath:applicationContext-*.xml"})
public class TestContract {

//	@Autowired
//	private PriceListManager priceListManager;
	
	
	@Test
	public void testAddContract() {
		// String url = "http://127.0.0.1:8087/api/pricelist/add.jhtm";
		
		String url = "http://smbfront.17.lenovouat.cn/api/contract/addContractInfo.jhtm";
		
//		String url = "http://10.120.120.155:8087/api/contract/addContractInfo.jhtm";
		Map<String, Object> map = new HashMap<>();
		map.put("contractNo", "dddd");
		map.put("memberCode", "SMB2160811000036");
		map.put("buyerName", "王瑞奇");
		map.put("shipName", "王瑞奇");
		map.put("shipMobile", "18001141691");
		map.put("shipAddress", "上地西路6号");
		map.put("takeffectTime", "2016-08-08 12:12:12");
		map.put("issend", true);


		String body = JsonUtil.toJson(map);

		try {
			String res = HttpUtil.executeHttpPostType(url, body, "application/json; charset=utf-8");
			System.out.println(res);
		} catch (Exception e) {
			e.printStackTrace();
		}

	}

	

	@Test
	public void testGetContract() {
		String url = "http://10.120.120.155:8087/api/contract/getContractInfo.jhtm";
		Map<String, Object> map = new HashMap<>();
		map.put("contractNo", "SMB2160811000036");
		map.put("memberCode", "SMB2160811000036");

		

		String body = JsonUtil.toJson(map);

		try {
			String res = HttpUtil.executeHttpPostType(url, body, "application/json; charset=utf-8");
			System.out.println(res);
			
		} catch (Exception e) {
			e.printStackTrace();
			Assert.fail();
		}
	}
	
}
