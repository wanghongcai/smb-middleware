package com.lenovo.smbmiddleware.test;

import java.util.List;
import java.util.Map;

import com.lenovo.m2.buy.smbmiddleware.util.JsonUtil;

public class TestParam {
	
	
	public static void main(String[] args) {
		
		
		String str = "{\"data\":[{\"处理器\":{\"CPU型号1\":\"6Y3022\",\"CPU速度\":\"0.9GHz，最大频率:2.2GHz\",\"CPU型号\":\"6Y30\",\"CPU类型\":\"第六代Skylake平台Intel Core M 6Y30处理器\"},\"内存\":{\"插槽数量\":\"板载\",\"内存大小\":\"4GB\",\"内存类型\":\"DDR3\"},\"显示器\":{\"屏幕尺寸\":\"12.2英寸\",\"物理分辨率\":\"1920x1200\",\"显示比例\":\"宽屏16:10\"}}],\"curDatetime\":\"2016-08-23 19:32:40\",\"status\":200,\"timecost\":0.0010001659393311,\"size\":1}";
		
		Map map = JsonUtil.fromJson(str,  Map.class);
		
		Object o = map.get("data");
		
		String data= JsonUtil.toJson(o);
//		System.out.println(data);
		List<Map> list = JsonUtil.readValuesAsArrayList(data, Map.class);
		Map<String, Map<String,String>> m = list.get(0);
		
		for(Map.Entry<String,Map<String,String>> e: m.entrySet()){
			System.out.println(e.getKey());
			System.out.println(e.getValue());
			Map<String,String> v = e.getValue();
			for(Map.Entry<String, String> last: v.entrySet()){
				System.out.println(last.getKey() +"    :   "+ last.getValue());
			} 
			
		}
		
		
		
		System.out.println(list.size());
		
		
		
		
		
		
		
	}

}
