package com.lenovo.smbmiddleware.test;

import com.lenovo.m2.buy.smbmiddleware.domain.InvoiceShop;
import com.lenovo.m2.buy.smbmiddleware.domain.InvoiceShopModifyLog;
import com.lenovo.m2.buy.smbmiddleware.manager.InvoiceManager;
import com.lenovo.m2.buy.smbmiddleware.util.JsonUtil;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import javax.annotation.Resource;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * Created by wangrq1 on 2016/8/3.
 */
@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations = { "classpath:applicationContext-*.xml" })

public class TestInvoiceManager {

	@Resource
	private InvoiceManager invoiceManager;

	@Test
	public void testInvoiceAdd() throws Exception {
		Map<String, Object> map = new HashMap();
		map.put("terminal", 1);
		map.put("memberCode", "SMB2160804000013");
		map.put("customerName", "联想北京");
		map.put("invoiceType", "0");
		map.put("payManType", "1");
		
		map.put("payMan", "王瑞奇");
		map.put("taxNo", "10057830455");
		map.put("bankName", "中国银行");

		map.put("accountNo", "10057830455");
		map.put("openingBank", "北京银行");
		map.put("accountNumber", "866180558810001800800");
		map.put("subAreaCode", "1");
		map.put("subAreaName", "1");
		map.put("zip", "100083");
		map.put("provinceCode", "1");
		map.put("provinceName", "北京");
		map.put("cityCode", "23");

		map.put("cityName", "销售1");
		map.put("countyCode", "2");

		map.put("countyName", "销售1");

		map.put("address", "销售1");
		map.put("phoneNo", "18001141691");
		map.put("isDefault", "1");

		map.put("approvalStatus", "1");
		map.put("approver", "abc");
		map.put("approvalDate", "2016-09-09 12:12:12");
		map.put("soldToCode", "010123");
		map.put("isShow", "1");
		map.put("createTime", "2016-09-09 12:12:12");
		map.put("createBy", "wangrq1");
		map.put("updateTime", "2016-09-09 12:12:12");
		map.put("updateBy", "wangrq1");
		map.put("isConfirmPersonal", "1");
		map.put("synType", "1");

		String res = invoiceManager.syncInvoiceAdd(JsonUtil.toJson(map));

		System.out.println(res);

	}
	
	
	
	
	@Test
	public void testInvoiceModify() throws Exception {
		Map<String, Object> map = new HashMap<>();
		map.put("terminal", 1);
		map.put("memberCode", "SMB2160804000013");
		map.put("customerName", "联想北京");
		map.put("invoiceType", "0");
		map.put("payManType", "1");
		
		map.put("payMan", "王瑞奇");
		map.put("taxNo", "10057830455");
		map.put("bankName", "中国银行");

		map.put("accountNo", "10057830455");
		map.put("openingBank", "北京银行");
		map.put("accountNumber", "866180558810001800800");
		map.put("subAreaCode", "1");
		map.put("subAreaName", "1");
		map.put("zip", "100083");
		map.put("provinceCode", "1");
		map.put("provinceName", "北京");
		map.put("cityCode", "23");

		map.put("cityName", "销售1");
		map.put("countyCode", "2");

		map.put("countyName", "销售1");

		map.put("address", "销售1");
		map.put("phoneNo", "18001141691");
		map.put("isDefault", "1");

		map.put("approvalStatus", "1");
		map.put("approver", "abc");
		map.put("approvalDate", "2016-09-09 12:12:12");
		map.put("soldToCode", "010123");
		map.put("isShow", "1");
		map.put("createTime", "2016-09-09 12:12:12");
		map.put("createBy", "wangrq1");
		map.put("updateTime", "2016-09-09 12:12:12");
		map.put("updateBy", "wangrq1");
		map.put("isConfirmPersonal", "1");
		map.put("synType", "2");
		map.put("uuid", "bf993660-b18c-4468-9366-db2c61a6d192");
		String res = invoiceManager.syncInvoiceAdd(JsonUtil.toJson(map));

		System.out.println(res);

	}
	
	

	@Test
	public void testNotifyInvoiceAdd() {
		
		InvoiceShop invoice = invoiceManager.getById("87");
		
		invoiceManager.notifySmbInvoiceAdd(invoice);

	}

	@Test
	public void testInvoicePull() {
		List<InvoiceShop> log = invoiceManager.pullInvoice();
		System.out.println(JsonUtil.toJson(log));
	}
	
	
	@Test
	public void testInvoiceGetById() {
		InvoiceShop log = invoiceManager.getById("54");
		System.out.println(JsonUtil.toJson(log));
	}

	
	@Test
	public void testInvoiceGetByIdByUUID() {
						
		String r = invoiceManager.getIdByGuid("4bb90d9a-f001-4994-b7ee-b1942c997f31");
		
		System.out.println(r);
	}
	
	
	

	
	

}
