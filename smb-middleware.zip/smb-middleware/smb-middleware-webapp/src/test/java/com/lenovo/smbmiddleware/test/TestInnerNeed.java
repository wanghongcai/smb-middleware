package com.lenovo.smbmiddleware.test;

import com.lenovo.m2.buy.smbmiddleware.remote.OpenPlatUtil;
import com.lenovo.m2.buy.smbmiddleware.util.Constants;
import com.lenovo.m2.buy.smbmiddleware.util.JsonUtil;
import org.junit.Assert;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import java.util.HashMap;
import java.util.Map;

/**
 * Created by wangrq1 on 2016/8/1.
 */
@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations = {"classpath:applicationContext-*.xml"})
public class TestInnerNeed {

    @Autowired
    private OpenPlatUtil openPlatUtil;


    @Test
    public void testAddressByIdByGUID(){
        Map param = new HashMap<>();

        param.put("guid", "SMB2160726000003");

        try {
            String res = openPlatUtil.invokeOpenPlat(Constants.METHOD_ADDRESS_GETIDBYUUID, JsonUtil.toJson(param));
            System.out.println(res);
        } catch (Exception e) {
            e.printStackTrace();
            Assert.fail();
        }

    }

    @Test
    public void testInvoiceByIdByGUID(){

    }

    @Test
    public void testAddressGetById(){

        //	SH("SH","收货地址"),
//        SP("SP","收票地址"),
//                HT("HT","合同地址")

        Map param = new HashMap<>();
        param.put("userId", "10073739669");
        param.put("type", "SP");
        param.put("deliverId", "1476802");

        try {
            String res = openPlatUtil.invokeOpenPlat(Constants.METHOD_ADDRESS_GETBYID, JsonUtil.toJson(param));
            System.out.println(res);
        } catch (Exception e) {
            e.printStackTrace();
            Assert.fail();
        }
    }

    @Test
    public void testInvoiceGetById(){



    }

    @Test
    public void testUserGetIdBySmbId(){
        Map param = new HashMap<>();
        param.put("sts", "e40e7004-4c8a-4963-8564-31271a8337d8");
        param.put("thirdId", "SMB2160726000003");

        try {
            String res = openPlatUtil.invokeOpenPlat(Constants.METHOD_MEMBER_GETIDBYTHIRDID, JsonUtil.toJson(param));
            System.out.println(res);
        } catch (Exception e) {
            e.printStackTrace();
            Assert.fail();
        }

    }

    @Test
    public void testUserGetSmbIdById(){
        Map param = new HashMap<>();
        param.put("sts", "e40e7004-4c8a-4963-8564-31271a8337d8");
        param.put("customerId", "46301");
        try {
            String res = openPlatUtil.invokeOpenPlat(Constants.METHOD_MEMBER_GETTHIRDIDBYID, JsonUtil.toJson(param));
            System.out.println(res);

        } catch (Exception e) {
            e.printStackTrace();
            Assert.fail();
        }
    }


}
