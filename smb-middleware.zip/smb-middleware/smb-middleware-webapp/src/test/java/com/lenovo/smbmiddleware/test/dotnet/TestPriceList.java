package com.lenovo.smbmiddleware.test.dotnet;

import com.lenovo.m2.buy.smbmiddleware.remote.cxf.pricelist.*;
import com.lenovo.m2.buy.smbmiddleware.util.JsonUtil;
import org.junit.Test;

/**
 * Created by wangrq1 on 2016/8/1.
 */
public class TestPriceList {

    @Test
    public void testPriceListUpdateStatus(){

        GoodsAndPricelist service = new GoodsAndPricelist();

        GoodsAndPricelistSoap soap = service.getGoodsAndPricelistSoap();
        IntegrationPriceList param = new IntegrationPriceList();

        param.setPriceListCode("SMB1234");
        param.setProcessStatus(ProcessStatus.DUPLICATE);

        PriceResult result = soap.sendBTCPriceStatus(param);


        System.out.println(JsonUtil.toJson(result));

    }


}
