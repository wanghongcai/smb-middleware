package com.lenovo.smbmiddleware.test;

import com.lenovo.m2.buy.smbmiddleware.util.HttpUtil;
import com.lenovo.m2.buy.smbmiddleware.util.JsonUtil;
import org.junit.Test;

import java.util.HashMap;
import java.util.Map;

/**
 * Created by wangrq1 on 2016/8/1.
 */
public class TestPay {

    @Test
    public void testUpdatePayStatus() {
        String url = "http://10.120.120.155:8087/api/pay/notify/payStatusNotify.jhtm";
        Map<String, Object> map = new HashMap();
        map.put("terminal", 1);
        map.put("tradeNo", "SMB60819001E");
        map.put("orderStatus", "TRADE_SUCCESS");
        map.put("transactionId", "1231231sf43243");
        map.put("payAcc", "62123412341234");
        map.put("payType", "20");
        map.put("payDept", "中国银行");

        String body = JsonUtil.toJson(map);

        try {
            String res = HttpUtil.executeHttpPostType(url, body, "application/json; charset=utf-8");
            System.out.println(res);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

}
