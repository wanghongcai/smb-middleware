package com.lenovo.smbmiddleware.test;

import com.lenovo.m2.buy.smbmiddleware.util.HttpUtil;
import com.lenovo.m2.buy.smbmiddleware.util.JsonUtil;
import org.junit.Test;

import java.util.HashMap;
import java.util.Map;

/**
 * Created by wangrq1 on 2016/8/1.
 */
public class TestOrder {


    @Test
    public void  testUpdateStatus(){

        String url = "http://smbfront.17.lenovo.com.cn/api/order/updatestatus.jhtm";
        Map<String, Object> map = new HashMap();
//        map.put("terminal", 1);
        map.put("orderId", "SMB60509000301E");
        map.put("status", "STATUS_SMB_17_WAREHOUSED");
        map.put("statusTime", "2016-05-10 15:13:36");
        
        String body = JsonUtil.toJson(map);

        try {
            String res = HttpUtil.executeHttpPostType(url, body, "application/json; charset=utf-8");
            System.out.println(res);
        } catch (Exception e) {
            e.printStackTrace();
        }

    }


    @Test
    public void  testUpdateLogistics(){

        String url = "http://10.120.120.155:8087/api/logistics/updateLogistics.jhtm";
        Map<String, Object> map = new HashMap<>();
        map.put("terminal", 1);
        map.put("orderId", "3289478");
        map.put("logistics", "SZYD201604280001232");
        map.put("logisticsCompanyCode", "北京天勤志远物流有限公司2");


        String body = JsonUtil.toJson(map);

        try {
            String res = HttpUtil.executeHttpPostType(url, body, "application/json; charset=utf-8");
            System.out.println(res);
        } catch (Exception e) {
            e.printStackTrace();
        }

    }



    @Test
    public void  testGetContractPdfUrl(){

        String url = "http://10.120.120.155:8087/api/order/getcontracturl.jhtm";
        Map<String, Object> map = new HashMap();
        map.put("terminal", 1);
        map.put("orderId", "SMB12341234");



        String body = JsonUtil.toJson(map);

        try {
            String res = HttpUtil.executeHttpPostType(url, body, "application/json; charset=utf-8");
            System.out.println(res);
        } catch (Exception e) {
            e.printStackTrace();
        }

    }


}
