package com.lenovo.smbmiddleware.test;

import java.net.MalformedURLException;
import java.net.URL;

import org.apache.cxf.jaxws.JaxWsProxyFactoryBean;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import com.lenovo.m2.buy.smbmiddleware.remote.cxf.member.MemberInfo;
import com.lenovo.m2.buy.smbmiddleware.remote.cxf.member.MemberInfoSoap;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations = { "classpath:applicationContext-*.xml" })
public class TestCXF {
	
	
	@Autowired
	private MemberInfoSoap memberInfoSoap;
	
	@Test
	public void testJAXWSProxy() throws MalformedURLException{
		
//		URL wsdlURL = new URL("http://10.99.200.85:8020/GoodsAndPricelist.asmx?wsdl");
//		QName SERVICE_NAME = new QName("http://tempuri.org/", "GoodsAndPricelist");
//		Service service = Service.create(wsdlURL, SERVICE_NAME);
//		GoodsAndPricelistSoap client = service.getPort(GoodsAndPricelistSoap.class);
//		IntegrationPriceList list = new IntegrationPriceList();
//		list.setPriceListCode("SMBP608190003");
//		PriceResult pr= client.getPriceListStatus(list);
		
//		System.out.println(pr.getReturnStatus());
		
		
		
		MemberInfo info = new MemberInfo(new URL("http://10.99.200.85:8020/MemberInfo.asmx?WSDL"));
//		info.
		MemberInfoSoap soap = info.getMemberInfoSoap12();
	
		String res = soap.seachMemberInfo("d78d7f88-e51f-431c-9f28-b367c722f9f7");
		
		System.out.println(res);
		
	}
	
	@Test
	public void testClient2(){
		
		
//		ClientProxyFactoryBean factory = new ClientProxyFactoryBean();
//		factory.setServiceClass(MemberInfoSoap.class);
//		factory.setAddress("http://10.99.200.85:8020/MemberInfo.asmx");
////		factory.set
//		MemberInfoSoap client = (MemberInfoSoap) factory.create();
//		
//		try{
//			client.seachMemberInfo("d78d7f88-e51f-431c-9f28-b367c722f9f7");
//			
//		}catch(Exception e){
//			e.printStackTrace();;
//		}
		
		JaxWsProxyFactoryBean f = new JaxWsProxyFactoryBean();
		f.setAddress("http://10.99.200.85:8020/MemberInfo.asmx");
		f.setServiceClass(MemberInfoSoap.class);
		
		MemberInfoSoap client = (MemberInfoSoap) f.create();
		
		
		String res = client.seachMemberInfo("d78d7f88-e51f-431c-9f28-b367c722f9f7");
		
		System.out.println(res);
		
		
		
		
		
	}

	
	
	@Test
	public void testWithSpring(){
		
		
		
		String res = memberInfoSoap.seachMemberInfo("d78d7f88-e51f-431c-9f28-b367c722f9f7");
		
		System.out.println(res);
		
		
		
		
		
	}


	public static void main(String[]args){
		String imgUrl = "http://ssss.lenoo.com";

		if(imgUrl != null && imgUrl.startsWith("http:")){
			imgUrl = imgUrl.substring(5);
		}


		System.out.println(imgUrl);


	}
}
