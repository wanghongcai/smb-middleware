package com.lenovo.m2.buy.smbmiddleware.domain;

import java.io.Serializable;

/**
 * @author zhanhgs
 * @version V1.0
 * @Title: ${file_name}
 * @Package ${package_name}
 * @Description: 地址操作日志对象
 * @date ${date} ${time}
 */
public class AddressLog implements Serializable{

    private Memberaddrs memberaddrs;//地址对象
    private String opreation;//操作类型 1：新增地址，2：更新地址，3：删除地址

    public AddressLog() {
    }

    public AddressLog(String opreation, Memberaddrs memberaddrs) {
        this.opreation = opreation;
        this.memberaddrs = memberaddrs;
    }

    public Memberaddrs getMemberaddrs() {
        return memberaddrs;
    }

    public void setMemberaddrs(Memberaddrs memberaddrs) {
        this.memberaddrs = memberaddrs;
    }

    public String getOpreation() {
        return opreation;
    }

    public void setOpreation(String opreation) {
        this.opreation = opreation;
    }
}


