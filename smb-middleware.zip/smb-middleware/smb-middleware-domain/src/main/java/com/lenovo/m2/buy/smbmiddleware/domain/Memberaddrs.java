package com.lenovo.m2.buy.smbmiddleware.domain;

import java.io.Serializable;
import java.util.Date;

public class Memberaddrs implements Serializable {

    /**
     * serialVersionUID:TODO(用一句话描述这个变量表示什么).
     *
     * @since JDK 1.7
     */
    private static final long serialVersionUID = 1L;

    private String id;

    private String lenovoId;

    private String addressname;

    private String name;

    private String provinceCode;

    private String cityCode;

    private String countyCode;

    private String address;

    private String zip;

    private String tel;

    private String mobile;

    private Integer isdefault;

    private Date createtime;

    private String createby;

    private Date updatetime;

    private String updateby;

    private String email;

    private Integer isdeleted;
    //收货地址类型
    private String type;
    //省市县编码
    private String areaNos;
    //公司名称
    private String company;
    //乡镇编码或汉字
    private String townshipCode;
    //查询用的queryShopId
    private int queryShopId;
    //shopid
    private int shopId;
    //guid smb id
    private String guid;
    //addressId smb AddressID
    private String addressId;


    public String getGuid() {
        return guid;
    }

    public void setGuid(String guid) {
        this.guid = guid;
    }

    public String getAddressId() {
        return addressId;
    }

    public void setAddressId(String addressId) {
        this.addressId = addressId;
    }


    public int getQueryShopId() {
        return queryShopId;
    }

    public void setQueryShopId(int queryShopId) {
        this.queryShopId = queryShopId;
    }

    public int getShopId() {
        return shopId;
    }

    public void setShopId(int shopId) {
        this.shopId = shopId;
    }

    public String getTownshipCode() {
        return townshipCode;
    }

    public void setTownshipCode(String townshipCode) {
        this.townshipCode = townshipCode;
    }

    public String getCompany() {
        return company;
    }

    public void setCompany(String company) {
        this.company = company;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public String getAreaNos() {
        return areaNos;
    }

    public void setAreaNos(String areaNos) {
        this.areaNos = areaNos;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getLenovoId() {
        return lenovoId;
    }

    public void setLenovoId(String lenovoId) {
        this.lenovoId = lenovoId;
    }

    public String getAddressname() {
        return addressname;
    }

    public void setAddressname(String addressname) {
        this.addressname = addressname;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getProvinceCode() {
        return provinceCode;
    }

    public void setProvinceCode(String provinceCode) {
        this.provinceCode = provinceCode;
    }

    public String getCityCode() {
        return cityCode;
    }

    public void setCityCode(String cityCode) {
        this.cityCode = cityCode;
    }

    public String getCountyCode() {
        return countyCode;
    }

    public void setCountyCode(String countyCode) {
        this.countyCode = countyCode;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public String getZip() {
        return zip;
    }

    public void setZip(String zip) {
        this.zip = zip;
    }

    public String getTel() {
        return tel;
    }

    public void setTel(String tel) {
        this.tel = tel;
    }

    public String getMobile() {
        return mobile;
    }

    public void setMobile(String mobile) {
        this.mobile = mobile;
    }

    public Integer getIsdefault() {
        return isdefault;
    }

    public void setIsdefault(Integer isdefault) {
        this.isdefault = isdefault;
    }


    public String getCreateby() {
        return createby;
    }

    public void setCreateby(String createby) {
        this.createby = createby;
    }

    public Date getCreatetime() {
        return createtime;
    }

    public void setCreatetime(Date createtime) {
        this.createtime = createtime;
    }

    public Date getUpdatetime() {
        return updatetime;
    }

    public void setUpdatetime(Date updatetime) {
        this.updatetime = updatetime;
    }

    public String getUpdateby() {
        return updateby;
    }

    public void setUpdateby(String updateby) {
        this.updateby = updateby;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public Integer getIsdeleted() {
        return isdeleted;
    }

    public void setIsdeleted(Integer isdeleted) {
        this.isdeleted = isdeleted;
    }

    @Override
    public String toString() {
        return "Memberaddrs{" +
                "id='" + id + '\'' +
                ", lenovoId='" + lenovoId + '\'' +
                ", addressname='" + addressname + '\'' +
                ", name='" + name + '\'' +
                ", provinceCode='" + provinceCode + '\'' +
                ", cityCode='" + cityCode + '\'' +
                ", countyCode='" + countyCode + '\'' +
                ", address='" + address + '\'' +
                ", zip='" + zip + '\'' +
                ", tel='" + tel + '\'' +
                ", mobile='" + mobile + '\'' +
                ", isdefault=" + isdefault +
                ", createtime=" + createtime +
                ", createby='" + createby + '\'' +
                ", updatetime=" + updatetime +
                ", updateby='" + updateby + '\'' +
                ", email='" + email + '\'' +
                ", isdeleted=" + isdeleted +
                ", type='" + type + '\'' +
                ", areaNos='" + areaNos + '\'' +
                ", company='" + company + '\'' +
                ", townshipCode='" + townshipCode + '\'' +
                ", queryShopId=" + queryShopId +
                ", shopId=" + shopId +
                ", guid='" + guid + '\'' +
                ", addressId='" + addressId + '\'' +
                '}';
    }
}