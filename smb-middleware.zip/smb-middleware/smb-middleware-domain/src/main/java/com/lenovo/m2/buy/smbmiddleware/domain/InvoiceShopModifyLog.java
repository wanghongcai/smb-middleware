package com.lenovo.m2.buy.smbmiddleware.domain;

import java.io.Serializable;

public class InvoiceShopModifyLog extends InvoiceShop implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 6907026818863836917L;
	
	private Integer shopId;
	private Integer state;

	public Integer getState() {
		return this.state;
	}

	public void setState(Integer state) {
		this.state = state;
	}

	public Integer getShopId() {
		return this.shopId;
	}

	public void setShopId(Integer shopId) {
		this.shopId = shopId;
	}
}
