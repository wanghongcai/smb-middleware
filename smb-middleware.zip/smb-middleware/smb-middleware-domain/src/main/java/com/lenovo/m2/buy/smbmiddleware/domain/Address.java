package com.lenovo.m2.buy.smbmiddleware.domain;

import java.io.Serializable;

/**
 * Created by wangrq1 on 2016/7/27.
 */
public class Address implements Serializable{

    private String deliverName;
    private String deliverProvince;
    private String deliverCity;
    private String deliverCounty;
    private String deliverTowerShip;
    private String deliverStreet;
    private String deliverTele;
    private String deliverMobile;
    private String deliverEmail;
    private String isDefault;
    private String company;
    private String type;
    private String zip;
    private String userId;
    private String deliverId;
    private String uuid;

    private String operType;


    public String getDeliverName() {
        return deliverName;
    }

    public void setDeliverName(String deliverName) {
        this.deliverName = deliverName;
    }

    public String getDeliverProvince() {
        return deliverProvince;
    }

    public void setDeliverProvince(String deliverProvince) {
        this.deliverProvince = deliverProvince;
    }

    public String getDeliverCity() {
        return deliverCity;
    }

    public void setDeliverCity(String deliverCity) {
        this.deliverCity = deliverCity;
    }

    public String getDeliverCounty() {
        return deliverCounty;
    }

    public void setDeliverCounty(String deliverCounty) {
        this.deliverCounty = deliverCounty;
    }

    public String getDeliverTowerShip() {
        return deliverTowerShip;
    }

    public void setDeliverTowerShip(String deliverTowerShip) {
        this.deliverTowerShip = deliverTowerShip;
    }

    public String getDeliverStreet() {
        return deliverStreet;
    }

    public void setDeliverStreet(String deliverStreet) {
        this.deliverStreet = deliverStreet;
    }

    public String getDeliverTele() {
        return deliverTele;
    }

    public void setDeliverTele(String deliverTele) {
        this.deliverTele = deliverTele;
    }

    public String getDeliverMobile() {
        return deliverMobile;
    }

    public void setDeliverMobile(String deliverMobile) {
        this.deliverMobile = deliverMobile;
    }

    public String getDeliverEmail() {
        return deliverEmail;
    }

    public void setDeliverEmail(String deliverEmail) {
        this.deliverEmail = deliverEmail;
    }

    public String getIsDefault() {
        return isDefault;
    }

    public void setIsDefault(String isDefault) {
        this.isDefault = isDefault;
    }

    public String getCompany() {
        return company;
    }

    public void setCompany(String company) {
        this.company = company;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public String getZip() {
        return zip;
    }

    public void setZip(String zip) {
        this.zip = zip;
    }

    public String getUserId() {
        return userId;
    }

    public void setUserId(String userId) {
        this.userId = userId;
    }

    public String getDeliverId() {
        return deliverId;
    }

    public void setDeliverId(String deliverId) {
        this.deliverId = deliverId;
    }

    public String getUuid() {
        return uuid;
    }

    public void setUuid(String uuid) {
        this.uuid = uuid;
    }

    public String getOperType() {
        return operType;
    }

    public void setOperType(String operType) {
        this.operType = operType;
    }
}
