package com.lenovo.m2.buy.smbmiddleware.util;

import com.lenovo.m2.buy.smbmiddleware.enums.GlobalErrorMessage;
import com.lenovo.m2.buy.smbmiddleware.enums.MessageType;
import com.lenovo.m2.buy.smbmiddleware.exception.BusinessException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.PriorityQueue;

/**
 * Created by wangrq1 on 2016/7/26.
 */
public class MessageQueue {

    private static PriorityQueue<Message> queue = new PriorityQueue<>();

    private static Logger log = LoggerFactory.getLogger(MessageQueue.class);


    public static boolean add(Message message){
        if(queue.size() > 200){
            log.warn("queue size={}", queue.size());
        }

        return  queue.add(message);
    }

    public static Message take(){
        return queue.poll();
    }


    public static class Message implements Comparable<Message>{

        private MessageType type;
        private String content;
        private Date createTime;

        public MessageType getType() {
            return type;
        }

        public void setType(MessageType type) {
            this.type = type;
        }

        public String getContent() {
            return content;
        }

        public void setContent(String content) {
            this.content = content;
        }

        public Date getCreateTime() {
            return createTime;
        }

        public void setCreateTime(Date d){
            this.createTime = d;
        }

        public Message(MessageType type, String content){
            this.type = type;
            this.content = content;
            this.createTime = new Date();
        }

        public void resetCreateTime(){
            this.createTime = new Date();
        }



        @Override
        public int compareTo(Message o) {
            if(o == null){
                return 1;
            }
            return this.createTime.compareTo(o.createTime);

        }


        public static MessageType getInvoiceOperType(String type){
            if("1".equals(type)){
                return MessageType.INVOICE_ADD;
            }else if("2".equals(type)){
                return MessageType.INVOICE_MODIFY;
            }else if("3".equals(type)){
                return MessageType.INVOICE_DELETE;
            }else {
                throw new BusinessException(GlobalErrorMessage.ERROR_PARAM_ILLEGAL);
            }

        }
        
        

        


        public static MessageType getAddressOperType(String type){
            if("1".equals(type)){
                return MessageType.ADDRESS_ADD;
            }else if("2".equals(type)){
                return MessageType.ADDRESS_MODIFY;
            }else if("3".equals(type)){
                return MessageType.ADDRESS_DELETE;
            }else {
                throw new BusinessException(GlobalErrorMessage.ERROR_PARAM_ILLEGAL);
            }
        }
    }



    public static void main(String[]args){
        Date now = new Date();

        Calendar calendar  = Calendar.getInstance();
        calendar.setTime(now);
        calendar.add(Calendar.MINUTE, 1);

        Date a = calendar.getTime();

        calendar.add(Calendar.MINUTE, 2);
        Date b = calendar.getTime();

        calendar.add(Calendar.MINUTE, 2);
        Date c = calendar.getTime();

        calendar.add(Calendar.MINUTE, 2);
        Date d = calendar.getTime();

        calendar.add(Calendar.MINUTE, 2);
        Date e = calendar.getTime();



        Message ma = new Message(MessageType.ADDRESS_ADD, "");
        ma.setCreateTime(a);

        Message mb = new Message(MessageType.ADDRESS_ADD, "");
        mb.setCreateTime(b);

        Message mc = new Message(MessageType.ADDRESS_ADD, "");
        mc.setCreateTime(c);

        Message md = new Message(MessageType.ADDRESS_ADD, "");
        md.setCreateTime(d);

        Message me = new Message(MessageType.ADDRESS_ADD, "");
        me.setCreateTime(e);

        add(ma);
        add(md);
        add(me);
        add(mc);
        add(mb);

        while (true){
        Message mg = take();
            if(mg == null){
                break;
            }
            System.out.println(new SimpleDateFormat("yyyyMMdd HH:mm:ss").format(mg.createTime));

        }


    }


}
