package com.lenovo.m2.buy.smbmiddleware.util;

import org.apache.commons.codec.binary.Hex;
import org.apache.commons.lang.RandomStringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.nio.charset.Charset;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Map;

/**
 * Created by wangrq1 on 2016/7/21.
 */
public class OpenPlatReq {

    static final Logger log = LoggerFactory.getLogger(OpenPlatReq.class);

    private String method;
    private String timestamp;
    private String v = "1.0";
    private String lenovo_param_json;
    private String app_key;
    private String secretKey;
    private Integer terminal = 1;
    private String unique = null;
    private String userId;


    private static String DEFAULT_ACCESS_TOKEN = CustomizedPropertyConfigurer.getContextProperty("access_token");
    private static String DEFAULT_APP_KEY  = CustomizedPropertyConfigurer.getContextProperty("app_key");//"msb20160802";
//    private static String DEFAULT_APP_KEY  = "msb20160802";
    private static String DEFAULT_SECRETKEY = CustomizedPropertyConfigurer.getContextProperty("secretKey");
//    private static String DEFAULT_SECRETKEY = "cerp@msb20160902@#XZ";


    private String formBody;


    public OpenPlatReq(String method, String paramBody){
        this.method = method;
        this.lenovo_param_json = paramBody;
        this.timestamp = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss").format(new Date());
//        this.access_token =DEFAULT_ACCESS_TOKEN;
        this.app_key = DEFAULT_APP_KEY;
        this.secretKey = DEFAULT_SECRETKEY;
        Map map = JsonUtil.fromJson(paramBody, Map.class);
        this.userId = (String)map.get("userId");
        this.unique = RandomStringUtils.randomAlphabetic(6);

    }

    public OpenPlatReq(String method, String paramBody, String app_key, String secretKey){
        this.method = method;
        this.lenovo_param_json = paramBody;
        this.timestamp = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss").format(new Date());
//        this.access_token =access_token;
        this.app_key = app_key;
        this.secretKey = secretKey;
        Map map = JsonUtil.fromJson(paramBody, Map.class);
        this.userId = (String)map.get("userId");
        this.unique = RandomStringUtils.randomAlphabetic(6);
    }




    /**
     *
     * @param
     * @return
     */
     private String getPlain(){
        StringBuilder sb = new StringBuilder(128);
                sb.append("app_key").append(app_key)
                .append("lenovo_param_json").append(this.lenovo_param_json)
                .append("method").append(this.method)
                .append("terminal").append(terminal)
                .append("timestamp").append(this.timestamp)
                .append("unique").append(this.unique)
                        .append("userId").append(this.userId)
                .append("v").append(this.v);
        return sb.toString();
    }


    public String getPostBody(){
        String origPlain = getPlain();
        String plain = String.format("%s%s%s", this.secretKey, origPlain, this.secretKey);
        String sign  = md5Sum(plain);

        StringBuilder sb = new StringBuilder();
        sb.append("app_key").append('=').append(app_key).append('&')
                .append("lenovo_param_json").append('=').append(this.lenovo_param_json).append('&')
                .append("method").append('=').append(this.method).append('&')
                .append("timestamp").append('=').append(this.timestamp).append('&')
                .append("v").append('=').append(this.v).append('&')
                .append("sign=").append(sign).append("&terminal=").append(terminal).append("&unique=").append(this.unique).append("&userId=").append(userId);

//        log.info("plain={}, sign={}, post body={}", new Object[]{plain, sign, sb.toString()});

        return sb.toString();
    }


    private String md5Sum(String plain){
        MessageDigest md = null;
        try {
            md = MessageDigest.getInstance("MD5");
            String md5 =  new String(Hex.encodeHex(md.digest(plain.getBytes(Charset.forName("UTF-8")))));
            return md5.toUpperCase();
        } catch (NoSuchAlgorithmException e) {
            e.printStackTrace();
        }
        return "";
    }


public static void main(String[] args){



    String str = new OpenPlatReq("12345","12345","12345","12345").md5Sum("testapp_keytestlenovo_param_json{}methodlenovo_testtimestamp2016-07-26 09:58:51test");

    System.out.println(RandomStringUtils.randomAlphabetic(6));


}



}
