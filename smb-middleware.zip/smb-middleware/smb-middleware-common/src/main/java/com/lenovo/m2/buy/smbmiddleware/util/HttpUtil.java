
package com.lenovo.m2.buy.smbmiddleware.util;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.UnsupportedEncodingException;
import java.net.URI;
import java.nio.charset.Charset;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;

import org.apache.commons.lang.StringUtils;
import org.apache.http.HttpEntity;
import org.apache.http.HttpResponse;
import org.apache.http.NameValuePair;
import org.apache.http.client.config.RequestConfig;
import org.apache.http.client.entity.UrlEncodedFormEntity;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.entity.StringEntity;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.HttpClients;
import org.apache.http.impl.nio.client.CloseableHttpAsyncClient;
import org.apache.http.impl.nio.client.HttpAsyncClients;
import org.apache.http.message.BasicNameValuePair;
import org.apache.http.util.EntityUtils;

import com.lenovo.m2.buy.smbmiddleware.enums.GlobalErrorMessage;
import com.lenovo.m2.buy.smbmiddleware.exception.BusinessException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;


/**
 * @Description:
 * @author:
 */
public class HttpUtil {


	private static Logger log = LoggerFactory.getLogger(HttpUtil.class);

	private static int conTimeOutMs = 10000;
	private static int soTimeOutMs = 30000;
	
	
	
	/**
	 * @description 发送httpClient post 请求，json 格式返回
	 * @author qinhc
	 * @2015下午6:03:09
	 * @param url
	 * @param body
	 * @return
	 * @throws Exception
	 */
	public static String executeHttpPost(String url, String body)
			throws RuntimeException {
		CloseableHttpClient httpclient = HttpClients.createDefault(); 
		HttpPost method = new HttpPost(url);
		StringEntity entity = new StringEntity(body, "utf-8");// 解决中文乱码问题
		entity.setContentEncoding("UTF-8");
		entity.setContentType("application/x-www-form-urlencoded; charset=utf-8");

		method.setEntity(entity);
		String resData = "";
		// 请求超时
		// 读取超时
		RequestConfig config = RequestConfig.custom().setSocketTimeout(soTimeOutMs).setConnectTimeout(conTimeOutMs).build();
		method.setConfig(config);
		
		try {
			HttpResponse result = httpclient.execute(method);
			// 请求结束，返回结果
			resData = EntityUtils.toString(result.getEntity());
		} catch (Exception e) {
			log.error("execute http post error", e);
			throw new BusinessException(GlobalErrorMessage.ERROR_SYSTEM_ERROR.getCode(), e.getMessage());
		} finally {
			try{
				httpclient.close();
			}catch(Exception e){
				log.error("close http client error", e);
			}
			
		}
		return resData;
	}
	
	/**
	 * @description
	 * @author qinhc
	 * @2015下午6:00:41
	 * @param url
	 * @param body
	 * @param type 请求的类型
	 * @return
	 * @throws Exception
	 */
	public static String executeHttpPostType(String url, String body, String type)
			throws Exception {
		CloseableHttpClient httpclient = HttpClients.createDefault(); 
		HttpPost method = new HttpPost(url);
		StringEntity entity = new StringEntity(body, "utf-8");// 解决中文乱码问题
		entity.setContentEncoding("UTF-8");
		entity.setContentType(type);
		method.setEntity(entity);
		String resData = "";
		// 请求超时
		RequestConfig config = RequestConfig.custom().setSocketTimeout(20000).setConnectTimeout(20000).build();
		method.setConfig(config);

		try {
			HttpResponse result = httpclient.execute(method);
			// 请求结束，返回结果
			resData = EntityUtils.toString(result.getEntity(), Charset.forName("UTF-8"));
			log.info("executeHttpPostType返回的数据：" + resData);
		} catch (Exception e) {
			log.error("executeHttpPostType请求出错：" + e.getMessage());
		} finally {
			try{
				httpclient.close();
			}catch(Exception e){
				//nothing todo
				log.error("close http client error", e);
			}
		}
		return resData;
	}
	
	/**
	 * 
	* @Description: post 提交
	* @author yuzj7@lenovo.com  
	* @date 2015年5月15日 上午10:41:49
	* @param url
	* @param params
	* @return
	 */
	public static String postStr(String url, Map<String, Object> params) throws UnsupportedEncodingException{
		CloseableHttpClient httpclient = HttpClients.createDefault(); 
		HttpPost httpPost = new HttpPost(url);
		//application/x-www-form-urlencoded
		httpPost.setHeader("Content-Type", "application/x-www-form-urlencoded");
		List<NameValuePair> nvps = new ArrayList<NameValuePair>(); 
		if (params != null && !params.isEmpty()) {
			for (Entry<String, Object> entry : params.entrySet()) {
				nvps.add(new BasicNameValuePair(entry.getKey(), String.valueOf(entry
						.getValue())));
			}
		}
		httpPost.setEntity(new UrlEncodedFormEntity(nvps, "utf-8"));
		String line = null;   
		String str="";
		 try { 
			HttpResponse response = httpclient.execute(httpPost); 
			HttpEntity entity = response.getEntity(); 
			InputStreamReader inputstream = new InputStreamReader(entity.getContent(), "UTF-8");
			BufferedReader reader = new BufferedReader(inputstream);   
			// 显示结果   
			while ((line = reader.readLine()) != null) {   
				str+=line;   
			} 
			reader.close();
			inputstream.close();
		 }catch(Exception e){
             log.error(e.getMessage(),e);
		 }finally{
			 try{
				 if(httpclient != null){
					 httpclient.close();
				 }
			 }catch(Exception e){
				 log.error("", e);
			 }
		 }
		return str;
	}
	
	
	/**
	 * post 方法
	 * @param url
	 * @return
	 * @author mamj
	 * @throws UnsupportedEncodingException
	 * @date 2013-11-19 下午03:46:58
	 */
	public static String PostStr(String url, Map<String, String> params,String referer,String cookie,boolean isproxy,String charset) throws UnsupportedEncodingException{
		CloseableHttpClient httpclient = HttpClients.createDefault();  
		// 请求超时
		// 读取超时
		RequestConfig config = RequestConfig.custom().setSocketTimeout(60000).setConnectTimeout(60000).build();
		HttpPost httpPost = new HttpPost(url); 
		httpPost.setConfig(config);
		
		List<NameValuePair> nvps = new ArrayList<NameValuePair>(); 
		if (params != null && !params.isEmpty()) {
			for (Entry<String, String> entry : params.entrySet()) {
				nvps.add(new BasicNameValuePair(entry.getKey(), entry
						.getValue()));
			}
		}
		if(!StringUtils.isEmpty(cookie)){
			httpPost.setHeader("Cookie", cookie);
		}
		if(!StringUtils.isEmpty(referer)){
			httpPost.addHeader("Referer", referer);
		}
         
         if(StringUtils.isEmpty(charset)){
        	 charset = "utf-8";
         }
		httpPost.setEntity(new UrlEncodedFormEntity(nvps, charset));
		String line = null;   
		 StringBuffer str = new StringBuffer("");  
		 InputStreamReader inreader = null;
		 BufferedReader reader = null;
		 try { 
			HttpResponse response=httpclient.execute(httpPost); 
			HttpEntity entity = response.getEntity();   
			inreader = new InputStreamReader(entity.getContent(), charset);
			reader  = new BufferedReader(inreader);   
			// 显示结果   
			while ((line = reader.readLine()) != null) {   
				str.append(line);
			} 
		 }catch(Exception e){
             log.error(e.getMessage(),e);
		 }finally{
			 if (reader != null) {
	        	  try {
	        		  reader.close();// 最后要关闭BufferedReader  
				} catch (IOException e) {
                      log.error(e.getMessage(),e);
				}
	          }
	    	  if(inreader != null){
	    		  try {
	    			  inreader.close();
	    			  httpclient.close();
				} catch (IOException e) {
					log.error("", e);
				}
	    	  }
		 }
		return str.toString();
	}
	
	
	/**
	 * 
	* @Description: http get 请求
	* @author yuzj7@lenovo.com  
	* @date 2015年6月11日 下午5:53:28
	* @param url
	* @return
	 */
	public static String getStr(String url) {
		
		  BufferedReader in = null;  
	      // 定义HttpClient  
		  CloseableHttpClient client = HttpClients.createDefault();  
		  
	      // 实例化HTTP方法  
	      HttpGet request = new HttpGet(url);
	      RequestConfig config = RequestConfig.custom().setSocketTimeout(60000).setConnectTimeout(60000).build();
	      request.setConfig(config);
	      String line = "";  
	      String tmp="";
	      try {  
		      request.setHeader("Content-Type", "application/x-www-form-urlencoded");
		      HttpResponse response = client.execute(request);
	          in = new BufferedReader(new InputStreamReader(response.getEntity().getContent(), "UTF-8"));   
	          while ((tmp=in.readLine()) != null) {   
	            line+=tmp;   
	          }
	      }catch (Exception e) {
              log.error(e.getMessage(),e);
			  e.printStackTrace();
          }finally{
	    	  if (in != null) {
	        	  try {
					in.close();// 最后要关闭BufferedReader  
					client.close();
				} catch (IOException e) {
					log.error("", e);
				}
	          }
	      }  
	      return line;  
	            
	}

    public static String getStrCookie(String url,String cookieName,String cookieValue) {

        BufferedReader in = null;
        // 定义HttpClient
        CloseableHttpClient client = HttpClients.createDefault();

        // 实例化HTTP方法
        //HttpGet request = new HttpGet();
        HttpPost request = new HttpPost();
        RequestConfig config = RequestConfig.custom().setSocketTimeout(60000).setConnectTimeout(60000).build();
        request.setConfig(config);
        String line = "";
        String tmp="";
        try {
            request.setURI(new URI(url));
            request.setHeader("Content-Type", "text/html;charset=UTF-8");
//            request.setHeader("Cookie",cookieName+"="+cookieValue);
            request.setHeader("Cookie",cookieName+"="+cookieValue);
            HttpResponse response = client.execute(request);
            in = new BufferedReader(new InputStreamReader(response.getEntity().getContent(), "UTF-8"));
            while ((tmp=in.readLine()) != null) {
                line+=tmp;
            }
        }catch (Exception e) {
            log.error(e.getMessage(),e);
        }finally{
            if (in != null) {
                try {
                    in.close();// 最后要关闭BufferedReader
                    client.close();
                } catch (IOException e) {
                	log.error("", e);
                }
            }
        }
        return line;

    }


	/**
	 * @description
	 * @author wangrq1
	 * @2015下午6:00:41
	 * @param url
	 * @param body
	 * @param type 请求的类型
	 * @return
	 * @throws Exception
	 */
	public static String asyncHttpPost(String url, String body, String type)
			throws Exception {
		CloseableHttpAsyncClient httpclient = HttpAsyncClients.createDefault();
		HttpPost method = new HttpPost(url);
		StringEntity entity = new StringEntity(body, "utf-8");// 解决中文乱码问题
		entity.setContentEncoding("UTF-8");
		entity.setContentType(type);
		method.setEntity(entity);
		String resData = "";
		// 请求超时
		RequestConfig config = RequestConfig.custom().setSocketTimeout(20000).setConnectTimeout(20000).build();
		method.setConfig(config);

		try {

//			httpclient.start();
//			httpclient.execute()
//			httpclient.execute(method, )
//			HttpResponse result = httpclient.execute(method);

			
			// 请求结束，返回结果
//			resData = EntityUtils.toString(result.getEntity(), Charset.forName("UTF-8"));
			log.info("executeHttpPostType返回的数据：" + resData);
		} catch (Exception e) {
			log.error("executeHttpPostType请求出错：" + e.getMessage());
		} finally {
			method.releaseConnection();
		}
		return resData;
	}


	public static void main(String[] args) {
	
	}
}
