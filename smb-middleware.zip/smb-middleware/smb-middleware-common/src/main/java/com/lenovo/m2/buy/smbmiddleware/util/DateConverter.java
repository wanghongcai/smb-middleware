package com.lenovo.m2.buy.smbmiddleware.util;

import org.apache.commons.beanutils.Converter;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.logging.SimpleFormatter;

/**
 * Created by wangrq1 on 2016/8/3.
 */
public class DateConverter implements Converter {

    @Override
    public Object convert(Class type, Object value) {
        if (value == null) {
            return null;
        }
        if (value instanceof Date) {
            return value;
        }
        if (value instanceof Long) {
            Long longValue = (Long) value;
            return new Date(longValue.longValue());
        }
        if (value instanceof String) {
            try {
                return new SimpleDateFormat("yyyy-MM-dd HH:mm:ss").parse((String) value);
            } catch (ParseException e) {
                e.printStackTrace();
                return null;
            }
        }
        return  null;
    }
}