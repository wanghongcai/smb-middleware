package com.lenovo.m2.buy.smbmiddleware.util;

/**
 * Created by wangrq1 on 2016/7/27.
 */
public interface Constants {

    static String METHOD_ADDRESS_ADD = "lenovo.consignee.add";

    static String METHOD_ADDRESS_MODIFY = "lenovo.consignee.edit";

    static String METHOD_ADDRESS_GETBYID = "lenovo.consignee.getdeliver";

    static String METHOD_PAY_STATUS_NOTIFY = "lenovo.pay.status.notify";

    static String METHOD_PRICE_LIST_ADD = "lenovo.pricelist.add";

    static String METHOD_PRICE_LIST_MANUALORDER = "lenovo.pricelist.manualorder";

    static String METHOD_INVOICE_SYNC = "lenovo.invoice.sync";

    static String METHOD_INVOICE_GETBYID = "lenovo.invoice.getById";


    static String METHOD_ORDER_STATE_UPDATE = "lenovo.order.state.update";

    //物流单号    
    static String METHOD_ORDER_LOGISTICS  = "lenovo.order.logistics";
    
    //订单轨迹
    static String METHOD_ORDER_LOGISTICS_MESSAGE  = "lenovo.order.logistics.message";

    static String METHOD_CONTRACT_QUERY_PDFURL = "lenovo.contract.query.pdfurl";

    static String METHOD_ADDRESS_FOR_SYNC = "lenovo.consignee.queryforsync";

    static String METHOD_INVOICE_FOR_SYNC = "lenovo.invoice.querylog";

    static String METHOD_ADDRESS_GETIDBYUUID = "lenovo.consignee.getIdByGuid";

    static String METHOD_INVOICE_GETIDBYUUID = "lenovo.invoice.getIdByUUID";


    static String METHOD_MEMBER_GETIDBYTHIRDID = "lenovo.customer.open.getCustomerBythirdid";

    static String METHOD_MEMBER_GETTHIRDIDBYID = "lenovo.customer.open.getCustomerbyid";
    
    
    static String METHOD_PULL_DEALNO = "lenovo.pricelist.pullOrderedDealNo";
    
    
    static String METHOD_CONTRACT_ADD = "lenovo.contract.addContractInfo";
    
    static String METHOD_CONTRACT_QUERY = "lenovo.contract.getContractInfo";
    
    
    static String METHOD_PRICE_LIST_UPDATETO_ORDERED = "lenovo.pricelist.updateToOrdered";

    static String METHOD_PRICE_LIST_QUERY_PDFURL = "lenovo.pricelist.queryPdfUrl";
    

}
