package com.lenovo.m2.buy.smbmiddleware.util;

import java.util.Arrays;
import java.util.List;

import org.apache.commons.lang.StringUtils;

/**
 * Created by luqian on 2015-11-16.
 */
public class CommonUtils {

    public static boolean isNumeric(String str){
    	if(StringUtils.isEmpty(str)){
    		return false;
    	}
        for (int i = 0; i < str.length(); i++){
            if (!Character.isDigit(str.charAt(i))){
                return false;
            }
        }
        return true;
    }
    
    
    public static <T> String listJoin(List<T> list, String joiner){
    	StringBuilder sb = new StringBuilder();
    	for(T item: list){
    		sb.append(joiner).append(item);
    	}
    	return sb.substring(joiner.length());
    }

    
    public static void main(String[] args) {
		List<String> a = Arrays.asList(new String[]{"a","a","d","e"});
    	
    	
    	System.out.println(listJoin(a,","));
    	
    	System.out.println(listJoin(a, ",:"));
    	
	}
}
