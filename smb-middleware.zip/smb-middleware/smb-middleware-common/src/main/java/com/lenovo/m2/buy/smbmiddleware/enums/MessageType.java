package com.lenovo.m2.buy.smbmiddleware.enums;

/**
 * Created by wangrq1 on 2016/7/26.
 */
public enum MessageType {
    ADDRESS_ADD,ADDRESS_MODIFY, ADDRESS_DELETE, INVOICE_ADD, INVOICE_MODIFY, INVOICE_DELETE, UPDATE_PRICELIST;
	
	
	
	public static boolean isAddress(MessageType type){
		return type == ADDRESS_ADD || type == ADDRESS_MODIFY || type == ADDRESS_DELETE;
	}
	
	
	public static boolean isInvoice(MessageType type){
		return type == INVOICE_ADD || type == INVOICE_MODIFY || type == INVOICE_DELETE;
	}
}
