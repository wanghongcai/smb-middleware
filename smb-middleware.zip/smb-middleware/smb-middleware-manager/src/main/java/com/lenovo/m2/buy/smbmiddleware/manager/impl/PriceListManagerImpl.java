package com.lenovo.m2.buy.smbmiddleware.manager.impl;

import java.util.HashMap;
import java.util.Map;

import com.lenovo.m2.buy.smbmiddleware.remote.OpenPlatUtil;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.lenovo.m2.arch.framework.domain.RemoteResult;
import com.lenovo.m2.buy.smbmiddleware.manager.PriceListManager;
import com.lenovo.m2.buy.smbmiddleware.remote.cxf.pricelist.GoodsAndPricelistSoap;
import com.lenovo.m2.buy.smbmiddleware.remote.cxf.pricelist.IntegrationPriceList;
import com.lenovo.m2.buy.smbmiddleware.remote.cxf.pricelist.PriceResult;
import com.lenovo.m2.buy.smbmiddleware.util.Constants;
import com.lenovo.m2.buy.smbmiddleware.util.JsonUtil;

@Service
public class PriceListManagerImpl implements PriceListManager {
	
	private static Logger log = LoggerFactory.getLogger(PriceListManagerImpl.class);
	
	@Autowired
	private GoodsAndPricelistSoap goodsAndPricelistSoap;

	@Autowired
	private OpenPlatUtil openPlatUtil;
	
	@Override
	public boolean updateSmbStatus(String dealNo) {
		
		IntegrationPriceList param = new IntegrationPriceList();
		param.setPriceListCode(dealNo);
		PriceResult result = goodsAndPricelistSoap.sendBTCPriceStatus(param);
		log.info("updateSmb pricelist Status, res={}", JsonUtil.toJson(result));
		
		return result.isReturnFlag();
	}

	@Override
	public String pullOrderedDealNo() {
		
		Map param = new HashMap<>();
        param.put("count", 1);
        String res = openPlatUtil.invokeOpenPlat(Constants.METHOD_PULL_DEALNO, JsonUtil.toJson(param));
        log.info("pullOrderedDealNo return ={}", res);
        RemoteResult<String> map = JsonUtil.fromJson(res, RemoteResult.class);
        if(map.isSuccess()){
            return map.getT();
        }else {
            log.warn("查询待更新状态的报价单号失败");
            return null;
        }
		
	}
	
	

}
