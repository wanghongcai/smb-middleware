package com.lenovo.m2.buy.smbmiddleware.manager;

public interface PriceListManager {

	
	boolean updateSmbStatus(String dealNo);
	
	
	
	String pullOrderedDealNo();
	
}
