package com.lenovo.m2.buy.smbmiddleware.manager;

import java.util.List;

import com.lenovo.m2.buy.smbmiddleware.domain.InvoiceShop;
import com.lenovo.m2.buy.smbmiddleware.domain.InvoiceShopModifyLog;

/**
 * Created by wangrq1 on 2016/7/27.
 */
public interface InvoiceManager {

    /**
     * smb 添加发票信息调用商城
     * @param json
     * @return
     */
    String syncInvoiceAdd(String json) throws Exception;


    boolean notifySmbInvoiceAdd(InvoiceShop json);


    boolean notifySmbInvoiceModify(InvoiceShop json);
    
    
    boolean notifySmbInvoiceDelete(InvoiceShop json);


    List<InvoiceShop> pullInvoice();


    String getIdByGuid(String guid);


    InvoiceShop getById(String id);
    
}
