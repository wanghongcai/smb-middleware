package com.lenovo.m2.buy.smbmiddleware.manager.impl;

import java.lang.reflect.InvocationTargetException;
import java.util.Collections;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.annotation.Resource;

import com.lenovo.m2.buy.smbmiddleware.remote.OpenPlatUtil;
import org.apache.commons.beanutils.BeanUtils;
import org.apache.commons.beanutils.ConvertUtils;
import org.apache.commons.lang.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.lenovo.m2.arch.framework.domain.RemoteResult;
import com.lenovo.m2.buy.smbmiddleware.domain.AddressLog;
import com.lenovo.m2.buy.smbmiddleware.domain.Memberaddrs;
import com.lenovo.m2.buy.smbmiddleware.enums.GlobalErrorMessage;
import com.lenovo.m2.buy.smbmiddleware.exception.BusinessException;
import com.lenovo.m2.buy.smbmiddleware.manager.AddressManager;
import com.lenovo.m2.buy.smbmiddleware.remote.MemberInfoRemote;
import com.lenovo.m2.buy.smbmiddleware.remote.cxf.member.AddressTypeEnum;
import com.lenovo.m2.buy.smbmiddleware.remote.cxf.member.IntegrationShipToParty;
import com.lenovo.m2.buy.smbmiddleware.remote.cxf.member.MemberInfoSoap;
import com.lenovo.m2.buy.smbmiddleware.remote.cxf.member.Result;
import com.lenovo.m2.buy.smbmiddleware.remote.cxf.member.TrueFalseEnum;
import com.lenovo.m2.buy.smbmiddleware.util.Constants;
import com.lenovo.m2.buy.smbmiddleware.util.DateConverter;
import com.lenovo.m2.buy.smbmiddleware.util.DateUtils;
import com.lenovo.m2.buy.smbmiddleware.util.JsonUtil;

/**
 * Created by wangrq1 on 2016/7/27.
 */

@Service
public class AddressManagerImpl implements AddressManager {

    private static Logger log = LoggerFactory.getLogger(AddressManagerImpl.class);

    @Resource
    private MemberInfoRemote memberInfoRemote;

    @Autowired
    private MemberInfoSoap memberInfoSoap;

    @Autowired
    private OpenPlatUtil openPlatUtil;

    static {
        ConvertUtils.register(new DateConverter(), Date.class);

    }
    
 

    @Override
    public String syncAddressAdd(String json) throws Exception{
        String method = Constants.METHOD_ADDRESS_ADD;

        //id转换
        Map openPlatParam = JsonUtil.fromJson(json, Map.class);
        String memberCode = String.valueOf(openPlatParam.get("memberCode"));
        String userId = memberInfoRemote.findIdByThirdId(memberCode);
        openPlatParam.put("userId", userId);
        openPlatParam.put("unique", userId);
        openPlatParam.put("terminal", "1");
        openPlatParam.remove("memberCode");
        openPlatParam.put("shopId", "8");
        
        //该res 为解开开放平台层报文的应用层的 remote,
        String res =  openPlatUtil.invokeOpenPlat(method, JsonUtil.toJson(openPlatParam));

        Map map = JsonUtil.fromJson(res, Map.class);
        Object rc = map.get("rc");
        if("0".equals(String.valueOf(rc))){
            //成功
            Map data = JsonUtil.fromJson(json, Map.class);
            data.put("id", map.get("id"));
//            notifySmbAddressAdd(JsonUtil.toJson(data));

            RemoteResult rr = new RemoteResult(true);
            rr.setT(map);

            return JsonUtil.toJson(rr);
        }else {
            RemoteResult rr = new RemoteResult(false);
            rr.setResultCode(String.valueOf(rc));
            rr.setResultMsg(String.valueOf(map.get("msg")));
            return JsonUtil.toJson(rr);
        }
    }

    @Override
    public String syncAddressModify(String body) throws Exception{

        Map map = JsonUtil.fromJson(body, Map.class);
        String deliverId = (String)map.get("outDeliverId");

        String mallId = this.getIdByGuid(deliverId);
        //id转换
        map.put("deliverId", mallId);
        //user转换
        String memberCode = String.valueOf(map.get("memberCode"));
        String userId = memberInfoRemote.findIdByThirdId(memberCode);
        map.put("userId", userId);
        map.put("unique", userId);
        map.put("terminal", "1");
        map.put("shopId", "8");
        
        //调用开放平台
        String modifyRes = openPlatUtil.invokeOpenPlat(Constants.METHOD_ADDRESS_MODIFY, JsonUtil.toJson(map));
        Map modifyResMap = JsonUtil.fromJson(modifyRes, Map.class);
        Object modifyRc = modifyResMap.get("rc");

        if("0".equals(String.valueOf(modifyRc))){
            RemoteResult rr = new RemoteResult(true);
            rr.setT(modifyResMap);
            return JsonUtil.toJson(rr);
        }else{
            RemoteResult rr = new RemoteResult(false);
            rr.setResultCode(String.valueOf(modifyRc));
            rr.setResultMsg(String.valueOf(modifyResMap.get("msg")));
            return JsonUtil.toJson(rr);
        }
        
    }




    @Override
    public boolean notifySmbAddressAdd(Memberaddrs json) {

        IntegrationShipToParty smbAddress = addressTransfer(json);
        //set Memberid
        String lenovoid = json.getLenovoId();
        String memberId = memberInfoRemote.findUserGUID(lenovoid);
        smbAddress.setMemberInfoID(memberId);

        log.info("notifySmbAddress req={}", JsonUtil.toJson(smbAddress));	
        Result result = memberInfoSoap.addShipInfo(smbAddress);

        log.info(JsonUtil.toJson(result));
        return result.isReturnFlag();
    }

    @Override
    public boolean notifySmbAddressModify(Memberaddrs json) {
        IntegrationShipToParty smbAddress = addressTransfer(json);
        String lenovoid = json.getLenovoId();
        String memberId = memberInfoRemote.findUserGUID(lenovoid);
        smbAddress.setMemberInfoID(memberId);
        log.info("通知smb:{}", JsonUtil.toJson(smbAddress));
        Result result = memberInfoSoap.updateShipInfo(smbAddress);
        log.info(JsonUtil.toJson(result));

        return result.isReturnFlag();
    }



    private IntegrationShipToParty addressTransfer(Memberaddrs address){
        if(address == null){
            return  null;
        }

        IntegrationShipToParty smbAddress = new IntegrationShipToParty();

        smbAddress.setAddress(address.getAddress());

        String type = address.getType();
        AddressTypeEnum typeEnum = AddressTypeEnum.RECEIVING;
        if("SH".equals(type)){
            typeEnum = AddressTypeEnum.RECEIVING;
        }else if("SP".equals(type)){
            typeEnum = AddressTypeEnum.TICKET;
        }else if("HT".equals(type)){
            typeEnum = AddressTypeEnum.PACT;
        }else{
            throw new BusinessException(GlobalErrorMessage.ERROR_PLAT_UNKNOWN_ADDRESS_TYPE);
        }
        smbAddress.setAddressType(typeEnum);
        smbAddress.setClientName(address.getName());
        smbAddress.setClientAbbName(address.getAddressname());
        smbAddress.setMobilePhone(address.getMobile());

        smbAddress.setProvinceCode(address.getProvinceCode());
        smbAddress.setProvinceName(address.getProvinceCode());
        
        smbAddress.setCityCode(address.getCityCode());
        smbAddress.setCityName(address.getCityCode());
        
        smbAddress.setCountyCode(address.getCountyCode());
        smbAddress.setCountyName(address.getCountyCode());

        smbAddress.setIsDefault("1".equals(address.getIsdefault()) ? TrueFalseEnum.TRUE : TrueFalseEnum.FALSE);
        smbAddress.setIsValid(TrueFalseEnum.TRUE);
//        smbAddress.setSubAreaCode();
//        smbAddress.setSubAreaName();
        smbAddress.setZip(address.getZip());
        smbAddress.setID(address.getGuid());

        smbAddress.setCreateTime(DateUtils.convertToXMLGregorianCalendar(address.getCreatetime()));
        smbAddress.setCreateBy(address.getCreateby());
        
        smbAddress.setShipToCompany(address.getCompany());

        return smbAddress;
    }

    @Override
    public String getIdByGuid(String guid) {
        Map param = new HashMap<>();
        param.put("guid", guid);

        String res = openPlatUtil.invokeOpenPlat(Constants.METHOD_ADDRESS_GETIDBYUUID, JsonUtil.toJson(param));
        log.info("address getIdByGuid return ={}", res);
        Map map = JsonUtil.fromJson(res, Map.class);
        String rc = String.valueOf(map.get("rc"));
        if("0".equals(rc)){
            return String.valueOf(map.get("data"));
        }else {
            throw new BusinessException("1", "查询地址id失败");
        }

    }

    @Override
    public Memberaddrs getById(String userId, String type, String deliverId) {

        Map<String,Object> param = new HashMap<>();
        param.put("userId", userId);
        param.put("type", type);
        param.put("deliverId", deliverId);

        String res = openPlatUtil.invokeOpenPlat(Constants.METHOD_ADDRESS_GETBYID, JsonUtil.toJson(param));

        Map map = JsonUtil.fromJson(res, Map.class);

        String rc = String.valueOf(map.get("rc"));
        if("0".equals(rc)){
            Map data = (Map)map.get("data");
            if(data == null){
                return  null;
            }
            Memberaddrs ret = new Memberaddrs();
            try {
                BeanUtils.copyProperties(ret, data);
            } catch (IllegalAccessException e) {
                e.printStackTrace();
            } catch (InvocationTargetException e) {
                e.printStackTrace();
            }
            return ret;

        }else{
            throw  new BusinessException(GlobalErrorMessage.ERROR_PARAM_ILLEGAL);
        }
    }


    @Override
    public List<AddressLog> pullAddress() {
        Map<String,Object> param = new HashMap<>();
        param.put("count", "0");

        try {
            String res = openPlatUtil.invokeOpenPlat(Constants.METHOD_ADDRESS_FOR_SYNC, JsonUtil.toJson(param));
            if(StringUtils.isEmpty(res) || "[]".equals(res) || "{}".equals(res)){
                return Collections.emptyList();
            }

            Map map = JsonUtil.fromJson(res, Map.class);
            String rc = String.valueOf(map.get("rc"));
            if(!"0".equals(rc)){
                throw new BusinessException(GlobalErrorMessage.ERROR_PARAM_ILLEGAL);
            }
            Object data = map.get("data");
            if(data == null){
                return Collections.emptyList();
            }
            String json = JsonUtil.toJson(data);
            List<AddressLog> ret = JsonUtil.readValuesAsArrayList(json, AddressLog.class);

            return ret;
        }catch (Exception e){
            log.error("", e);
            return Collections.emptyList();
        }

    }

	@Override
	public boolean notifySmbAddressDelete(Memberaddrs json) {
        IntegrationShipToParty smbAddress = addressTransfer(json);
        String lenovoid = json.getLenovoId();
        String memberId = memberInfoRemote.findUserGUID(lenovoid);
        smbAddress.setMemberInfoID(memberId);
        smbAddress.setIsValid(TrueFalseEnum.FALSE);
        log.info("通知smb:{}", JsonUtil.toJson(smbAddress));
        Result result = memberInfoSoap.updateShipInfo(smbAddress);
        log.info(JsonUtil.toJson(result));

        return result.isReturnFlag();
	}

	
}
