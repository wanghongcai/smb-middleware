package com.lenovo.m2.buy.smbmiddleware.manager;


import java.util.List;

import com.lenovo.m2.buy.smbmiddleware.domain.AddressLog;
import com.lenovo.m2.buy.smbmiddleware.domain.Memberaddrs;

/**
 * Created by wangrq1 on 2016/7/27.
 */
public interface AddressManager {


    /**
     * smb 添加地址调用商城
     * @param json
     * @return
     */
    String syncAddressAdd(String json) throws Exception;

    /**
     * smb修改地址调用商城
     * @param json
     * @return
     */
    String syncAddressModify(String json) throws Exception;


    String getIdByGuid(String guid);


    Memberaddrs getById(String userId, String type, String deliverId);


    boolean notifySmbAddressAdd(Memberaddrs json);


    boolean notifySmbAddressModify(Memberaddrs json);


    boolean notifySmbAddressDelete(Memberaddrs json);
    
    
    
    List<AddressLog> pullAddress();

}
