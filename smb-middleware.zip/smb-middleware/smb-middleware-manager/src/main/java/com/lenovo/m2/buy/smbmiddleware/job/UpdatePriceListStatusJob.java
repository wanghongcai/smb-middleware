package com.lenovo.m2.buy.smbmiddleware.job;

import org.apache.commons.lang.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;

import com.lenovo.m2.buy.smbmiddleware.enums.MessageType;
import com.lenovo.m2.buy.smbmiddleware.manager.PriceListManager;
import com.lenovo.m2.buy.smbmiddleware.util.MessageQueue;

/**
 * Created by wangrq1 on 2016/7/25.
 */
@Component
public class UpdatePriceListStatusJob {

    private static Logger log = LoggerFactory.getLogger(UpdatePriceListStatusJob.class);


    @Autowired
    private PriceListManager invoiceManager;


    @Scheduled(fixedRate=10000)
    public void run(){
    	while(true){
    		String dealNo = invoiceManager.pullOrderedDealNo();
    		if(StringUtils.isEmpty(dealNo)){
    			return;
    		}
    		log.info("查询到待通知的报价单号：{}", dealNo);
    		execNotify(dealNo);
    	}
    }
    
    
    private void execNotify(String dealNo){
         try{
         	boolean res = invoiceManager.updateSmbStatus(dealNo);
            log.info("UpdatePriceListStatus, dealNo={}, res={}", dealNo, res);
         }catch (Exception e){
         	log.error("InvoiceQueryJob error", e);
//            MessageQueue.Message msg = new MessageQueue.Message(MessageType.UPDATE_PRICELIST, dealNo);
//            MessageQueue.add(msg);
         }
   }


}
