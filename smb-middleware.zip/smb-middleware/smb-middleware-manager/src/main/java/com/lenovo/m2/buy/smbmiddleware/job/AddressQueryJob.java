package com.lenovo.m2.buy.smbmiddleware.job;

import java.util.List;

import javax.annotation.Resource;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;

import com.lenovo.m2.buy.smbmiddleware.domain.AddressLog;
import com.lenovo.m2.buy.smbmiddleware.domain.Memberaddrs;
import com.lenovo.m2.buy.smbmiddleware.enums.MessageType;
import com.lenovo.m2.buy.smbmiddleware.manager.AddressManager;
import com.lenovo.m2.buy.smbmiddleware.util.JsonUtil;
import com.lenovo.m2.buy.smbmiddleware.util.MessageQueue;

/**
 * Created by wangrq1 on 2016/7/25.
 */
@Component
public class AddressQueryJob{

    private static Logger log = LoggerFactory.getLogger(AddressQueryJob.class);

    @Resource
    private AddressManager addressManager;

	/**
	 * 同步合同邮寄地址到SMB,每5秒执行一次
	 */
    @Scheduled(fixedRate=5000)
    public void run(){
    	while(true){
    		List<AddressLog> addresses = addressManager.pullAddress();
    		if(addresses.size() <= 0){
    			return;
    		}
    		for(AddressLog address: addresses){
    			log.info("查询到待通知的地址：{}", JsonUtil.toJson(address));
    			execNotify(address);
    		}
    	}
    }
    
    private void execNotify(AddressLog address){
    	 String type = address.getOpreation();
         Memberaddrs memberaddrs = address.getMemberaddrs();
    	try{
    		boolean res = false;
            if("1".equals(type)){
            	res = addressManager.notifySmbAddressAdd(memberaddrs);

            }else if("2".equals(type)){
            	res = addressManager.notifySmbAddressModify(memberaddrs);

            }else if("3".equals(type)){
                res = addressManager.notifySmbAddressDelete(memberaddrs);
            }
            log.info("notifySmbAddress type={} res = {}", type, res);
    	}catch(Exception e){
    		log.error("AddressQueryJob error", e);
//            MessageType mtype = MessageQueue.Message.getAddressOperType(type);
//            MessageQueue.Message msg = new MessageQueue.Message(mtype, JsonUtil.toJson(memberaddrs));
//            MessageQueue.add(msg);
    	}
    }
}
