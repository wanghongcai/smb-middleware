package com.lenovo.m2.buy.smbmiddleware.job;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;

import com.lenovo.m2.buy.smbmiddleware.domain.InvoiceShop;
import com.lenovo.m2.buy.smbmiddleware.enums.MessageType;
import com.lenovo.m2.buy.smbmiddleware.manager.InvoiceManager;
import com.lenovo.m2.buy.smbmiddleware.util.JsonUtil;
import com.lenovo.m2.buy.smbmiddleware.util.MessageQueue;

/**
 * Created by wangrq1 on 2016/7/25.
 */
public class InvoiceQueryJob {

    private static Logger log = LoggerFactory.getLogger(InvoiceQueryJob.class);


    @Autowired
    private InvoiceManager invoiceManager;


    @Scheduled(fixedRate=5000)
    public void run(){
    	while(true){
    		List<InvoiceShop> invoiceList = invoiceManager.pullInvoice();
    		if(invoiceList.size() <= 0){
    			return;
    		}
    		for(InvoiceShop invoice: invoiceList){
    			log.info("查询到待通知的发票：{}", JsonUtil.toJson(invoice));
    			execNotify(invoice);
    		}
    	}
    }
    
    
    private void execNotify(InvoiceShop invoice){
    	 Integer type = invoice.getSynType();
         InvoiceShop shop = invoice;
         try{
             //1增加，2修改，3删除
         	boolean res = false;
             if(type == 1){
                 res = invoiceManager.notifySmbInvoiceAdd(shop);
             }else if(type == 2){
            	 InvoiceShop newInvoice = invoiceManager.getById(String.valueOf(invoice.getId()));
            	 if(newInvoice == null){
            		 log.info("查询到发票为null, id={}", invoice.getId());
            		 return ;
            	 }
                 res = invoiceManager.notifySmbInvoiceModify(newInvoice);
             }else if(type == 3){
                 res = invoiceManager.notifySmbInvoiceDelete(invoice);
             }
             log.info("notify invoice type={}, res={}", type, res);
         }catch (Exception e){
         	log.error("InvoiceQueryJob error", e);
//             MessageType mtype = MessageQueue.Message.getInvoiceOperType(type + "");
//             MessageQueue.Message msg = new MessageQueue.Message(mtype, JsonUtil.toJson(shop));
//             MessageQueue.add(msg);
         }

   }


}
