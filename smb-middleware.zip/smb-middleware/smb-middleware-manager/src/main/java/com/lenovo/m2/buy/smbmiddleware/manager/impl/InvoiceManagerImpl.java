package com.lenovo.m2.buy.smbmiddleware.manager.impl;

import java.lang.reflect.InvocationTargetException;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.annotation.Resource;

import com.lenovo.m2.buy.smbmiddleware.remote.OpenPlatUtil;
import com.lenovo.m2.buy.smbmiddleware.remote.cxf.member.*;
import org.apache.commons.beanutils.BeanUtils;
import org.apache.commons.lang.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.lenovo.m2.arch.framework.domain.RemoteResult;
import com.lenovo.m2.buy.smbmiddleware.domain.Invoice;
import com.lenovo.m2.buy.smbmiddleware.domain.InvoiceShop;
import com.lenovo.m2.buy.smbmiddleware.enums.GlobalErrorMessage;
import com.lenovo.m2.buy.smbmiddleware.exception.BusinessException;
import com.lenovo.m2.buy.smbmiddleware.manager.InvoiceManager;
import com.lenovo.m2.buy.smbmiddleware.remote.MemberInfoRemote;
import com.lenovo.m2.buy.smbmiddleware.util.Constants;
import com.lenovo.m2.buy.smbmiddleware.util.DateUtils;
import com.lenovo.m2.buy.smbmiddleware.util.JsonUtil;

/**
 * Created by wangrq1 on 2016/7/28.
 */
@Service
public class InvoiceManagerImpl implements InvoiceManager {

	private static Logger log = LoggerFactory.getLogger(InvoiceManagerImpl.class);

	@Resource
	private MemberInfoRemote memberInfoRemote;

    @Autowired
    private MemberInfoSoap memberInfoSoap;


	@Autowired
	private OpenPlatUtil openPlatUtil;
	

	@Override
	public String syncInvoiceAdd(String json) throws Exception {
		String method = Constants.METHOD_INVOICE_SYNC;
		log.info("syncInvoiceAdd json={}", json);
		// id转换
		Map openPlatParam = JsonUtil.fromJson(json, Map.class);
		String memberCode = String.valueOf(openPlatParam.get("memberCode"));
		String userId = memberInfoRemote.findIdByThirdId(memberCode);
		openPlatParam.put("userId", userId);
		openPlatParam.put("unique", userId);
		openPlatParam.put("terminal", "1");
		
		
		String uuid = String.valueOf(openPlatParam.get("uuid"));
		String type = String.valueOf(openPlatParam.get("synType"));
		if("2".equals(type)){
			String id = this.getIdByGuid(uuid);
			openPlatParam.put("id", id);
		}

		// 该res 为解开开放平台层报文的应用层的 remote,
		String res = openPlatUtil.invokeOpenPlat(method, JsonUtil.toJson(openPlatParam));
		log.info("syncInvoice add res={}", res);
		return res;

	}

	@Override
	public boolean notifySmbInvoiceAdd(InvoiceShop invoice) {
		IntegrationMemberInvoiceInfo smbInvoice = toSMBInvoiceInfo(invoice);
		smbInvoice.setOperationType(OperationType.ADD);
		
		log.info("notify invoice add request = {}", JsonUtil.toJson(smbInvoice));
		Result result = memberInfoSoap.addInvoiceInfo(smbInvoice);
		log.info("notify invoice add result = {}", JsonUtil.toJson(result));
		
		return result.isReturnFlag();
	}

	@Override
	public boolean notifySmbInvoiceModify(InvoiceShop invoice) {
		IntegrationMemberInvoiceInfo smbInvoice = toSMBInvoiceInfo(invoice);
		smbInvoice.setOperationType(OperationType.UPDATE);
		Result result = memberInfoSoap.updateInvoiceInfo(smbInvoice);
		log.info("notify invoice info result = {}", JsonUtil.toJson(result));
		
		return result.isReturnFlag();
	}

	private IntegrationMemberInvoiceInfo toSMBInvoiceInfo(InvoiceShop invoice) {
		IntegrationMemberInvoiceInfo info = new IntegrationMemberInvoiceInfo();
		info.setProcessStatus(ProcessStatus.UN_PROCESSED);
		info.setUpdateTime(DateUtils.convertToXMLGregorianCalendar(invoice.getUpdateTime()));
		info.setID(invoice.getUuid());
		info.setAddress(invoice.getAddress());
		info.setBankID(invoice.getAccountNo());
		info.setBankName(invoice.getBankName());
		info.setCityCode(invoice.getCityCode());
		info.setCityName(invoice.getCityName());
		info.setCountyCode(invoice.getCountyCode());
		info.setCountyName(invoice.getCountyName());
		info.setInvoiceName(invoice.getCustomerName());
		
		Integer approvalStatus = invoice.getApprovalStatus();
		MemberInvoiceStatusEnum aStatus = MemberInvoiceStatusEnum.NOT_CHECK;
		
		info.setInvoiceType(0 == invoice.getInvoiceType() ? InvoiceTypeEnum.PLAIN_INVOICE: InvoiceTypeEnum.ADDED_INVOICES);
		
		if(info.getInvoiceType() == InvoiceTypeEnum.PLAIN_INVOICE){
			//普票直接审核通过
			aStatus = MemberInvoiceStatusEnum.POSTED;
		}else{
			//增票判断状态
			if(approvalStatus != null){
				if(approvalStatus == 1){
					aStatus = MemberInvoiceStatusEnum.RE_JECT;
				}else if(approvalStatus == 2){
					aStatus = MemberInvoiceStatusEnum.POSTED;
				}else{
					aStatus = MemberInvoiceStatusEnum.NOT_CHECK;
				}
			}else{
				aStatus = MemberInvoiceStatusEnum.NOT_CHECK;
			}
		}
				
		info.setApprovalStatus(aStatus);
		
		info.setIsDefault(0 ==invoice.getIsDefault() ? TrueFalseEnum.FALSE: TrueFalseEnum.TRUE);
		String userId = invoice.getLenovoID();
		// lenovoid -> smb uuid
		String memberId = memberInfoRemote.findUserGUID(userId);

		info.setMemberInfoID(memberId);
		info.setPayMan(invoice.getPayMan());
					
		if(invoice.getPayManType() != null){
			info.setPayManType(0 == invoice.getPayManType() ? PayManTypeEnum.PERSON : PayManTypeEnum.COMPANY);
		}
		
		info.setPhone(invoice.getPhoneNo());
		info.setProvinceCode(invoice.getProvinceCode());
		info.setProvinceName(invoice.getProvinceName());
		
		info.setSubAreaCode(invoice.getSubAreaCode());
		info.setSubAreaName(invoice.getSubAreaName());
		info.setTaxID(invoice.getTaxNo());
		info.setZip(invoice.getZip());
		info.setCreateBy(invoice.getCreateBy());
		info.setCreateTime(DateUtils.convertToXMLGregorianCalendar(invoice.getCreateTime()));
		
		if(invoice.getIsShow() != null && 0==invoice.getIsShow()){
			info.setIsShow(TrueFalseEnum.FALSE);
		}else{
			info.setIsShow(TrueFalseEnum.TRUE);
		}


		String taxNoType = invoice.getTaxNoType();

		TaxNoTypeEnum taxNoTypeEnum = TaxNoTypeEnum.EMPTY;
		if(StringUtils.isEmpty(taxNoType)){
			taxNoTypeEnum = TaxNoTypeEnum.EMPTY;
		}else if("0".equals(taxNoType)){
			taxNoTypeEnum = TaxNoTypeEnum.TAX;
		}else if("1".equals(taxNoType)){
			taxNoTypeEnum = TaxNoTypeEnum.CREDIT_CODE;
		}
		info.setTaxNoType(taxNoTypeEnum);

		InvoiceCompanyTypeEnum invoiceCompanyTypeEnum = null;
		Integer companyType = invoice.getCompanyType();
		if(companyType == 0){
			invoiceCompanyTypeEnum = InvoiceCompanyTypeEnum.PERSON;
		}else if(companyType == 1){
			invoiceCompanyTypeEnum = InvoiceCompanyTypeEnum.COMPANY;
		}
		info.setCompanyType(invoiceCompanyTypeEnum);

		return info;
	}

	public List<InvoiceShop> pullInvoice() {
		Map<String, Object> param = new HashMap<>();
		param.put("count", "1");
		try {
			String res = openPlatUtil.invokeOpenPlat(Constants.METHOD_INVOICE_FOR_SYNC, JsonUtil.toJson(param));
			log.info("pull invoice return {}", res);
			RemoteResult map = JsonUtil.fromJson(res, RemoteResult.class);
			if(!map.isSuccess()){
				return Collections.emptyList();
			}
			Object o = map.getT();
			List<InvoiceShop> log = JsonUtil.readValuesAsArrayList(JsonUtil.toJson(o), InvoiceShop.class);
			return log;
		} catch (Exception e) {
			log.error("", e);
			return Collections.emptyList();
		}
	}

	public static void main(String[] args) {
		Map<String, Object> map = new HashMap<>();

		map.put("id", "12344");

		Invoice invoice = new Invoice();

		try {
			BeanUtils.copyProperties(invoice, map);
			System.out.println(JsonUtil.toJson(invoice));
		} catch (IllegalAccessException e) {
			e.printStackTrace();
		} catch (InvocationTargetException e) {
			e.printStackTrace();
		}

	}

	@Override
	public String getIdByGuid(String guid) {
		Map<String, Object> map = new HashMap();
		map.put("terminal", 1);
		map.put("uuid", guid);
		String res = openPlatUtil.invokeOpenPlat(Constants.METHOD_INVOICE_GETIDBYUUID, JsonUtil.toJson(map));
		RemoteResult<Map> r = JsonUtil.fromJson(res, RemoteResult.class);
		if(r.isSuccess()){
			Map ret = r.getT();
			return String.valueOf(ret.get("id"));
		}else{
			throw new BusinessException(GlobalErrorMessage.ERROR_QUERY_INVOICE_ID);
		}
		
	}

	@Override
	public InvoiceShop getById(String id) {
		Map<String, Object> param = new HashMap();
		param.put("id", id);
	
		String res = openPlatUtil.invokeOpenPlat(Constants.METHOD_INVOICE_GETBYID, JsonUtil.toJson(param));
		RemoteResult<Map> map = JsonUtil.fromJson(res, RemoteResult.class);
			
		if(!map.isSuccess()){
			return null;
		}
		Map t=  map.getT();
		if(t == null){
			return null;
		}
		
		InvoiceShop ret= new InvoiceShop();
		try {
			BeanUtils.copyProperties(ret, t);
			return ret;
		} catch (IllegalAccessException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (InvocationTargetException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return null;
		
	}

	@Override
	public boolean notifySmbInvoiceDelete(InvoiceShop json) {
		IntegrationMemberInvoiceInfo smbInvoice = toSMBInvoiceInfo(json);
		smbInvoice.setOperationType(OperationType.UPDATE);
		smbInvoice.setIsShow(TrueFalseEnum.FALSE);
		Result result = memberInfoSoap.updateInvoiceInfo(smbInvoice);
		log.info("notify invoice info result = {}", JsonUtil.toJson(result));
		return result.isReturnFlag();
	}


}
