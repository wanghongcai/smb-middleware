package com.lenovo.m2.buy.smbmiddleware.job;

import javax.annotation.Resource;

import org.apache.commons.lang.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;

import com.lenovo.m2.buy.smbmiddleware.domain.Memberaddrs;
import com.lenovo.m2.buy.smbmiddleware.enums.MessageType;
import com.lenovo.m2.buy.smbmiddleware.manager.AddressManager;
import com.lenovo.m2.buy.smbmiddleware.manager.InvoiceManager;
import com.lenovo.m2.buy.smbmiddleware.manager.PriceListManager;
import com.lenovo.m2.buy.smbmiddleware.util.JsonUtil;
import com.lenovo.m2.buy.smbmiddleware.util.MessageQueue;

/**
 * Created by wangrq1 on 2016/7/26.
 */
@Component
public class MessageProcessJob {

    private static Logger log = LoggerFactory.getLogger(MessageProcessJob.class);

    @Resource
    private AddressManager addressManager;

    @Resource
    private PriceListManager priceListManager;

    @Scheduled(fixedRate=5000)
    public void run(){
    	MessageQueue.Message msg = MessageQueue.take();
        try{

            if(msg == null){
                return;
            }
            String content = msg.getContent();
            if(StringUtils.isEmpty(content)){
            	return;
            }
            
            MessageType type = msg.getType();
			if(MessageType.isAddress(type)){
            	//获取最新地址
            	Memberaddrs address = JsonUtil.fromJson(content, Memberaddrs.class);
            	Memberaddrs newAddress= addressManager.getById(address.getLenovoId(), address.getType(), address.getId());
            	if(type == MessageType.ADDRESS_ADD){
            		if(newAddress == null){
            			log.info("can not find address, orig={}", content);
            			return;
            		}
            		addressManager.notifySmbAddressAdd(newAddress);
            	}else if(type == MessageType.ADDRESS_DELETE){
            		if(newAddress == null){
            			log.info("can not find address, orig={}", content);
            			return;
            		}
            		addressManager.notifySmbAddressModify(newAddress);
            	}else if(type == MessageType.ADDRESS_DELETE){
                    addressManager.notifySmbAddressDelete(newAddress);
            	}
            }else if(type == MessageType.UPDATE_PRICELIST){
            	String dealNo = content;
            	priceListManager.updateSmbStatus(dealNo);
            	
            }
        }catch (Exception e){
            log.error("", e);
//            MessageQueue.add(msg);
        }
    }


}
